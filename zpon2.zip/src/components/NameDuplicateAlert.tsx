import React, { useState, useEffect } from 'react';
import { NameCheckResult, ExistingNameRecord } from '../utils/nameDuplicateChecker';
import { formatNumber } from '../utils/formatters';

export interface NameDuplicateAlertProps {
  checkResult: NameCheckResult;
  currency?: string;
  onSelectExisting?: (record: ExistingNameRecord) => void;
  allowSameNameAnyway?: boolean;
  onToggleAllowSameName?: (allow: boolean) => void;
}

export const NameDuplicateAlert: React.FC<NameDuplicateAlertProps> = ({
  checkResult,
  currency = 'د.ع',
  onSelectExisting,
  allowSameNameAnyway = false,
  onToggleAllowSameName,
}) => {
  const { hasExactMatch, exactMatch, hasSimilarMatches, similarMatches } = checkResult;
  const [isSimilarExpanded, setIsSimilarExpanded] = useState(true);

  useEffect(() => {
    if (hasSimilarMatches) {
      setIsSimilarExpanded(true);
    }
  }, [hasSimilarMatches, similarMatches.length]);

  if (!hasExactMatch && !hasSimilarMatches) {
    return null;
  }

  return (
    <div className="space-y-2 mt-1.5 animate-in fade-in slide-in-from-top-1 duration-200">
      {/* 1. EXACT MATCH WARNING (CRITICAL) */}
      {hasExactMatch && exactMatch && (
        <div className="p-3 bg-rose-50/95 border border-rose-200 rounded-2xl shadow-xs text-start">
          <div className="flex items-start gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center shrink-0 mt-0.5">
              <i className="fa-solid fa-triangle-exclamation text-sm"></i>
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="text-xs font-black text-rose-900 flex items-center gap-1.5 flex-wrap">
                <span>تنبيه: هذا الاسم مسجل مسبقاً بالكامل!</span>
              </h4>
              <p className="text-[11px] text-rose-700 mt-0.5 leading-relaxed">
                يوجد حساب مسبق باسم <strong className="text-rose-900 font-black">"{exactMatch.name}"</strong>
                {exactMatch.amount !== undefined && (
                  <span> برصيد حالي: <strong className="font-mono font-bold text-rose-900">{formatNumber(exactMatch.amount)} {currency}</strong></span>
                )}
                {exactMatch.phone && <span> (هاتف: <span className="font-mono">{exactMatch.phone}</span>)</span>}.
              </p>

              {/* Action Buttons */}
              <div className="mt-2.5 flex items-center gap-2 flex-wrap">
                {onSelectExisting && (
                  <button
                    type="button"
                    onClick={() => onSelectExisting(exactMatch)}
                    className="h-8 px-3 rounded-xl bg-rose-600 hover:bg-rose-700 active:bg-rose-800 text-white text-[11px] font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-2xs touch-manipulation active:scale-95"
                  >
                    <i className="fa-solid fa-folder-open text-xs"></i>
                    <span>فتح الحساب الموجود وإضافة الدين عليه</span>
                  </button>
                )}

                {onToggleAllowSameName && (
                  <label className="flex items-center gap-1.5 text-[10.5px] font-bold text-slate-600 cursor-pointer select-none bg-white/80 px-2.5 py-1.5 rounded-xl border border-rose-200 hover:bg-white transition-colors">
                    <input
                      type="checkbox"
                      checked={allowSameNameAnyway}
                      onChange={(e) => onToggleAllowSameName(e.target.checked)}
                      className="w-3.5 h-3.5 accent-rose-600 rounded cursor-pointer"
                    />
                    <span>شخص آخر يحمل نفس الاسم (سماح بالتكرار)</span>
                  </label>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. SIMILAR NAMES ALERT WITH DEDICATED ALERT BUTTON */}
      {!hasExactMatch && hasSimilarMatches && (
        <div className="bg-amber-50/95 border border-amber-300/80 rounded-2xl shadow-xs overflow-hidden text-start animate-in fade-in slide-in-from-top-1 duration-200">
          {/* Interactive Alert Button (زر تنبيه للأسماء المشابهة) */}
          <button
            type="button"
            onClick={() => setIsSimilarExpanded((prev) => !prev)}
            className="w-full p-2.5 sm:p-3 bg-gradient-to-r from-amber-500/15 via-amber-500/10 to-amber-50 flex items-center justify-between gap-2.5 hover:bg-amber-100/70 active:bg-amber-200/60 transition-all cursor-pointer border-b border-amber-200/60 text-start"
            title="اضغط لعرض أو إخفاء الأسماء المشابهة"
          >
            <div className="flex items-center gap-2.5 min-w-0">
              <span className="w-7 h-7 rounded-xl bg-amber-500 text-white flex items-center justify-center shrink-0 shadow-xs">
                <i className="fa-solid fa-bell text-xs"></i>
              </span>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="text-xs font-black text-amber-950">
                    تنبيه: يوجد ({similarMatches.length}) اسم مشابه مسجل مسبقاً
                  </span>
                  <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-amber-200 text-amber-900 font-bold">
                    احذر تشابه الأسماء
                  </span>
                </div>
                <p className="text-[10.5px] text-amber-800/90 font-medium truncate mt-0.5">
                  انقر هنا لمعاينة الحسابات المشابهة قبل إتمام الحفظ
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1.5 shrink-0 text-amber-800">
              <span className="text-[11px] font-bold hidden sm:inline">
                {isSimilarExpanded ? 'إخفاء' : 'عرض'}
              </span>
              <span className={`w-6 h-6 rounded-lg bg-amber-200/80 flex items-center justify-center text-xs transition-transform duration-200 ${isSimilarExpanded ? 'rotate-180' : ''}`}>
                <i className="fa-solid fa-chevron-down text-[10px]"></i>
              </span>
            </div>
          </button>

          {/* Expanded Similar Matches List */}
          {isSimilarExpanded && (
            <div className="p-3 space-y-2 animate-in fade-in duration-150">
              <div className="space-y-1.5">
                {similarMatches.map(({ record, message }) => (
                  <div
                    key={record.id}
                    className="p-2.5 bg-white/95 hover:bg-white rounded-xl border border-amber-200/80 flex items-center justify-between gap-2.5 transition-all shadow-2xs"
                  >
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-xs font-black text-slate-800 truncate">{record.name}</span>
                        {record.amount !== undefined && (
                          <span className="text-[10px] font-mono font-bold px-1.5 py-0.2 rounded bg-amber-100 text-amber-900 border border-amber-200">
                            {formatNumber(record.amount)} {currency}
                          </span>
                        )}
                      </div>
                      <span className="text-[10.5px] text-slate-500 block truncate mt-0.5">
                        {message} {record.phone ? `• هاتف: ${record.phone}` : ''}
                      </span>
                    </div>

                    {onSelectExisting && (
                      <button
                        type="button"
                        onClick={() => onSelectExisting(record)}
                        className="h-8 px-3 rounded-lg bg-amber-500 hover:bg-amber-600 active:bg-amber-700 active:scale-95 text-white text-[11px] font-bold flex items-center gap-1.5 cursor-pointer transition-all shrink-0 touch-manipulation shadow-2xs"
                        title="اختيار هذا الحساب المسجل"
                      >
                        <i className="fa-solid fa-arrow-left text-[10px]"></i>
                        <span>هو نفسه</span>
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

