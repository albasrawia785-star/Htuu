import React, { useState, useEffect } from 'react';
import { Debtor } from '../types';
import { useI18n } from '../i18n/index.tsx';
import { formatAmountInput, formatNumber, parseFormattedNumber, getCurrentTimeStr, resolveRecordDateTime } from '../utils/formatters';
import { handleInputFocus, useModalKeyboardAdjust } from '../utils/keyboardHelper';
import { RecordTimeSelector } from './RecordTimeSelector';
import { InvoiceAttachmentField } from './InvoiceAttachmentField';

interface TransactionModalProps {
  isOpen: boolean;
  type: 'pay' | 'add';
  debtor: Debtor | null;
  onClose: () => void;
  onConfirm: (debtorId: number, amount: number, date?: string, notes?: string, paymentMethod?: 'cash' | 'electronic', invoiceImage?: string) => Promise<void>;
  enableElectronicPayment?: boolean;
  allowInvoiceUpload?: boolean;
}

export const TransactionModal: React.FC<TransactionModalProps> = ({
  isOpen,
  type,
  debtor,
  onClose,
  onConfirm,
  enableElectronicPayment = false,
  allowInvoiceUpload = true,
}) => {
  const { t, currency } = useI18n();
  const [amountStr, setAmountStr] = useState('');
  const [notes, setNotes] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'electronic'>('cash');
  const [debtDate, setDebtDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [recordTime, setRecordTime] = useState(false);
  const [timeMode, setTimeMode] = useState<'auto' | 'manual'>('auto');
  const [debtTime, setDebtTime] = useState(() => getCurrentTimeStr());
  const [invoiceImage, setInvoiceImage] = useState<string | undefined>(undefined);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useModalKeyboardAdjust(isOpen);

  const todayStr = new Date().toISOString().split('T')[0];

  useEffect(() => {
    if (isOpen) {
      setAmountStr('');
      setNotes('');
      setPaymentMethod('cash');
      setDebtDate(new Date().toISOString().split('T')[0]);
      setRecordTime(false);
      setTimeMode('auto');
      setDebtTime(getCurrentTimeStr());
      setInvoiceImage(undefined);
      setError(null);
    }
  }, [isOpen]);

  if (!isOpen || !debtor) return null;

  const isPayment = type === 'pay';
  const enteredAmount = parseFormattedNumber(amountStr);
  const currentAmount = debtor.amount || 0;
  const newCalculatedAmount = isPayment
    ? Math.max(0, currentAmount - enteredAmount)
    : currentAmount + enteredAmount;

  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setAmountStr(formatAmountInput(e.target.value));
  };

  const handleQuickSelect = (val: number) => {
    setAmountStr(val.toLocaleString('en-US'));
  };

  const handlePayFull = () => {
    setAmountStr(currentAmount.toLocaleString('en-US'));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (enteredAmount <= 0) {
      setError(t('modals.enterAmountGreaterThanZero', 'يرجى إدخال مبلغ أكبر من صفر'));
      return;
    }

    try {
      setIsSubmitting(true);
      const formattedDate = resolveRecordDateTime(debtDate, recordTime, timeMode, debtTime);
      const trimmedNotes = notes.trim() || undefined;
      await onConfirm(
        debtor.id,
        enteredAmount,
        formattedDate,
        trimmedNotes,
        isPayment ? paymentMethod : undefined,
        invoiceImage
      );
      setInvoiceImage(undefined);
      onClose();
    } catch (err: any) {
      setError(err.message || t('common.syncError', 'حدث خطأ في المزامنة'));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex justify-center items-center z-50 p-4 animate-in fade-in duration-150 text-start">
      <div className="bg-white rounded-3xl w-full max-w-sm p-5 sm:p-6 shadow-2xl relative border border-slate-100 max-h-[92vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-3 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div
              className={`w-9 h-9 rounded-xl flex items-center justify-center text-sm font-bold ${
                isPayment ? 'bg-emerald-50 text-emerald-600' : 'bg-blue-50 text-blue-600'
              }`}
            >
              <i className={`fa-solid ${isPayment ? 'fa-arrow-down' : 'fa-plus'}`}></i>
            </div>
            <div>
              <div className="font-bold text-sm text-slate-800">
                {isPayment ? t('debts.payAmount', 'تسديد مبلغ من الدين') : t('debts.addDebt', 'إضافة دين جديد')}
              </div>
              <div className="text-[11px] text-slate-500 font-medium">{debtor.name}</div>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-10 h-10 sm:w-9 sm:h-9 rounded-full bg-slate-100 hover:bg-slate-200 active:bg-slate-300 active:scale-95 flex items-center justify-center text-slate-500 hover:text-slate-800 transition-all cursor-pointer touch-manipulation shadow-2xs"
            title="خروج / إغلاق"
            aria-label="إغلاق النافذة"
          >
            <i className="fa-solid fa-xmark text-base"></i>
          </button>
        </div>

        {/* Balance Preview Card */}
        <div className="bg-slate-50 rounded-2xl p-2.5 mb-3 border border-slate-100 grid grid-cols-2 gap-2 text-center">
          <div>
            <span className="text-[10px] text-slate-400 block mb-0.5 font-medium">{t('debts.currentDebt', 'الدين الحالي')}</span>
            <span className="text-xs font-bold text-slate-700 font-mono">
              {formatNumber(currentAmount)} {currency}
            </span>
          </div>

          <div>
            <span className="text-[10px] text-slate-400 block mb-0.5 font-medium">{t('debts.balanceAfterAction', 'الرصيد بعد العملية')}</span>
            <span
              className={`text-xs font-bold font-mono ${
                newCalculatedAmount === 0 ? 'text-emerald-600' : 'text-blue-600'
              }`}
            >
              {formatNumber(newCalculatedAmount)} {currency}
            </span>
          </div>
        </div>

        {error && (
          <div className="mb-3 p-2 bg-red-50 border border-red-200 text-red-600 text-xs rounded-xl flex items-center gap-2">
            <i className="fa-solid fa-circle-exclamation shrink-0"></i>
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="flex flex-col gap-3 pb-24 sm:pb-0">
          {/* Amount Field */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              {isPayment ? t('debts.paidAmount', 'المبلغ المسدد') : t('debts.additionalDebtAmount', 'مبلغ الدين الإضافي')} ({currency})
            </label>
            <div className="relative">
              <input
                type="text"
                dir="ltr"
                inputMode="numeric"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-base outline-none focus:border-blue-600 focus:bg-white text-slate-800 font-bold font-mono transition-all"
                placeholder="0"
                value={amountStr}
                onChange={handleAmountChange}
                onFocus={handleInputFocus}
              />
            </div>
          </div>

          {/* Quick Amount Buttons */}
          <div className="flex flex-wrap gap-1.5">
            {isPayment && currentAmount > 0 && (
              <button
                type="button"
                onClick={handlePayFull}
                className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg text-[10px] font-bold cursor-pointer transition-colors"
              >
                {t('debts.fullAmount', 'كامل المبلغ')} ({formatNumber(currentAmount)})
              </button>
            )}
            {[5000, 10000, 25000, 50000].map((val) => (
              <button
                key={val}
                type="button"
                onClick={() => handleQuickSelect(val)}
                className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg text-[10px] font-semibold cursor-pointer transition-colors"
              >
                +{val.toLocaleString('en-US')}
              </button>
            ))}
          </div>

          {/* Notes Field (Optional) */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center justify-between">
              <span>
                {t('common.notes', 'ملاحظات')}{' '}
                <span className="text-slate-400 font-normal text-[10px]">({t('common.optional', 'اختياري')})</span>
              </span>
            </label>
            <textarea
              rows={2}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:border-blue-600 focus:bg-white text-slate-800 transition-all placeholder:text-slate-400 font-bold resize-y leading-relaxed"
              placeholder={
                isPayment
                  ? t('debts.paymentPlaceholder', 'مثال: تسديد نقدي، حوالة، دفعة أسبوعية...')
                  : t('debts.debtPlaceholder', 'مثال: بضاعة، كارت شحن، مسواك...')
              }
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              onFocus={handleInputFocus}
              maxLength={250}
            />
          </div>

          {/* Payment Method Option (Cash or Electronic) - Shown only when electronic payment is enabled */}
          {isPayment && enableElectronicPayment && (
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center justify-between">
                <span>{t('debts.paymentMethod', 'طريقة الدفع والتسديد')}</span>
                <span className="text-[10.5px] font-bold text-slate-500">
                  {paymentMethod === 'electronic' ? '💳 دفع إلكتروني (ماستر كارد)' : '💵 نقداً (كاش)'}
                </span>
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('cash')}
                  className={`py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 border transition-all cursor-pointer ${
                    paymentMethod === 'cash'
                      ? 'bg-emerald-50 border-emerald-500 text-emerald-700 shadow-xs ring-2 ring-emerald-500/20'
                      : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <span className="text-sm">💵</span>
                  <span>{t('debts.cashPayment', 'نقداً (كاش)')}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('electronic')}
                  className={`py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 border transition-all cursor-pointer ${
                    paymentMethod === 'electronic'
                      ? 'bg-blue-50 border-blue-500 text-blue-700 shadow-xs ring-2 ring-blue-500/20'
                      : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <span className="text-sm">💳</span>
                  <span>{t('debts.electronicPayment', 'دفع إلكتروني')}</span>
                </button>
              </div>
            </div>
          )}

          {/* Date Picker */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-bold text-slate-700">
                {isPayment ? t('debts.paymentDate', 'تاريخ التسديد') : t('debts.debtRegistrationDate', 'تاريخ تسجيل الدين')}
              </label>
              {debtDate !== todayStr ? (
                <button
                  type="button"
                  onClick={() => setDebtDate(todayStr)}
                  className="text-[10px] font-bold text-blue-600 hover:text-blue-700 bg-blue-50 hover:bg-blue-100 px-1.5 py-0.5 rounded cursor-pointer transition-colors"
                >
                  اليوم
                </button>
              ) : (
                <span className="text-[10px] text-emerald-700 font-bold bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-100">
                  اليوم
                </span>
              )}
            </div>
            <input
              type="date"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:border-blue-600 focus:bg-white text-slate-800 transition-all font-mono"
              value={debtDate}
              onChange={(e) => setDebtDate(e.target.value)}
              onFocus={handleInputFocus}
            />
          </div>

          {/* Record Time Selector */}
          <RecordTimeSelector
            enabled={recordTime}
            onEnabledChange={setRecordTime}
            mode={timeMode}
            onModeChange={setTimeMode}
            time={debtTime}
            onTimeChange={setDebtTime}
            accentColor={isPayment ? 'emerald' : 'blue'}
            idPrefix="tx_modal"
          />

          {/* Invoice Attachment Field */}
          <InvoiceAttachmentField
            value={invoiceImage}
            onChange={setInvoiceImage}
            allowUpload={allowInvoiceUpload}
            label={isPayment ? 'صورة وصل التسديد / الفاتورة (اختياري)' : 'صورة فاتورة الدين الإضافي (اختياري)'}
          />

          <div className="flex gap-2.5 mt-3 pt-3 border-t border-slate-100 pb-[max(0.25rem,env(safe-area-inset-bottom))]">
            <button
              type="submit"
              disabled={isSubmitting}
              className={`flex-1 min-h-[46px] py-3 rounded-xl font-bold text-xs sm:text-sm shadow-md cursor-pointer transition-all flex items-center justify-center gap-2 text-white active:scale-[0.98] touch-manipulation ${
                isPayment
                  ? 'bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 shadow-emerald-500/20'
                  : 'bg-blue-600 hover:bg-blue-700 active:bg-blue-800 shadow-blue-500/20'
              }`}
            >
              {isSubmitting ? (
                <>
                  <i className="fa-solid fa-spinner fa-spin text-xs"></i>
                  <span>{t('common.processing', 'جاري المعالجة...')}</span>
                </>
              ) : (
                <>
                  <i className={`fa-solid ${isPayment ? 'fa-check' : 'fa-plus'} text-xs`}></i>
                  <span>{isPayment ? t('debts.confirmPayment', 'تأكيد التسديد') : t('debts.confirmAddition', 'تأكيد الإضافة')}</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="flex-1 min-h-[46px] bg-slate-100 hover:bg-slate-200 active:bg-slate-300 text-slate-700 py-3 rounded-xl font-bold text-xs sm:text-sm cursor-pointer transition-all active:scale-[0.98] touch-manipulation border border-slate-200/50"
            >
              {t('common.cancel', 'إلغاء')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
