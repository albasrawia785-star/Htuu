import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  signInWithPopup,
  GoogleAuthProvider,
  onAuthStateChanged,
  User as FirebaseUser,
  signOut,
} from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';

export interface GoogleDriveFile {
  id: string;
  name: string;
  mimeType?: string;
  createdTime?: string;
  modifiedTime?: string;
  size?: string;
  description?: string;
  webViewLink?: string;
}

export const GOOGLE_DRIVE_SCOPES = [
  'https://www.googleapis.com/auth/drive.file',
];

// In-memory cache for access token (never persisted to localStorage/sessionStorage)
let cachedAccessToken: string | null = null;
let isSigningIn = false;

// Initialize Firebase app and auth securely
const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
const auth = getAuth(app);

const provider = new GoogleAuthProvider();
GOOGLE_DRIVE_SCOPES.forEach((scope) => provider.addScope(scope));
provider.setCustomParameters({
  prompt: 'select_account',
});

/**
 * Initializes Google Auth state listener.
 */
export const initDriveAuth = (
  onAuthChange: (user: FirebaseUser | null, token: string | null) => void
) => {
  return onAuthStateChanged(auth, async (user: FirebaseUser | null) => {
    if (user && cachedAccessToken) {
      onAuthChange(user, cachedAccessToken);
    } else {
      onAuthChange(user, cachedAccessToken);
    }
  });
};

/**
 * Initiates Google OAuth Sign-in Popup and extracts the Drive OAuth Access Token.
 */
export const googleSignIn = async (): Promise<{ user: FirebaseUser; accessToken: string }> => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error('لم يتم استلام رمز الوصول (Access Token) من Google');
    }
    cachedAccessToken = credential.accessToken;
    return { user: result.user, accessToken: cachedAccessToken };
  } catch (error: any) {
    console.error('Google Drive Sign-in error:', error);
    throw error;
  } finally {
    isSigningIn = false;
  }
};

/**
 * Signs out from Google and clears in-memory cached token.
 */
export const googleSignOut = async (): Promise<void> => {
  try {
    await signOut(auth);
  } finally {
    cachedAccessToken = null;
  }
};

/**
 * Returns current in-memory access token.
 */
export const getDriveAccessToken = (): string | null => {
  return cachedAccessToken;
};

/**
 * Sets current in-memory access token (used after sign-in).
 */
export const setDriveAccessToken = (token: string | null) => {
  cachedAccessToken = token;
};

/**
 * Returns current Firebase Google user.
 */
export const getDriveUser = (): FirebaseUser | null => {
  return auth.currentUser;
};

/**
 * Finds or creates dedicated application folder on Google Drive.
 */
export const getOrCreateBackupFolder = async (accessToken: string): Promise<string> => {
  const folderName = 'نسخ_دفتر_الديون_والأقساط';
  try {
    const query = `mimeType = 'application/vnd.google-apps.folder' and name = '${folderName}' and trashed = false`;
    const listUrl = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(query)}&fields=files(id,name)`;

    const listRes = await fetch(listUrl, {
      headers: { Authorization: `Bearer ${accessToken}` },
    });

    if (listRes.ok) {
      const listData = await listRes.json();
      if (listData.files && listData.files.length > 0) {
        return listData.files[0].id;
      }
    }

    // Create the folder
    const createRes = await fetch('https://www.googleapis.com/drive/v3/files', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: folderName,
        mimeType: 'application/vnd.google-apps.folder',
        description: 'مجلد النسخ الاحتياطية لتطبيق دفتر الديون والأقساط والموردين',
      }),
    });

    if (createRes.ok) {
      const newFolder = await createRes.json();
      return newFolder.id || 'root';
    }
  } catch (e) {
    console.warn('Could not ensure dedicated folder, fallback to root:', e);
  }
  return 'root';
};

/**
 * Uploads a complete backup payload to Google Drive using multipart upload.
 */
export const uploadBackupToGoogleDrive = async (
  accessToken: string,
  fileName: string,
  jsonString: string,
  description?: string
): Promise<GoogleDriveFile> => {
  const folderId = await getOrCreateBackupFolder(accessToken);
  const boundary = '-------aldion_drive_boundary_' + Date.now();
  const delimiter = `\r\n--${boundary}\r\n`;
  const closeDelimiter = `\r\n--${boundary}--`;

  const metadata = {
    name: fileName,
    mimeType: 'application/json',
    description: description || 'نسخة احتياطية شاملة لكافة الأنظمة والصور المرفقة',
    parents: folderId && folderId !== 'root' ? [folderId] : undefined,
  };

  const multipartRequestBody =
    delimiter +
    'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
    JSON.stringify(metadata) +
    delimiter +
    'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
    jsonString +
    closeDelimiter;

  const res = await fetch(
    'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,size,createdTime,modifiedTime,webViewLink,description',
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': `multipart/related; boundary=${boundary}`,
      },
      body: multipartRequestBody,
    }
  );

  if (!res.ok) {
    const errorText = await res.text();
    throw new Error(`فشل رفع النسخة الاحتياطية إلى Google Drive: ${errorText}`);
  }

  return await res.json();
};

/**
 * Lists all backup JSON files stored on Google Drive.
 */
export const listDriveBackups = async (accessToken: string): Promise<GoogleDriveFile[]> => {
  const query = `(name contains 'backup_' or name contains '.json' or mimeType = 'application/json') and trashed = false`;
  const url = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(
    query
  )}&fields=files(id,name,size,createdTime,modifiedTime,webViewLink,description)&orderBy=createdTime desc&pageSize=50`;

  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`تعذر استعراض النسخ من Google Drive: ${errText}`);
  }

  const data = await res.json();
  return data.files || [];
};

/**
 * Downloads the full backup payload JSON from Google Drive.
 */
export const downloadDriveBackupContent = async (
  accessToken: string,
  fileId: string
): Promise<any> => {
  const url = `https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`;
  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`تعذر تنزيل ملف النسخة الاحتياطية من Google Drive: ${errText}`);
  }

  const jsonText = await res.text();
  try {
    return JSON.parse(jsonText);
  } catch (e) {
    throw new Error('الملف الذي تم تنزيله ليس بصيغة JSON صالحة');
  }
};

/**
 * Deletes a backup file from Google Drive.
 */
export const deleteDriveBackupFile = async (
  accessToken: string,
  fileId: string
): Promise<boolean> => {
  const url = `https://www.googleapis.com/drive/v3/files/${fileId}`;
  const res = await fetch(url, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${accessToken}` },
  });

  if (!res.ok && res.status !== 204) {
    const errText = await res.text();
    throw new Error(`تعذر حذف الملف من Google Drive: ${errText}`);
  }

  return true;
};
