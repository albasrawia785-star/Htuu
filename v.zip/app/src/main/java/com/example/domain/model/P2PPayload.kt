package com.example.domain.model

import com.squareup.moshi.JsonClass

enum class PacketType {
    ANNOUNCE,
    CHAT_REQUEST,
    CHAT_RESPONSE,
    TEXT_MESSAGE,
    MEDIA_MESSAGE,
    TYPING_STATUS,
    MESSAGE_ACK,
    READ_RECEIPT,
    CALL_REQUEST,
    CALL_ACCEPT,
    CALL_REJECT,
    CALL_END
}

@JsonClass(generateAdapter = true)
data class NetworkPacket(
    val packetType: PacketType,
    val senderDeviceId: String,
    val senderName: String,
    val senderIp: String = "",
    val messageId: String = "",
    val textContent: String = "",
    val mediaType: String = "", // TEXT, IMAGE, AUDIO, FILE
    val mediaFileName: String = "",
    val mediaFileSize: Long = 0L,
    val mediaDataBase64: String = "", // Base64 chunk or payload for small files/images/audio
    val audioDurationMs: Long = 0L,
    val isTyping: Boolean = false,
    val isAccepted: Boolean = false,
    val timestamp: Long = System.currentTimeMillis(),
    val senderAvatarBase64: String = ""
)
