package com.example.data.network

import android.content.Context
import android.util.Base64
import android.util.Log
import androidx.room.withTransaction
import com.example.data.local.db.AppDatabase
import com.example.data.local.db.entity.ChatRequestEntity
import com.example.data.local.db.entity.ConversationEntity
import com.example.data.local.db.entity.MessageEntity
import com.example.data.local.preferences.UserPreferences
import com.example.data.local.storage.FileManager
import com.example.data.logging.ErrorLogger
import com.example.data.notification.NotificationHelper
import com.example.domain.model.DiscoveredDevice
import com.example.domain.model.MessageStatus
import com.example.domain.model.MessageType
import com.example.domain.model.NetworkPacket
import com.example.domain.model.PacketType
import com.example.domain.model.RequestStatus
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.io.PrintWriter
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.Collections
import java.util.UUID

class P2PNetworkManager(
    private val context: Context,
    private val db: AppDatabase,
    private val userPrefs: UserPreferences,
    private val fileManager: FileManager,
    private val notificationHelper: NotificationHelper
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
    private val adapter = moshi.adapter(NetworkPacket::class.java)

    private val _discoveredDevices = MutableStateFlow<List<DiscoveredDevice>>(emptyList())
    val discoveredDevices: StateFlow<List<DiscoveredDevice>> = _discoveredDevices.asStateFlow()

    private val _typingStatus = MutableStateFlow<Map<String, Boolean>>(emptyMap())
    val typingStatus: StateFlow<Map<String, Boolean>> = _typingStatus.asStateFlow()

    private val deviceListLock = Any()
    private val processingRequestIds = Collections.synchronizedSet(mutableSetOf<String>())

    @Volatile
    private var isRunning = false

    private var udpSocket: DatagramSocket? = null
    private var tcpServerSocket: ServerSocket? = null

    companion object {
        const val UDP_PORT = 8888
        const val TCP_PORT = 8889
        private const val TAG = "P2PNetworkManager"

        @Volatile
        private var INSTANCE: P2PNetworkManager? = null

        fun getInstance(context: Context): P2PNetworkManager {
            return INSTANCE ?: synchronized(this) {
                val appCtx = context.applicationContext
                val db = AppDatabase.getDatabase(appCtx)
                val userPrefs = UserPreferences(appCtx)
                val fileManager = FileManager(appCtx)
                val notificationHelper = NotificationHelper(appCtx)
                INSTANCE ?: P2PNetworkManager(appCtx, db, userPrefs, fileManager, notificationHelper).also {
                    INSTANCE = it
                }
            }
        }
    }

    fun isEngineActive(): Boolean = isRunning

    val isUdpActive: Boolean
        get() = udpSocket?.isBound == true && !udpSocket!!.isClosed

    val isTcpActive: Boolean
        get() = tcpServerSocket?.isBound == true && !tcpServerSocket!!.isClosed

    fun startEngine() {
        if (isRunning) return
        isRunning = true
        Log.i(TAG, "Starting P2P Network Engine...")

        startUdpBroadcaster()
        startUdpListener()
        startTcpServer()
        startDeviceHeartbeatChecker()
    }

    fun stopEngine() {
        isRunning = false
        Log.i(TAG, "Stopping P2P Network Engine...")
        try {
            udpSocket?.close()
            udpSocket = null
        } catch (e: Exception) {
            Log.e(TAG, "Error closing UDP socket", e)
        }
        try {
            tcpServerSocket?.close()
            tcpServerSocket = null
        } catch (e: Exception) {
            Log.e(TAG, "Error closing TCP server socket", e)
        }
    }

    /**
     * Periodically broadcasts UDP announcement packet to discover peers on LAN/Hotspot.
     */
    private fun startUdpBroadcaster() {
        scope.launch {
            while (isRunning) {
                try {
                    val myIp = getLocalIpAddress() ?: "127.0.0.1"
                    val packet = NetworkPacket(
                        packetType = PacketType.ANNOUNCE,
                        senderDeviceId = userPrefs.deviceId,
                        senderName = userPrefs.getDeviceName(),
                        senderIp = myIp,
                        senderAvatarBase64 = userPrefs.getUserAvatarBase64()
                    )
                    val json = adapter.toJson(packet)
                    val bytes = json.toByteArray(Charsets.UTF_8)

                    val broadcastAddress = getBroadcastAddress() ?: InetAddress.getByName("255.255.255.255")
                    DatagramSocket().use { socket ->
                        socket.broadcast = true
                        val datagramPacket = DatagramPacket(bytes, bytes.size, broadcastAddress, UDP_PORT)
                        socket.send(datagramPacket)
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "UDP Broadcaster error", e)
                }
                delay(2000)
            }
        }
    }

    /**
     * Immediately sends a UDP announcement packet to notify network peers of updated device info (e.g. device name or avatar change).
     */
    fun broadcastPresenceNow() {
        scope.launch(Dispatchers.IO) {
            try {
                val myIp = getLocalIpAddress() ?: "127.0.0.1"
                val packet = NetworkPacket(
                    packetType = PacketType.ANNOUNCE,
                    senderDeviceId = userPrefs.deviceId,
                    senderName = userPrefs.getDeviceName(),
                    senderIp = myIp,
                    senderAvatarBase64 = userPrefs.getUserAvatarBase64()
                )
                val json = adapter.toJson(packet)
                val bytes = json.toByteArray(Charsets.UTF_8)

                val broadcastAddress = getBroadcastAddress() ?: InetAddress.getByName("255.255.255.255")
                DatagramSocket().use { socket ->
                    socket.broadcast = true
                    val datagramPacket = DatagramPacket(bytes, bytes.size, broadcastAddress, UDP_PORT)
                    socket.send(datagramPacket)
                }
                Log.d(TAG, "Immediate presence broadcast sent with device name: ${userPrefs.getDeviceName()}")
            } catch (e: Exception) {
                Log.e(TAG, "Error in broadcastPresenceNow", e)
            }
        }
    }

    /**
     * Listens for incoming UDP packets from other devices on port 8888.
     */
    private fun startUdpListener() {
        scope.launch {
            try {
                udpSocket = DatagramSocket(null).apply {
                    reuseAddress = true
                    bind(InetSocketAddress(UDP_PORT))
                    broadcast = true
                }
                val buffer = ByteArray(16384)

                while (isRunning) {
                    try {
                        val packet = DatagramPacket(buffer, buffer.size)
                        udpSocket?.receive(packet)
                        if (!isRunning) break

                        val json = String(packet.data, 0, packet.length, Charsets.UTF_8).trim()
                        if (json.isNotEmpty()) {
                            val networkPacket = try { adapter.fromJson(json) } catch (e: Exception) { null }
                            if (networkPacket != null &&
                                networkPacket.senderDeviceId.isNotBlank() &&
                                networkPacket.senderDeviceId != userPrefs.deviceId
                            ) {
                                val peerIp = packet.address?.hostAddress ?: networkPacket.senderIp
                                if (peerIp.isNotBlank()) {
                                    val discovered = DiscoveredDevice(
                                        deviceId = networkPacket.senderDeviceId,
                                        deviceName = networkPacket.senderName,
                                        ipAddress = peerIp,
                                        port = TCP_PORT,
                                        lastSeenTimestamp = System.currentTimeMillis(),
                                        isOnline = true,
                                        avatarBase64 = networkPacket.senderAvatarBase64
                                    )
                                    updateDiscoveredDevice(discovered)
                                }
                            }
                        }
                    } catch (e: Exception) {
                        if (isRunning) {
                            Log.e(TAG, "Error in UDP receive loop", e)
                            delay(500)
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Fatal UDP Listener binding error", e)
            }
        }
    }

    private fun updateDiscoveredDevice(device: DiscoveredDevice) {
        synchronized(deviceListLock) {
            val currentList = _discoveredDevices.value.toMutableList()
            val index = currentList.indexOfFirst { it.deviceId == device.deviceId }
            if (index >= 0) {
                currentList[index] = device
            } else {
                currentList.add(device)
            }
            _discoveredDevices.value = currentList
        }

        // Also update IP in DB if conversation exists
        scope.launch {
            try {
                if (device.deviceId.isNotBlank() && device.ipAddress.isNotBlank()) {
                    db.conversationDao().updateTargetIp(device.deviceId, device.ipAddress)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error updating target IP in database", e)
            }
        }
    }

    /**
     * Periodically checks device heartbeats and marks devices offline if not seen for > 6s.
     */
    private fun startDeviceHeartbeatChecker() {
        scope.launch {
            while (isRunning) {
                delay(3000)
                try {
                    val now = System.currentTimeMillis()
                    synchronized(deviceListLock) {
                        val updatedList = _discoveredDevices.value.map { device ->
                            if (now - device.lastSeenTimestamp > 6000) {
                                device.copy(isOnline = false)
                            } else {
                                device
                            }
                        }
                        _discoveredDevices.value = updatedList
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error in device heartbeat checker", e)
                }
            }
        }
    }

    /**
     * Starts TCP Server Socket to accept chat requests, messages, files, and typing status.
     */
    private fun startTcpServer() {
        scope.launch {
            try {
                tcpServerSocket = ServerSocket().apply {
                    reuseAddress = true
                    bind(InetSocketAddress(TCP_PORT))
                }
                Log.i(TAG, "TCP Server started successfully on port $TCP_PORT")

                while (isRunning) {
                    try {
                        val clientSocket = tcpServerSocket?.accept() ?: break
                        scope.launch { handleClientSocket(clientSocket) }
                    } catch (e: Exception) {
                        if (isRunning) {
                            Log.e(TAG, "TCP Server accept error", e)
                            delay(500)
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Fatal TCP Server error", e)
            }
        }
    }

    private suspend fun handleClientSocket(socket: Socket) {
        withContext(Dispatchers.IO) {
            try {
                socket.soTimeout = 10000
                val reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.UTF_8))
                val json = reader.readLine()
                if (!json.isNull_or_blank()) {
                    val packet = adapter.fromJson(json)
                    if (packet != null) {
                        val peerIp = socket.inetAddress?.hostAddress ?: ""
                        processIncomingPacket(packet, peerIp)
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error handling client socket", e)
            } finally {
                try { socket.close() } catch (e: Exception) { Log.e(TAG, "Error closing client socket", e) }
            }
        }
    }

    private fun String?.isNull_or_blank(): Boolean {
        return this == null || this.trim().isEmpty()
    }

    private suspend fun processIncomingPacket(packet: NetworkPacket, senderIp: String) {
        try {
            val resolvedIp = senderIp.ifEmpty { packet.senderIp }
            when (packet.packetType) {
                PacketType.CHAT_REQUEST -> {
                    if (packet.senderDeviceId.isBlank()) return
                    db.withTransaction {
                        val requestEntity = ChatRequestEntity(
                            requestId = if (packet.messageId.isNotBlank()) packet.messageId else UUID.randomUUID().toString(),
                            senderDeviceId = packet.senderDeviceId,
                            senderName = packet.senderName,
                            senderIp = resolvedIp,
                            timestamp = packet.timestamp,
                            status = RequestStatus.PENDING
                        )
                        db.chatRequestDao().insertOrUpdateRequest(requestEntity)
                    }
                    notificationHelper.showChatRequestNotification(packet.senderName)
                }

                PacketType.CHAT_RESPONSE -> {
                    if (packet.senderDeviceId.isBlank()) return
                    db.withTransaction {
                        if (packet.isAccepted) {
                            val conversation = db.conversationDao().getConversationByDeviceId(packet.senderDeviceId)
                            if (conversation != null) {
                                db.conversationDao().updateAcceptedStatus(packet.senderDeviceId, true)
                                if (resolvedIp.isNotBlank()) {
                                    db.conversationDao().updateTargetIp(packet.senderDeviceId, resolvedIp)
                                }
                            } else {
                                val newConversation = ConversationEntity(
                                    targetDeviceId = packet.senderDeviceId,
                                    targetDeviceName = packet.senderName,
                                    targetIpAddress = resolvedIp,
                                    lastMessage = "تم قبول طلب المراسلة",
                                    lastMessageTimestamp = System.currentTimeMillis(),
                                    unreadCount = 0,
                                    isAccepted = true
                                )
                                db.conversationDao().insertOrUpdateConversation(newConversation)
                            }
                        }
                    }
                }

                PacketType.TEXT_MESSAGE -> {
                    if (packet.senderDeviceId.isBlank()) return
                    val msgId = if (packet.messageId.isNotBlank()) packet.messageId else UUID.randomUUID().toString()
                    db.withTransaction {
                        val conversation = db.conversationDao().getConversationByDeviceId(packet.senderDeviceId)
                        val convEntity = conversation ?: ConversationEntity(
                            targetDeviceId = packet.senderDeviceId,
                            targetDeviceName = packet.senderName,
                            targetIpAddress = resolvedIp,
                            lastMessage = packet.textContent,
                            lastMessageTimestamp = packet.timestamp,
                            unreadCount = 0,
                            isAccepted = true
                        )
                        db.conversationDao().insertOrUpdateConversation(convEntity)

                        val msgEntity = MessageEntity(
                            id = msgId,
                            conversationId = packet.senderDeviceId,
                            senderDeviceId = packet.senderDeviceId,
                            senderName = packet.senderName,
                            isFromMe = false,
                            type = MessageType.TEXT,
                            textContent = packet.textContent,
                            filePath = null,
                            fileName = null,
                            fileSize = 0L,
                            audioDurationMs = 0L,
                            timestamp = packet.timestamp,
                            status = MessageStatus.DELIVERED
                        )
                        db.messageDao().insertMessage(msgEntity)
                        db.conversationDao().updateLastMessage(packet.senderDeviceId, packet.textContent, packet.timestamp)
                        db.conversationDao().incrementUnreadCount(packet.senderDeviceId)
                    }

                    sendDeliveryAck(msgId, packet.senderDeviceId, resolvedIp)
                    notificationHelper.showNewMessageNotification(packet.senderName, packet.textContent)
                }

                PacketType.MEDIA_MESSAGE -> {
                    if (packet.senderDeviceId.isBlank()) return
                    val msgId = if (packet.messageId.isNotBlank()) packet.messageId else UUID.randomUUID().toString()
                    var localFilePath: String? = null
                    if (packet.mediaDataBase64.isNotBlank()) {
                        try {
                            val bytes = Base64.decode(packet.mediaDataBase64, Base64.DEFAULT)
                            localFilePath = fileManager.saveBytesToInternalStorage(
                                fileName = if (packet.mediaFileName.isNotBlank()) packet.mediaFileName else "file_${System.currentTimeMillis()}",
                                bytes = bytes
                            )
                        } catch (e: Exception) {
                            Log.e(TAG, "Error decoding media Base64", e)
                        }
                    }

                    val msgType = when (packet.mediaType) {
                        "IMAGE" -> MessageType.IMAGE
                        "AUDIO" -> MessageType.AUDIO
                        else -> MessageType.FILE
                    }

                    val preview = getMediaTextPreview(msgType, packet.mediaFileName)

                    db.withTransaction {
                        val conversation = db.conversationDao().getConversationByDeviceId(packet.senderDeviceId)
                        val convEntity = conversation ?: ConversationEntity(
                            targetDeviceId = packet.senderDeviceId,
                            targetDeviceName = packet.senderName,
                            targetIpAddress = resolvedIp,
                            lastMessage = preview,
                            lastMessageTimestamp = packet.timestamp,
                            unreadCount = 0,
                            isAccepted = true
                        )
                        db.conversationDao().insertOrUpdateConversation(convEntity)

                        val msgEntity = MessageEntity(
                            id = msgId,
                            conversationId = packet.senderDeviceId,
                            senderDeviceId = packet.senderDeviceId,
                            senderName = packet.senderName,
                            isFromMe = false,
                            type = msgType,
                            textContent = packet.textContent,
                            filePath = localFilePath,
                            fileName = packet.mediaFileName,
                            fileSize = packet.mediaFileSize,
                            audioDurationMs = packet.audioDurationMs,
                            timestamp = packet.timestamp,
                            status = MessageStatus.DELIVERED
                        )
                        db.messageDao().insertMessage(msgEntity)
                        db.conversationDao().updateLastMessage(packet.senderDeviceId, preview, packet.timestamp)
                        db.conversationDao().incrementUnreadCount(packet.senderDeviceId)
                    }

                    sendDeliveryAck(msgId, packet.senderDeviceId, resolvedIp)
                    notificationHelper.showNewMessageNotification(packet.senderName, preview)
                }

                PacketType.TYPING_STATUS -> {
                    if (packet.senderDeviceId.isNotBlank()) {
                        val map = _typingStatus.value.toMutableMap()
                        map[packet.senderDeviceId] = packet.isTyping
                        _typingStatus.value = map
                    }
                }

                PacketType.MESSAGE_ACK -> {
                    val newStatus = if (packet.textContent == "READ") MessageStatus.READ else MessageStatus.DELIVERED
                    if (packet.messageId.isNotBlank()) {
                        db.messageDao().updateMessageStatus(packet.messageId, newStatus)
                    } else if (packet.senderDeviceId.isNotBlank()) {
                        db.messageDao().updateOutgoingMessagesStatus(packet.senderDeviceId, newStatus)
                    }
                }

                PacketType.READ_RECEIPT -> {
                    if (packet.messageId.isNotBlank()) {
                        db.messageDao().updateMessageStatus(packet.messageId, MessageStatus.READ)
                    }
                    if (packet.senderDeviceId.isNotBlank()) {
                        db.messageDao().updateOutgoingMessagesStatus(packet.senderDeviceId, MessageStatus.READ)
                    }
                }

                PacketType.CALL_REQUEST -> {
                    if (packet.senderDeviceId.isNotBlank()) {
                        VoiceCallManager.getInstance(context).receiveIncomingCall(
                            senderDeviceId = packet.senderDeviceId,
                            senderName = packet.senderName,
                            senderIp = resolvedIp
                        )
                        notificationHelper.showNewMessageNotification(packet.senderName, "📞 مكالمة صوتية واردة...")
                    }
                }

                PacketType.CALL_ACCEPT -> {
                    VoiceCallManager.getInstance(context).onCallAcceptedByPeer()
                }

                PacketType.CALL_REJECT -> {
                    VoiceCallManager.getInstance(context).onCallEndedByPeer()
                }

                PacketType.CALL_END -> {
                    VoiceCallManager.getInstance(context).onCallEndedByPeer()
                }

                else -> {}
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error processing packet type ${packet.packetType}", e)
        }
    }

    private fun getMediaTextPreview(type: MessageType, fileName: String): String {
        return when (type) {
            MessageType.IMAGE -> "صورة"
            MessageType.AUDIO -> "تسجيل صوتي"
            MessageType.FILE -> "ملف: $fileName"
            MessageType.TEXT -> ""
        }
    }

    // ================= CLIENT ACTIONS =================

    fun sendChatRequest(targetDevice: DiscoveredDevice) {
        scope.launch(Dispatchers.IO) {
            try {
                val packet = NetworkPacket(
                    packetType = PacketType.CHAT_REQUEST,
                    senderDeviceId = userPrefs.deviceId,
                    senderName = userPrefs.getDeviceName(),
                    senderIp = getLocalIpAddress() ?: "",
                    messageId = UUID.randomUUID().toString()
                )
                sendPacketOverTcp(targetDevice.ipAddress, packet)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to send chat request to ${targetDevice.ipAddress}", e)
            }
        }
    }

    /**
     * Responds to a Chat Request atomically.
     * Returns true if request processing and session creation succeeded.
     */
    suspend fun respondToChatRequest(request: ChatRequestEntity, accept: Boolean): Boolean {
        Log.i(TAG, "Accept Button Clicked: senderDeviceId=${request.senderDeviceId}, requestId=${request.requestId}, accept=$accept")

        if (!processingRequestIds.add(request.requestId)) {
            Log.w(TAG, "[P2P] Request ${request.requestId} is already being processed.")
            return false
        }

        return withContext(Dispatchers.IO) {
            try {
                if (request.senderDeviceId.isBlank()) {
                    Log.e(TAG, "[P2P] Validation Failed: senderDeviceId is blank")
                    return@withContext false
                }

                var targetIp = request.senderIp
                if (targetIp.isBlank()) {
                    synchronized(deviceListLock) {
                        targetIp = _discoveredDevices.value.find { it.deviceId == request.senderDeviceId }?.ipAddress ?: ""
                    }
                }

                Log.i(TAG, "Connection Validated: targetIp=$targetIp for device=${request.senderDeviceId}")

                if (accept && targetIp.isBlank()) {
                    Log.e(TAG, "[P2P] Connection Validation Failed: Target IP is blank for device ${request.senderDeviceId}")
                    return@withContext false
                }

                Log.i(TAG, "Updating Request: ${request.requestId}")
                Log.i(TAG, "Creating Conversation for device: ${request.senderDeviceId}")
                Log.i(TAG, "Saving Conversation to Room Database")

                db.withTransaction {
                    db.chatRequestDao().updateRequestStatus(
                        request.requestId,
                        if (accept) RequestStatus.ACCEPTED else RequestStatus.DECLINED
                    )

                    if (accept) {
                        val conv = ConversationEntity(
                            targetDeviceId = request.senderDeviceId,
                            targetDeviceName = request.senderName.ifBlank { "مستخدم جديد" },
                            targetIpAddress = targetIp,
                            lastMessage = "بدأت المحادثة",
                            lastMessageTimestamp = System.currentTimeMillis(),
                            unreadCount = 0,
                            isAccepted = true
                        )
                        db.conversationDao().insertOrUpdateConversation(conv)
                    }
                }

                Log.i(TAG, "Conversation Saved")

                if (accept) {
                    Log.i(TAG, "Sending ACCEPT Packet to $targetIp")
                    val packet = NetworkPacket(
                        packetType = PacketType.CHAT_RESPONSE,
                        senderDeviceId = userPrefs.deviceId,
                        senderName = userPrefs.getDeviceName(),
                        senderIp = getLocalIpAddress() ?: "",
                        isAccepted = true
                    )
                    val tcpSuccess = sendPacketOverTcp(targetIp, packet)
                    if (!tcpSuccess) {
                        Log.w(TAG, "[P2P] TCP response transmission failed to $targetIp, but local session created")
                    }

                    val savedConversation = db.conversationDao().getConversationByDeviceId(request.senderDeviceId)
                    if (savedConversation != null && savedConversation.isAccepted) {
                        Log.i(TAG, "Session Created and Chat Created: successfully for ${request.senderDeviceId}")
                        return@withContext true
                    } else {
                        Log.e(TAG, "[P2P] Room Verification Failed: conversation entity not saved")
                        return@withContext false
                    }
                } else {
                    if (targetIp.isNotBlank()) {
                        Log.i(TAG, "[P2P] Sending decline TCP CHAT_RESPONSE to $targetIp")
                        val packet = NetworkPacket(
                            packetType = PacketType.CHAT_RESPONSE,
                            senderDeviceId = userPrefs.deviceId,
                            senderName = userPrefs.getDeviceName(),
                            senderIp = getLocalIpAddress() ?: "",
                            isAccepted = false
                        )
                        sendPacketOverTcp(targetIp, packet)
                    }
                    return@withContext true
                }
            } catch (e: Exception) {
                Log.e(TAG, "[P2P] Error in respondToChatRequest", e)
                ErrorLogger.log(
                    context = context,
                    throwable = e,
                    message = "Error in respondToChatRequest: ${e.localizedMessage}",
                    screenName = "P2PNetworkManager",
                    errorType = "CRITICAL",
                    connectionStatus = "Disconnected/Error",
                    ipAddress = request.senderIp
                )
                false
            } finally {
                processingRequestIds.remove(request.requestId)
            }
        }
    }

    fun sendTextMessage(targetDeviceId: String, targetIp: String, text: String, onCompleted: ((Boolean) -> Unit)? = null) {
        scope.launch(Dispatchers.IO) {
            try {
                val messageId = UUID.randomUUID().toString()
                val timestamp = System.currentTimeMillis()

                var resolvedIp = targetIp
                if (resolvedIp.isBlank()) {
                    synchronized(deviceListLock) {
                        resolvedIp = _discoveredDevices.value.find { it.deviceId == targetDeviceId }?.ipAddress ?: ""
                    }
                }

                db.withTransaction {
                    val existingConv = db.conversationDao().getConversationByDeviceId(targetDeviceId)
                    if (existingConv == null) {
                        val newConv = ConversationEntity(
                            targetDeviceId = targetDeviceId,
                            targetDeviceName = targetDeviceId,
                            targetIpAddress = resolvedIp,
                            lastMessage = text,
                            lastMessageTimestamp = timestamp,
                            unreadCount = 0,
                            isAccepted = true
                        )
                        db.conversationDao().insertOrUpdateConversation(newConv)
                    } else if (resolvedIp.isNotBlank()) {
                        db.conversationDao().updateTargetIp(targetDeviceId, resolvedIp)
                    }

                    val localMsg = MessageEntity(
                        id = messageId,
                        conversationId = targetDeviceId,
                        senderDeviceId = userPrefs.deviceId,
                        senderName = userPrefs.getDeviceName(),
                        isFromMe = true,
                        type = MessageType.TEXT,
                        textContent = text,
                        filePath = null,
                        fileName = null,
                        fileSize = 0L,
                        audioDurationMs = 0L,
                        timestamp = timestamp,
                        status = MessageStatus.SENT
                    )
                    db.messageDao().insertMessage(localMsg)
                    db.conversationDao().updateLastMessage(targetDeviceId, text, timestamp)
                }

                if (resolvedIp.isNotBlank()) {
                    val packet = NetworkPacket(
                        packetType = PacketType.TEXT_MESSAGE,
                        senderDeviceId = userPrefs.deviceId,
                        senderName = userPrefs.getDeviceName(),
                        senderIp = getLocalIpAddress() ?: "",
                        messageId = messageId,
                        textContent = text,
                        timestamp = timestamp
                    )
                    val success = sendPacketOverTcp(resolvedIp, packet)
                    if (success) {
                        db.messageDao().updateMessageStatus(messageId, MessageStatus.DELIVERED)
                    }
                    onCompleted?.invoke(success)
                } else {
                    Log.w(TAG, "Cannot send text message over TCP: blank target IP")
                    onCompleted?.invoke(false)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error sending text message", e)
                onCompleted?.invoke(false)
            }
        }
    }

    fun sendMediaMessage(
        targetDeviceId: String,
        targetIp: String,
        type: MessageType,
        file: File,
        fileName: String,
        audioDurationMs: Long = 0L,
        onCompleted: ((Boolean) -> Unit)? = null
    ) {
        scope.launch(Dispatchers.IO) {
            try {
                val messageId = UUID.randomUUID().toString()
                val timestamp = System.currentTimeMillis()
                val bytes = file.readBytes()
                val base64 = Base64.encodeToString(bytes, Base64.NO_WRAP)

                var resolvedIp = targetIp
                if (resolvedIp.isBlank()) {
                    synchronized(deviceListLock) {
                        resolvedIp = _discoveredDevices.value.find { it.deviceId == targetDeviceId }?.ipAddress ?: ""
                    }
                }

                val mediaTypeStr = when (type) {
                    MessageType.IMAGE -> "IMAGE"
                    MessageType.AUDIO -> "AUDIO"
                    else -> "FILE"
                }

                val previewText = getMediaTextPreview(type, fileName)

                db.withTransaction {
                    val existingConv = db.conversationDao().getConversationByDeviceId(targetDeviceId)
                    if (existingConv == null) {
                        val newConv = ConversationEntity(
                            targetDeviceId = targetDeviceId,
                            targetDeviceName = targetDeviceId,
                            targetIpAddress = resolvedIp,
                            lastMessage = previewText,
                            lastMessageTimestamp = timestamp,
                            unreadCount = 0,
                            isAccepted = true
                        )
                        db.conversationDao().insertOrUpdateConversation(newConv)
                    } else if (resolvedIp.isNotBlank()) {
                        db.conversationDao().updateTargetIp(targetDeviceId, resolvedIp)
                    }

                    val localMsg = MessageEntity(
                        id = messageId,
                        conversationId = targetDeviceId,
                        senderDeviceId = userPrefs.deviceId,
                        senderName = userPrefs.getDeviceName(),
                        isFromMe = true,
                        type = type,
                        textContent = "",
                        filePath = file.absolutePath,
                        fileName = fileName,
                        fileSize = file.length(),
                        audioDurationMs = audioDurationMs,
                        timestamp = timestamp,
                        status = MessageStatus.SENT
                    )
                    db.messageDao().insertMessage(localMsg)
                    db.conversationDao().updateLastMessage(
                        targetDeviceId,
                        previewText,
                        timestamp
                    )
                }

                if (resolvedIp.isNotBlank()) {
                    val packet = NetworkPacket(
                        packetType = PacketType.MEDIA_MESSAGE,
                        senderDeviceId = userPrefs.deviceId,
                        senderName = userPrefs.getDeviceName(),
                        senderIp = getLocalIpAddress() ?: "",
                        messageId = messageId,
                        mediaType = mediaTypeStr,
                        mediaFileName = fileName,
                        mediaFileSize = file.length(),
                        mediaDataBase64 = base64,
                        audioDurationMs = audioDurationMs,
                        timestamp = timestamp
                    )
                    val success = sendPacketOverTcp(resolvedIp, packet)
                    if (success) {
                        db.messageDao().updateMessageStatus(messageId, MessageStatus.DELIVERED)
                    }
                    onCompleted?.invoke(success)
                } else {
                    Log.w(TAG, "Cannot send media message over TCP: blank target IP")
                    onCompleted?.invoke(false)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error sending media message", e)
                onCompleted?.invoke(false)
            }
        }
    }

    fun sendDeliveryAck(messageId: String, targetDeviceId: String, targetIp: String) {
        if (targetIp.isBlank()) return
        scope.launch(Dispatchers.IO) {
            try {
                val packet = NetworkPacket(
                    packetType = PacketType.MESSAGE_ACK,
                    senderDeviceId = userPrefs.deviceId,
                    senderName = userPrefs.getDeviceName(),
                    messageId = messageId,
                    textContent = "DELIVERED"
                )
                sendPacketOverTcp(targetIp, packet)
            } catch (e: Exception) {
                Log.e(TAG, "Error sending delivery ACK for $messageId", e)
            }
        }
    }

    fun sendReadReceipt(targetDeviceId: String, targetIp: String, messageId: String = "") {
        if (targetDeviceId.isBlank()) return
        scope.launch(Dispatchers.IO) {
            try {
                var resolvedIp = targetIp
                if (resolvedIp.isBlank()) {
                    synchronized(deviceListLock) {
                        resolvedIp = _discoveredDevices.value.find { it.deviceId == targetDeviceId }?.ipAddress ?: ""
                    }
                }
                db.messageDao().updateIncomingMessagesStatus(targetDeviceId, MessageStatus.READ)
                db.conversationDao().clearUnreadCount(targetDeviceId)

                if (resolvedIp.isNotBlank()) {
                    val packet = NetworkPacket(
                        packetType = PacketType.READ_RECEIPT,
                        senderDeviceId = userPrefs.deviceId,
                        senderName = userPrefs.getDeviceName(),
                        messageId = messageId,
                        textContent = "READ"
                    )
                    sendPacketOverTcp(resolvedIp, packet)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error sending read receipt to $targetDeviceId", e)
            }
        }
    }

    fun sendTypingStatus(targetIp: String, isTyping: Boolean) {
        scope.launch(Dispatchers.IO) {
            try {
                val packet = NetworkPacket(
                    packetType = PacketType.TYPING_STATUS,
                    senderDeviceId = userPrefs.deviceId,
                    senderName = userPrefs.getDeviceName(),
                    isTyping = isTyping
                )
                sendPacketOverTcp(targetIp, packet)
            } catch (e: Exception) {
                Log.e(TAG, "Error sending typing status", e)
            }
        }
    }

    fun sendCallRequest(targetIp: String) {
        scope.launch(Dispatchers.IO) {
            try {
                val packet = NetworkPacket(
                    packetType = PacketType.CALL_REQUEST,
                    senderDeviceId = userPrefs.deviceId,
                    senderName = userPrefs.getDeviceName(),
                    senderIp = getLocalIpAddress() ?: ""
                )
                sendPacketOverTcp(targetIp, packet)
            } catch (e: Exception) {
                Log.e(TAG, "Error sending call request to $targetIp", e)
            }
        }
    }

    fun sendCallAccept(targetIp: String) {
        scope.launch(Dispatchers.IO) {
            try {
                val packet = NetworkPacket(
                    packetType = PacketType.CALL_ACCEPT,
                    senderDeviceId = userPrefs.deviceId,
                    senderName = userPrefs.getDeviceName()
                )
                sendPacketOverTcp(targetIp, packet)
            } catch (e: Exception) {
                Log.e(TAG, "Error sending call accept to $targetIp", e)
            }
        }
    }

    fun sendCallReject(targetIp: String) {
        scope.launch(Dispatchers.IO) {
            try {
                val packet = NetworkPacket(
                    packetType = PacketType.CALL_REJECT,
                    senderDeviceId = userPrefs.deviceId,
                    senderName = userPrefs.getDeviceName()
                )
                sendPacketOverTcp(targetIp, packet)
            } catch (e: Exception) {
                Log.e(TAG, "Error sending call reject to $targetIp", e)
            }
        }
    }

    fun sendCallEnd(targetIp: String) {
        scope.launch(Dispatchers.IO) {
            try {
                val packet = NetworkPacket(
                    packetType = PacketType.CALL_END,
                    senderDeviceId = userPrefs.deviceId,
                    senderName = userPrefs.getDeviceName()
                )
                sendPacketOverTcp(targetIp, packet)
            } catch (e: Exception) {
                Log.e(TAG, "Error sending call end to $targetIp", e)
            }
        }
    }

    private suspend fun sendPacketOverTcp(targetIp: String, packet: NetworkPacket): Boolean {
        if (targetIp.isBlank()) {
            Log.e(TAG, "Cannot send packet: targetIp is blank")
            return false
        }
        return withContext(Dispatchers.IO) {
            var socket: Socket? = null
            try {
                socket = Socket()
                socket.connect(InetSocketAddress(targetIp, TCP_PORT), 4000)
                socket.soTimeout = 4000
                val writer = PrintWriter(OutputStreamWriter(socket.getOutputStream(), Charsets.UTF_8), true)
                val json = adapter.toJson(packet)
                writer.println(json)
                writer.flush()
                true
            } catch (e: Exception) {
                Log.e(TAG, "Failed to send TCP packet type=${packet.packetType} to $targetIp:$TCP_PORT", e)
                false
            } finally {
                try { socket?.close() } catch (e: Exception) { Log.e(TAG, "Error closing TCP socket", e) }
            }
        }
    }

    // ================= NETWORK UTILS =================

    private fun getLocalIpAddress(): String? {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val networkInterface = interfaces.nextElement()
                if (networkInterface.isLoopback || !networkInterface.isUp) continue

                val addresses = networkInterface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val address = addresses.nextElement()
                    if (!address.isLoopbackAddress && address.hostAddress.indexOf(':') < 0) {
                        return address.hostAddress
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error getting local IP", e)
        }
        return null
    }

    private fun getBroadcastAddress(): InetAddress? {
        try {
            val myIp = getLocalIpAddress() ?: return null
            val parts = myIp.split(".")
            if (parts.size == 4) {
                val broadcastStr = "${parts[0]}.${parts[1]}.${parts[2]}.255"
                return InetAddress.getByName(broadcastStr)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error calculating broadcast address", e)
        }
        return InetAddress.getByName("255.255.255.255")
    }
}
