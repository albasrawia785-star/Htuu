import React, { useState, useEffect } from 'react';

export interface InvoiceImageViewerModalProps {
  isOpen: boolean;
  onClose: () => void;
  imageUrl?: string | null;
  title?: string;
  subtitle?: string;
  amountText?: string;
}

export const InvoiceImageViewerModal: React.FC<InvoiceImageViewerModalProps> = ({
  isOpen,
  onClose,
  imageUrl,
  title = 'صورة الفاتورة المرفقة',
  subtitle,
  amountText,
}) => {
  const [zoom, setZoom] = useState(1);
  const [rotation, setRotation] = useState(0);

  useEffect(() => {
    if (isOpen) {
      setZoom(1);
      setRotation(0);
    }
  }, [isOpen, imageUrl]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen || !imageUrl) return null;

  const handleZoomIn = () => setZoom((z) => Math.min(3, +(z + 0.25).toFixed(2)));
  const handleZoomOut = () => setZoom((z) => Math.max(0.5, +(z - 0.25).toFixed(2)));
  const handleReset = () => {
    setZoom(1);
    setRotation(0);
  };
  const handleRotate = () => setRotation((r) => (r + 90) % 360);

  const handleDownload = () => {
    try {
      const link = document.createElement('a');
      link.href = imageUrl;
      const cleanTitle = (title || 'فاتورة').replace(/[\s/\\?%*:|"<>]/g, '_');
      const ext = imageUrl.startsWith('data:image/webp') ? 'webp' : 'jpg';
      link.download = `${cleanTitle}_${Date.now()}.${ext}`;
      document.body.appendChild(link);
      link.click();
      setTimeout(() => {
        if (document.body.contains(link)) document.body.removeChild(link);
      }, 200);
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div
      className="fixed inset-0 z-[9999] bg-slate-950/90 backdrop-blur-md flex flex-col justify-between items-center select-none animate-in fade-in duration-200"
      onClick={onClose}
    >
      {/* Top Header Bar */}
      <div
        className="w-full max-w-4xl px-4 py-3 sm:py-4 flex items-center justify-between gap-3 text-white z-10"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-9 h-9 rounded-xl bg-blue-600/30 text-blue-400 border border-blue-500/40 flex items-center justify-center shrink-0">
            <i className="fa-solid fa-receipt text-sm"></i>
          </div>
          <div className="min-w-0">
            <h3 className="font-bold text-sm sm:text-base text-white truncate flex items-center gap-2">
              <span>{title}</span>
              {amountText && (
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-md bg-blue-500/20 text-blue-300 border border-blue-500/30">
                  {amountText}
                </span>
              )}
            </h3>
            {subtitle && (
              <p className="text-xs text-slate-400 truncate mt-0.5 font-mono" dir="auto">
                {subtitle}
              </p>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-1.5 shrink-0">
          <button
            type="button"
            onClick={handleDownload}
            className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
            title="تحميل الصورة بالجودة العالية"
          >
            <i className="fa-solid fa-download text-xs"></i>
            <span className="hidden sm:inline">تحميل</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
            title="إغلاق"
          >
            <i className="fa-solid fa-xmark text-sm"></i>
          </button>
        </div>
      </div>

      {/* Main Image Stage */}
      <div
        className="flex-1 w-full max-w-4xl p-2 sm:p-4 flex items-center justify-center overflow-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div
          className="transition-transform duration-200 ease-out flex items-center justify-center max-w-full max-h-[75vh]"
          style={{
            transform: `scale(${zoom}) rotate(${rotation}deg)`,
          }}
        >
          <img
            src={imageUrl}
            alt={title}
            className="max-w-full max-h-[75vh] object-contain rounded-2xl shadow-2xl border border-white/10 select-none pointer-events-auto"
            draggable={false}
          />
        </div>
      </div>

      {/* Floating Bottom Toolbar */}
      <div
        className="mb-4 sm:mb-6 px-4 py-2 bg-slate-900/90 border border-slate-700/80 rounded-2xl shadow-2xl flex items-center gap-2 text-white z-10 backdrop-blur-md"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          type="button"
          onClick={handleZoomOut}
          disabled={zoom <= 0.5}
          className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 flex items-center justify-center text-xs transition-colors cursor-pointer"
          title="تصغير"
        >
          <i className="fa-solid fa-magnifying-glass-minus"></i>
        </button>

        <span className="font-mono text-xs font-bold px-2 py-0.5 text-slate-300 min-w-[50px] text-center">
          {Math.round(zoom * 100)}%
        </span>

        <button
          type="button"
          onClick={handleZoomIn}
          disabled={zoom >= 3}
          className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 flex items-center justify-center text-xs transition-colors cursor-pointer"
          title="تكبير"
        >
          <i className="fa-solid fa-magnifying-glass-plus"></i>
        </button>

        <div className="w-px h-5 bg-slate-700 mx-1"></div>

        <button
          type="button"
          onClick={handleRotate}
          className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 flex items-center justify-center text-xs transition-colors cursor-pointer"
          title="تدوير 90 درجة"
        >
          <i className="fa-solid fa-rotate-right"></i>
        </button>

        <button
          type="button"
          onClick={handleReset}
          className="px-2.5 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer"
          title="إعادة الضبط"
        >
          <span>100%</span>
        </button>
      </div>
    </div>
  );
};
