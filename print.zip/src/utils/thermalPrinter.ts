import QRCode from 'qrcode';
import {
  ThermalPaperSize,
  ThermalFontSize,
  ThermalReceiptData,
  ThermalReceiptType,
  Debtor,
  InstallmentRecord,
  Supplier,
} from '../types';
export type { ThermalPaperSize, ThermalFontSize, ThermalReceiptData, ThermalReceiptType };
import { formatDateDigits, formatNumber } from './formatters';

// Storage key for paired/selected printer
const SAVED_PRINTER_KEY = 'aldion_thermal_bluetooth_printer';

export interface SavedPrinterInfo {
  name: string;
  id?: string;
  lastConnected?: string;
}

/**
 * Returns saved printer info from local storage
 */
export function getSavedBluetoothPrinter(): SavedPrinterInfo | null {
  try {
    const raw = localStorage.getItem(SAVED_PRINTER_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

/**
 * Saves selected Bluetooth printer info
 */
export function saveBluetoothPrinter(info: SavedPrinterInfo): void {
  try {
    localStorage.setItem(
      SAVED_PRINTER_KEY,
      JSON.stringify({ ...info, lastConnected: new Date().toISOString() })
    );
  } catch {}
}

/**
 * Clears saved printer
 */
export function clearSavedBluetoothPrinter(): void {
  try {
    localStorage.removeItem(SAVED_PRINTER_KEY);
  } catch {}
}

/**
 * Checks if Web Bluetooth API is supported in current environment
 */
export function isBluetoothSupported(): boolean {
  return typeof navigator !== 'undefined' && 'bluetooth' in navigator;
}

// Global active Bluetooth device reference for instant reconnection
let activeBluetoothDevice: any = null;
let activeGattServer: any = null;

/**
 * Checks connection state with saved printer
 */
export async function checkBluetoothStatus(): Promise<{
  supported: boolean;
  connected: boolean;
  deviceName?: string;
}> {
  if (!isBluetoothSupported()) {
    return { supported: false, connected: false };
  }
  const saved = getSavedBluetoothPrinter();
  const isConnected = Boolean(activeGattServer && activeGattServer.connected);
  return {
    supported: true,
    connected: isConnected,
    deviceName: saved?.name || activeBluetoothDevice?.name,
  };
}

/**
 * Retrieves list of already paired/authorized devices (without showing scan modal)
 */
export async function getPairedBluetoothPrinters(): Promise<{ name: string; id: string }[]> {
  if (!isBluetoothSupported()) return [];
  try {
    if (typeof (navigator as any).bluetooth.getDevices === 'function') {
      const devices = await (navigator as any).bluetooth.getDevices();
      return devices.map((d: any) => ({
        name: d.name || 'طابعة حرارية غير مسماة',
        id: d.id,
      }));
    }
  } catch (err) {
    console.warn('Could not list authorized bluetooth devices:', err);
  }
  return [];
}

// Common Bluetooth Thermal Printer Service & Characteristic UUIDs
const THERMAL_SERVICE_UUIDS = [
  '000018f0-0000-1000-8000-00805f9b34fb', // Standard POS Service
  '0000ffe0-0000-1000-8000-00805f9b34fb', // BLE Mini Thermal Printer
  '0000ff00-0000-1000-8000-00805f9b34fb', // Vendor SPP
  '49535343-fe7d-4ae5-8fa9-9fafd205e455', // ISSC Transparent
  'e7810a71-73ae-499d-8c15-faa9aef0c3f2', // RawBT service
];

/**
 * Requests pairing/selecting a Bluetooth printer from Android/browser dialog
 */
export async function requestPairBluetoothPrinter(): Promise<SavedPrinterInfo> {
  if (!isBluetoothSupported()) {
    throw new Error('ميزة البلوتوث غير مدعومة في هذا المتصفح أو بيئة التشغيل');
  }

  const device = await (navigator as any).bluetooth.requestDevice({
    acceptAllDevices: true,
    optionalServices: THERMAL_SERVICE_UUIDS,
  });

  if (!device) {
    throw new Error('لم يتم اختيار أي جهاز');
  }

  activeBluetoothDevice = device;
  const info: SavedPrinterInfo = {
    name: device.name || 'طابعة حرارية بلوتوث',
    id: device.id,
  };
  saveBluetoothPrinter(info);
  return info;
}

/**
 * Connects to printer GATT server and finds a writable characteristic
 */
async function getWritablePrinterCharacteristic(targetDevice?: any): Promise<any> {
  let device = targetDevice || activeBluetoothDevice;

  if (!device && isBluetoothSupported() && typeof (navigator as any).bluetooth.getDevices === 'function') {
    const saved = getSavedBluetoothPrinter();
    const authorized = await (navigator as any).bluetooth.getDevices();
    if (saved && saved.id) {
      device = authorized.find((d: any) => d.id === saved.id);
    }
    if (!device && authorized.length > 0) {
      device = authorized[0];
    }
  }

  if (!device) {
    // If no device cached or authorized, prompt user to pick their paired printer
    device = await (navigator as any).bluetooth.requestDevice({
      acceptAllDevices: true,
      optionalServices: THERMAL_SERVICE_UUIDS,
    });
    activeBluetoothDevice = device;
    saveBluetoothPrinter({ name: device.name || 'طابعة حرارية', id: device.id });
  }

  if (!device.gatt) {
    throw new Error('جهاز البلوتوث لا يدعم بروتوكول GATT');
  }

  let server = device.gatt;
  if (!server.connected) {
    server = await device.gatt.connect();
  }
  activeGattServer = server;

  // Search across primary services for a writable characteristic
  const services = await server.getPrimaryServices().catch(() => []);
  for (const service of services) {
    try {
      const characteristics = await service.getCharacteristics().catch(() => []);
      for (const char of characteristics) {
        if (
          char.properties &&
          (char.properties.write || char.properties.writeWithoutResponse)
        ) {
          return char;
        }
      }
    } catch {}
  }

  throw new Error('تعذر العثور على قناة كتابة متوافقة في طابعة البلوتوث');
}

/**
 * Sends binary ESC/POS data to Bluetooth printer in safe chunks
 */
export async function sendEscPosToBluetoothPrinter(
  data: Uint8Array,
  onProgress?: (percent: number) => void
): Promise<{ ok: boolean; message: string }> {
  try {
    const characteristic = await getWritablePrinterCharacteristic();
    const CHUNK_SIZE = 128; // Safe chunk size for BLE thermal buffers
    const total = data.length;

    for (let offset = 0; offset < total; offset += CHUNK_SIZE) {
      const chunk = data.subarray(offset, Math.min(offset + CHUNK_SIZE, total));
      if (characteristic.writeValueWithoutResponse) {
        await characteristic.writeValueWithoutResponse(chunk);
      } else {
        await characteristic.writeValue(chunk);
      }
      if (onProgress) {
        onProgress(Math.round(((offset + chunk.length) / total) * 100));
      }
      // Brief pause to allow thermal buffer to flush without dropping bytes
      await new Promise((r) => setTimeout(r, 12));
    }

    return { ok: true, message: 'تم إرسال أمر الطباعة بنجاح إلى الطابعة الحرارية!' };
  } catch (err: any) {
    console.warn('Bluetooth print failed, checking fallback:', err);
    throw err;
  }
}

// ----------------------------------------------------
// IMAGE / CANVAS RENDERING & BITMAP ESC/POS CONVERSION
// ----------------------------------------------------

/**
 * Draws a multi-line formatted Arabic text onto Canvas with word wrap
 */
function drawTextRTL(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  maxWidth: number,
  lineHeight: number,
  align: CanvasTextAlign = 'right'
): number {
  ctx.textAlign = align;
  const words = text.split(' ');
  let line = '';
  let currentY = y;

  for (let n = 0; n < words.length; n++) {
    const testLine = line ? `${line} ${words[n]}` : words[n];
    const metrics = ctx.measureText(testLine);
    if (metrics.width > maxWidth && n > 0) {
      ctx.fillText(line, x, currentY);
      line = words[n];
      currentY += lineHeight;
    } else {
      line = testLine;
    }
  }
  ctx.fillText(line, x, currentY);
  return currentY + lineHeight;
}

/**
 * Draws a dashed or solid horizontal divider line
 */
function drawDivider(
  ctx: CanvasRenderingContext2D,
  y: number,
  width: number,
  style: 'solid' | 'dashed' | 'double' = 'dashed'
) {
  ctx.save();
  ctx.strokeStyle = '#000000';
  ctx.lineWidth = style === 'double' ? 2 : 1;

  if (style === 'dashed') {
    ctx.setLineDash([6, 4]);
  } else {
    ctx.setLineDash([]);
  }

  ctx.beginPath();
  ctx.moveTo(12, y);
  ctx.lineTo(width - 12, y);
  ctx.stroke();

  if (style === 'double') {
    ctx.beginPath();
    ctx.moveTo(12, y + 4);
    ctx.lineTo(width - 12, y + 4);
    ctx.stroke();
  }

  ctx.restore();
}

/**
 * Renders the receipt into a high-contrast black-and-white Canvas image with Arabic typography
 */
export async function renderReceiptToCanvas(
  receipt: ThermalReceiptData,
  options: {
    paperSize?: ThermalPaperSize;
    fontSize?: ThermalFontSize;
  } = {}
): Promise<HTMLCanvasElement> {
  const paperSize = options.paperSize || '58mm';
  const fontSizeSetting = options.fontSize || 'medium';

  // 58mm = 384 pixels, 80mm = 576 pixels (multiples of 8)
  const canvasWidth = paperSize === '80mm' ? 576 : 384;
  const isLargePaper = paperSize === '80mm';

  // Font scale multipliers
  const scale =
    fontSizeSetting === 'small' ? 0.9 : fontSizeSetting === 'large' ? 1.15 : 1.0;

  const fontHeader = `bold ${Math.round((isLargePaper ? 28 : 22) * scale)}px 'Readex Pro', 'Tajawal', 'Cairo', sans-serif`;
  const fontTitle = `bold ${Math.round((isLargePaper ? 24 : 18) * scale)}px 'Readex Pro', 'Tajawal', 'Cairo', sans-serif`;
  const fontBodyBold = `bold ${Math.round((isLargePaper ? 20 : 15) * scale)}px 'Readex Pro', 'Tajawal', 'Cairo', sans-serif`;
  const fontBody = `normal ${Math.round((isLargePaper ? 18 : 14) * scale)}px 'Readex Pro', 'Tajawal', 'Cairo', sans-serif`;
  const fontAmount = `black ${Math.round((isLargePaper ? 28 : 22) * scale)}px 'Readex Pro', 'Tajawal', 'Cairo', sans-serif`;
  const fontFooter = `normal ${Math.round((isLargePaper ? 16 : 12) * scale)}px 'Readex Pro', 'Tajawal', 'Cairo', sans-serif`;

  // Estimate needed canvas height first
  let estimatedHeight = isLargePaper ? 850 : 720;
  if (receipt.qrCodeUrl) estimatedHeight += isLargePaper ? 220 : 180;
  if (receipt.notes) estimatedHeight += 60;
  if (receipt.guarantorName) estimatedHeight += 40;

  const canvas = document.createElement('canvas');
  canvas.width = canvasWidth;
  canvas.height = estimatedHeight;

  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) {
    throw new Error('فشل إنشاء محرك الرسم للوصل الحراري');
  }

  // Pure white background
  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  ctx.fillStyle = '#000000';
  ctx.textBaseline = 'top';
  ctx.direction = 'rtl';

  let y = 16;
  const paddingX = 16;
  const rightX = canvasWidth - paddingX;
  const leftX = paddingX;
  const centerX = canvasWidth / 2;

  // 1. Company Header / Branding
  const storeName = (receipt.companyName || 'دفتر الديون والأقساط').trim();
  ctx.font = fontHeader;
  ctx.textAlign = 'center';
  ctx.fillText(storeName, centerX, y);
  y += Math.round((isLargePaper ? 34 : 28) * scale);

  if (receipt.companyPhone) {
    ctx.font = fontBody;
    ctx.fillText(`هاتف: ${receipt.companyPhone}`, centerX, y);
    y += Math.round((isLargePaper ? 24 : 20) * scale);
  }

  if (receipt.companyAddress) {
    ctx.font = fontBody;
    ctx.fillText(receipt.companyAddress, centerX, y);
    y += Math.round((isLargePaper ? 24 : 20) * scale);
  }

  y += 4;
  drawDivider(ctx, y, canvasWidth, 'double');
  y += 14;

  // 2. Receipt Operation Title Badge (Inverted Black Box for Sharp Thermal Contrast)
  const titleBoxHeight = Math.round((isLargePaper ? 42 : 36) * scale);
  const titleBoxWidth = canvasWidth - paddingX * 2;
  ctx.fillStyle = '#000000';
  ctx.beginPath();
  ctx.roundRect(paddingX, y, titleBoxWidth, titleBoxHeight, 8);
  ctx.fill();

  ctx.fillStyle = '#FFFFFF';
  ctx.font = fontTitle;
  ctx.textAlign = 'center';
  ctx.fillText(receipt.title, centerX, y + (isLargePaper ? 8 : 6));
  y += titleBoxHeight + 12;

  ctx.fillStyle = '#000000';

  // 3. Receipt Metadata (ID, Date)
  ctx.font = fontBody;
  ctx.textAlign = 'right';
  ctx.fillText(`رقم الوصل: ${receipt.receiptId}`, rightX, y);
  ctx.textAlign = 'left';
  ctx.fillText(formatDateDigits(receipt.date || new Date().toISOString()), leftX, y);
  y += Math.round((isLargePaper ? 24 : 20) * scale);

  drawDivider(ctx, y, canvasWidth, 'dashed');
  y += 10;

  // 4. Customer / Entity Info Rows
  const drawRow = (label: string, value: string, isBoldValue = false) => {
    ctx.font = fontBody;
    ctx.textAlign = 'right';
    ctx.fillText(label, rightX, y);

    ctx.font = isBoldValue ? fontBodyBold : fontBody;
    ctx.textAlign = 'left';
    ctx.fillText(value, leftX, y);
    y += Math.round((isLargePaper ? 26 : 22) * scale);
  };

  drawRow('الاسم:', receipt.customerName, true);

  if (receipt.customerPhone) {
    drawRow('الهاتف:', receipt.customerPhone);
  }

  if (receipt.itemName) {
    drawRow('السلعة/المادة:', receipt.itemName, true);
  }

  if (receipt.guarantorName) {
    drawRow('الكفيل الضامن:', receipt.guarantorName);
  }

  if (receipt.nextDueDate) {
    drawRow('الاستحقاق القادم:', formatDateDigits(receipt.nextDueDate), true);
  }

  if (receipt.paymentMethod) {
    const methodLabel = receipt.paymentMethod === 'electronic' ? 'دفع إلكتروني (ماستر كارد)' : 'نقداً (كاش)';
    drawRow('طريقة الدفع:', methodLabel);
  }

  drawDivider(ctx, y, canvasWidth, 'dashed');
  y += 12;

  // 5. Financial Figures (Large & Crisp)
  const curr = 'د.ع';

  if (receipt.previousBalance !== undefined && receipt.previousBalance !== null) {
    drawRow('الرصيد السابق:', `${formatNumber(receipt.previousBalance)} ${curr}`);
  }

  // Active Transaction Amount Highlight
  const isPay = receipt.operationType.includes('pay');
  const amountLabel = isPay ? 'المبلغ المستلم (المسدد):' : 'المبلغ المضاف:';

  ctx.font = fontBodyBold;
  ctx.textAlign = 'right';
  ctx.fillText(amountLabel, rightX, y + 2);

  ctx.font = fontAmount;
  ctx.textAlign = 'left';
  ctx.fillText(`${formatNumber(receipt.amount)} ${curr}`, leftX, y);
  y += Math.round((isLargePaper ? 38 : 32) * scale);

  if (receipt.remainingBalance !== undefined && receipt.remainingBalance !== null) {
    ctx.font = fontBodyBold;
    ctx.textAlign = 'right';
    ctx.fillText('الرصيد المتبقي بذمته:', rightX, y);

    ctx.font = fontBodyBold;
    ctx.textAlign = 'left';
    ctx.fillText(`${formatNumber(receipt.remainingBalance)} ${curr}`, leftX, y);
    y += Math.round((isLargePaper ? 28 : 24) * scale);
  }

  if (receipt.notes && receipt.notes.trim()) {
    y += 4;
    ctx.font = fontBody;
    ctx.textAlign = 'right';
    ctx.fillText('ملاحظات:', rightX, y);
    y += 18;
    y = drawTextRTL(ctx, receipt.notes.trim(), rightX, y, canvasWidth - paddingX * 2, 20);
  }

  y += 6;
  drawDivider(ctx, y, canvasWidth, 'solid');
  y += 12;

  // 6. QR Code (Customer Statement Link)
  if (receipt.qrCodeUrl) {
    try {
      const qrDataUrl = await QRCode.toDataURL(receipt.qrCodeUrl, {
        width: isLargePaper ? 160 : 130,
        margin: 1,
        color: {
          dark: '#000000',
          light: '#FFFFFF',
        },
      });

      const qrImg = new Image();
      await new Promise<void>((resolve, reject) => {
        qrImg.onload = () => resolve();
        qrImg.onerror = reject;
        qrImg.src = qrDataUrl;
      });

      const qrSize = isLargePaper ? 160 : 130;
      ctx.drawImage(qrImg, centerX - qrSize / 2, y, qrSize, qrSize);
      y += qrSize + 6;

      ctx.font = fontFooter;
      ctx.textAlign = 'center';
      ctx.fillText('امسح الرمز أعلاه لمتابعة كشف الحساب المباشر', centerX, y);
      y += Math.round(20 * scale);
    } catch (qrErr) {
      console.warn('QR code generation on receipt canvas failed:', qrErr);
    }
  }

  // 7. Footer Notes
  ctx.font = fontFooter;
  ctx.textAlign = 'center';
  ctx.fillText('شكراً لتعاملكم معنا • يرجى الاحتفاظ بالوصل', centerX, y);
  y += Math.round(18 * scale);

  ctx.fillText('تطبيق دفتر الديون والأقساط الذكي', centerX, y);
  y += Math.round(30 * scale); // Bottom paper margin for clean tear-off

  // 8. Crop Canvas to exact computed height
  const finalCanvas = document.createElement('canvas');
  finalCanvas.width = canvasWidth;
  finalCanvas.height = Math.max(y, 100);
  const finalCtx = finalCanvas.getContext('2d');
  if (finalCtx) {
    finalCtx.fillStyle = '#FFFFFF';
    finalCtx.fillRect(0, 0, finalCanvas.width, finalCanvas.height);
    finalCtx.drawImage(canvas, 0, 0);
  }

  return finalCanvas;
}

/**
 * Converts a Canvas into 1-bit Monochrome ESC/POS Raster bit-image commands (GS v 0)
 */
export function canvasToEscPosRaster(canvas: HTMLCanvasElement): Uint8Array {
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Could not get canvas context');

  const width = canvas.width;
  const height = canvas.height;
  const imgData = ctx.getImageData(0, 0, width, height);
  const pixels = imgData.data;

  // Width in bytes (8 horizontal dots per byte)
  const widthBytes = Math.ceil(width / 8);
  const rasterDataSize = widthBytes * height;

  // ESC/POS Command: GS v 0 0 xL xH yL yH [rasterData...]
  // 0x1D, 0x76, 0x30, 0x00, xL, xH, yL, yH
  const xL = widthBytes & 0xff;
  const xH = (widthBytes >> 8) & 0xff;
  const yL = height & 0xff;
  const yH = (height >> 8) & 0xff;

  const header = [
    0x1b, 0x40, // ESC @ (Initialize printer)
    0x1b, 0x61, 0x01, // ESC a 1 (Center alignment)
    0x1d, 0x76, 0x30, 0x00, // GS v 0 0 (Raster bit image)
    xL, xH, yL, yH,
  ];

  const footer = [
    0x1b, 0x64, 0x04, // ESC d 4 (Feed 4 lines for tear bar)
    0x1d, 0x56, 0x42, 0x00, // GS V 66 0 (Partial cut if supported)
  ];

  const buffer = new Uint8Array(header.length + rasterDataSize + footer.length);
  buffer.set(header, 0);

  let byteOffset = header.length;
  const threshold = 160; // Luminance threshold for pure crisp black/white

  for (let row = 0; row < height; row++) {
    for (let colByte = 0; colByte < widthBytes; colByte++) {
      let byteVal = 0;
      for (let bit = 0; bit < 8; bit++) {
        const x = colByte * 8 + bit;
        if (x < width) {
          const pixelIndex = (row * width + x) * 4;
          const r = pixels[pixelIndex];
          const g = pixels[pixelIndex + 1];
          const b = pixels[pixelIndex + 2];
          const a = pixels[pixelIndex + 3];

          // Luminance formula
          const luminance = a < 128 ? 255 : 0.299 * r + 0.587 * g + 0.114 * b;
          if (luminance < threshold) {
            byteVal |= 1 << (7 - bit); // 1 = Black dot
          }
        }
      }
      buffer[byteOffset++] = byteVal;
    }
  }

  buffer.set(footer, byteOffset);
  return buffer;
}

/**
 * Triggers fallback printing using standard browser/Android print window
 */
export function printViaSystemDialog(canvas: HTMLCanvasElement): void {
  const dataUrl = canvas.toDataURL('image/png');
  const printWindow = window.open('', '_blank');
  if (!printWindow) {
    // If popups blocked, inject invisible iframe
    const iframe = document.createElement('iframe');
    iframe.style.position = 'fixed';
    iframe.style.right = '0';
    iframe.style.bottom = '0';
    iframe.style.width = '0';
    iframe.style.height = '0';
    iframe.style.border = 'none';
    document.body.appendChild(iframe);

    const doc = iframe.contentWindow?.document;
    if (doc) {
      doc.open();
      doc.write(`
        <!DOCTYPE html>
        <html>
          <head>
            <title>طباعة الوصل الحراري</title>
            <style>
              @page { size: auto; margin: 0; }
              body { margin: 0; padding: 0; display: flex; justify-content: center; }
              img { max-width: 100%; height: auto; }
            </style>
          </head>
          <body>
            <img src="${dataUrl}" onload="window.print(); setTimeout(() => parent.document.body.removeChild(frameElement), 1000);" />
          </body>
        </html>
      `);
      doc.close();
    }
    return;
  }

  printWindow.document.write(`
    <!DOCTYPE html>
    <html dir="rtl">
      <head>
        <meta charset="utf-8" />
        <title>طباعة الوصل الحراري</title>
        <style>
          @page { size: auto; margin: 0; }
          body { margin: 0; padding: 0; display: flex; justify-content: center; background: #fff; }
          img { max-width: 100%; height: auto; }
        </style>
      </head>
      <body>
        <img src="${dataUrl}" onload="window.print(); window.close();" />
      </body>
    </html>
  `);
  printWindow.document.close();
}

/**
 * Triggers RawBT Android Print Service intent (if installed on device)
 */
export function printViaRawBTIntent(data: Uint8Array): void {
  let binary = '';
  const len = data.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(data[i]);
  }
  const base64 = btoa(binary);
  const url = `rawbt:data:application/octet-stream;base64,${base64}`;
  window.location.href = url;
}

/**
 * High-level function: Renders and Prints a receipt directly to Bluetooth
 */
export async function printReceipt(
  receipt: ThermalReceiptData,
  options: {
    paperSize?: ThermalPaperSize;
    fontSize?: ThermalFontSize;
  } = {},
  onProgress?: (percent: number) => void
): Promise<{ ok: boolean; message: string; canvas: HTMLCanvasElement }> {
  // 1. Render receipt to Canvas image
  const canvas = await renderReceiptToCanvas(receipt, options);

  // 2. Convert to ESC/POS binary raster bytes
  const escPosBytes = canvasToEscPosRaster(canvas);

  // 3. Attempt direct Web Bluetooth send
  try {
    const res = await sendEscPosToBluetoothPrinter(escPosBytes, onProgress);
    return { ok: true, message: res.message, canvas };
  } catch (btErr: any) {
    console.warn('Direct Bluetooth failed or unavailable, using system print fallback:', btErr);
    // If user is on an Android APK where RawBT is present, or wants system printer:
    if (typeof window !== 'undefined' && /Android/i.test(navigator.userAgent)) {
      try {
        printViaRawBTIntent(escPosBytes);
        return { ok: true, message: 'تم تحويل أمر الطباعة لخدمة الطابعة الحرارية في أندرويد', canvas };
      } catch {}
    }

    // Default universal fallback: System Print
    printViaSystemDialog(canvas);
    return {
      ok: true,
      message: 'تم فتح نافذة الطباعة الحرارية لاختيار الطابعة المتصلة',
      canvas,
    };
  }
}

// ----------------------------------------------------
// RECEIPT BUILDER HELPERS FOR DEBTS, INSTALLMENTS, SUPPLIERS
// ----------------------------------------------------

export function createDebtorReceiptData(
  type: 'debt_add' | 'debt_pay' | 'debt_new',
  debtor: Debtor,
  amount: number,
  previousBalance: number,
  remainingBalance: number,
  companyInfo?: { name?: string; phone?: string; address?: string },
  qrUrl?: string,
  paymentMethod?: string,
  notes?: string
): ThermalReceiptData {
  const titles = {
    debt_add: 'إشعار إضافة دين',
    debt_pay: 'وصل تسديد وقبض دين',
    debt_new: 'وصل فتح حساب مدين جديد',
  };

  const idSuffix = Math.floor(1000 + Math.random() * 9000);
  return {
    receiptId: `#D-${debtor.id || idSuffix}`,
    operationType: type,
    title: titles[type],
    customerName: debtor.name,
    customerPhone: debtor.phone,
    amount,
    previousBalance,
    remainingBalance,
    date: new Date().toISOString(),
    notes: notes || debtor.notes,
    paymentMethod,
    companyName: companyInfo?.name,
    companyPhone: companyInfo?.phone,
    companyAddress: companyInfo?.address,
    qrCodeUrl: qrUrl,
  };
}

export function createInstallmentReceiptData(
  type: 'installment_new' | 'installment_pay',
  record: InstallmentRecord,
  amount: number,
  previousBalance: number,
  remainingBalance: number,
  companyInfo?: { name?: string; phone?: string; address?: string },
  qrUrl?: string,
  paymentMethod?: string,
  notes?: string
): ThermalReceiptData {
  const titles = {
    installment_new: 'وصل تسجيل بيع بالأقساط',
    installment_pay: 'وصل استلام دفعة قسط شهري',
  };

  return {
    receiptId: `#INS-${record.id}`,
    operationType: type,
    title: titles[type],
    customerName: record.name,
    customerPhone: record.phone,
    itemName: record.item,
    amount,
    previousBalance,
    remainingBalance,
    totalAmount: record.totalAmount,
    downPayment: record.downPayment,
    nextDueDate: record.nextDueDate,
    guarantorName: record.guarantorEnabled ? record.guarantorName : undefined,
    date: new Date().toISOString(),
    notes: notes || record.notes,
    paymentMethod,
    companyName: companyInfo?.name,
    companyPhone: companyInfo?.phone,
    companyAddress: companyInfo?.address,
    qrCodeUrl: qrUrl,
  };
}

export function createSupplierReceiptData(
  type: 'supplier_add_debt' | 'supplier_pay' | 'supplier_new',
  supplier: Supplier,
  amount: number,
  previousBalance: number,
  remainingBalance: number,
  companyInfo?: { name?: string; phone?: string; address?: string },
  paymentMethod?: string,
  notes?: string
): ThermalReceiptData {
  const titles = {
    supplier_add_debt: 'فاتورة بضاعة واردة من مورد',
    supplier_pay: 'سند صرف ودفع لمورد',
    supplier_new: 'سند تسجيل مورد وشركة جديدة',
  };

  return {
    receiptId: `#SUP-${supplier.id}`,
    operationType: type,
    title: titles[type],
    customerName: supplier.name,
    customerPhone: supplier.phone,
    itemName: supplier.itemType,
    amount,
    previousBalance,
    remainingBalance,
    date: new Date().toISOString(),
    notes: notes || supplier.notes,
    paymentMethod,
    companyName: companyInfo?.name,
    companyPhone: companyInfo?.phone,
    companyAddress: companyInfo?.address,
  };
}

export function createTestReceiptData(
  companyInfo?: { name?: string; phone?: string; address?: string }
): ThermalReceiptData {
  return {
    receiptId: `#TEST-${Math.floor(1000 + Math.random() * 9000)}`,
    operationType: 'test',
    title: 'وصل تجربة فحص الطابعة الحرارية',
    customerName: 'فحص جودة الطباعة العربية',
    customerPhone: '07XXXXXXXXX',
    itemName: 'اختبار وضوح الخط والباركود',
    amount: 50000,
    previousBalance: 150000,
    remainingBalance: 100000,
    date: new Date().toISOString(),
    notes: 'تمت الطباعة بنجاح وبدقة نقطية عالية عبر نظام البلوتوث.',
    paymentMethod: 'cash',
    companyName: companyInfo?.name || 'دفتر الديون والأقساط',
    companyPhone: companyInfo?.phone || '07700000000',
    companyAddress: companyInfo?.address || 'العراق - بغداد / البصرة',
    qrCodeUrl: 'https://aldion2-dafterappp.netlify.app',
  };
}
