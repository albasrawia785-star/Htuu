import React, { useState, useEffect } from 'react';
import { ThermalReceiptData, ThermalPaperSize, ThermalFontSize } from '../types';
import {
  printReceipt,
  checkBluetoothStatus,
  getSavedBluetoothPrinter,
  SavedPrinterInfo,
} from '../utils/thermalPrinter';
import { formatNumber, formatDateDigits } from '../utils/formatters';

interface ThermalPrintConfirmModalProps {
  receipt: ThermalReceiptData | null;
  isOpen: boolean;
  paperSize?: ThermalPaperSize;
  fontSize?: ThermalFontSize;
  onClose: () => void;
  onSuccess?: () => void;
  onShowToast?: (message: string, type: 'success' | 'error' | 'info') => void;
}

export const ThermalPrintConfirmModal: React.FC<ThermalPrintConfirmModalProps> = ({
  receipt,
  isOpen,
  paperSize = '58mm',
  fontSize = 'medium',
  onClose,
  onSuccess,
  onShowToast,
}) => {
  const [isPrinting, setIsPrinting] = useState(false);
  const [savedPrinter, setSavedPrinter] = useState<SavedPrinterInfo | null>(() => getSavedBluetoothPrinter());
  const [printerStatus, setPrinterStatus] = useState<{ connected: boolean; name?: string }>({
    connected: false,
  });

  useEffect(() => {
    if (isOpen) {
      const printer = getSavedBluetoothPrinter();
      setSavedPrinter(printer);
      checkBluetoothStatus().then((res) => {
        setPrinterStatus({ connected: res.connected, name: res.deviceName || printer?.name });
      });
    }
  }, [isOpen]);

  if (!isOpen || !receipt) return null;

  const handleConfirmPrint = async () => {
    try {
      setIsPrinting(true);
      const res = await printReceipt(receipt, {
        paperSize: paperSize as ThermalPaperSize,
        fontSize: fontSize as ThermalFontSize,
      });
      if (onShowToast) {
        onShowToast(res.message || 'تمت طباعة الوصل بنجاح!', 'success');
      }
      if (onSuccess) onSuccess();
      onClose();
    } catch (err: any) {
      console.error('Print confirmation error:', err);
      if (onShowToast) {
        onShowToast(err.message || 'تعذر إرسال الوصل للطابعة، يرجى التأكد من تشغيل البلوتوث', 'error');
      }
    } finally {
      setIsPrinting(false);
    }
  };

  const isPay = receipt.operationType.includes('pay');
  const amountTitle = isPay ? 'المبلغ المستلم' : 'المبلغ المضاف';

  return (
    <div
      className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-150 select-none"
      dir="rtl"
    >
      <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-sm overflow-hidden animate-in zoom-in-95 duration-200 text-start">
        {/* Header Ribbon */}
        <div className="p-4 bg-gradient-to-l from-amber-500/10 via-amber-500/5 to-transparent border-b border-amber-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500 text-white flex items-center justify-center text-lg font-bold shadow-md shadow-amber-500/20">
              <i className="fa-solid fa-print"></i>
            </div>
            <div>
              <h3 className="font-black text-sm text-slate-900 dark:text-white">
                هل تريد طباعة الوصل؟
              </h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                طابعة حرارية بلوتوث ({paperSize})
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            disabled={isPrinting}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-500 flex items-center justify-center transition-colors cursor-pointer"
          >
            <i className="fa-solid fa-xmark text-xs"></i>
          </button>
        </div>

        {/* Content & Receipt Preview */}
        <div className="p-5 space-y-4">
          {/* Printer status badge */}
          <div className="flex items-center justify-between p-2.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200/80 dark:border-slate-700/60 text-xs">
            <div className="flex items-center gap-2 text-slate-700 dark:text-slate-300">
              <i className="fa-brands fa-bluetooth-b text-blue-600"></i>
              <span className="font-bold truncate max-w-[170px]">
                {savedPrinter?.name || 'طابعة البلوتوث'}
              </span>
            </div>
            <div className="flex items-center gap-1.5 shrink-0">
              <span
                className={`w-2 h-2 rounded-full ${
                  printerStatus.connected ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'
                }`}
              ></span>
              <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400">
                {printerStatus.connected ? 'متصلة 🟢' : 'محفوظة في الجهاز 🟡'}
              </span>
            </div>
          </div>

          {/* Mini receipt representation */}
          <div className="p-3.5 bg-amber-50/50 dark:bg-slate-800/40 rounded-2xl border border-amber-200/70 dark:border-slate-700 space-y-2.5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-amber-900 dark:text-amber-400">نوع العملية:</span>
              <span className="font-black px-2 py-0.5 rounded-md bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 text-[11px]">
                {receipt.title}
              </span>
            </div>

            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-600 dark:text-slate-400">العميل:</span>
              <span className="font-bold text-slate-900 dark:text-white">{receipt.customerName}</span>
            </div>

            {receipt.itemName && (
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-600 dark:text-slate-400">السلعة/المادة:</span>
                <span className="font-bold text-slate-800 dark:text-slate-200">{receipt.itemName}</span>
              </div>
            )}

            <div className="pt-2 border-t border-dashed border-amber-200 dark:border-slate-700 flex items-center justify-between">
              <span className="text-xs font-bold text-slate-700 dark:text-slate-300">{amountTitle}:</span>
              <span className="text-base font-black text-emerald-600 dark:text-emerald-400">
                {formatNumber(receipt.amount)} <span className="text-xs font-bold">د.ع</span>
              </span>
            </div>

            {receipt.remainingBalance !== undefined && receipt.remainingBalance !== null && (
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-600 dark:text-slate-400">الرصيد المتبقي:</span>
                <span className="font-bold text-slate-900 dark:text-white">
                  {formatNumber(receipt.remainingBalance)} د.ع
                </span>
              </div>
            )}

            <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
              <span>رقم الوصل: {receipt.receiptId}</span>
              <span>{formatDateDigits(receipt.date)}</span>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-50 dark:bg-slate-800/80 border-t border-slate-100 dark:border-slate-800 flex gap-2.5">
          <button
            type="button"
            onClick={handleConfirmPrint}
            disabled={isPrinting}
            className="flex-1 py-3 px-4 bg-amber-600 hover:bg-amber-700 active:bg-amber-800 text-white rounded-2xl text-xs font-black shadow-lg shadow-amber-600/25 active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            {isPrinting ? (
              <>
                <i className="fa-solid fa-spinner fa-spin text-sm"></i>
                <span>جاري إرسال الوصل...</span>
              </>
            ) : (
              <>
                <i className="fa-solid fa-print text-sm"></i>
                <span>نعم - طباعة الوصل</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={onClose}
            disabled={isPrinting}
            className="px-5 py-3 bg-white dark:bg-slate-700 hover:bg-slate-100 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-600 rounded-2xl text-xs font-bold transition-all cursor-pointer"
          >
            تخطي (لا)
          </button>
        </div>
      </div>
    </div>
  );
};
