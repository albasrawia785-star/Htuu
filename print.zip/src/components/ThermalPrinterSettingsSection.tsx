import React, { useState, useEffect } from 'react';
import {
  AppSettings,
  ThermalPaperSize,
  ThermalFontSize,
} from '../types';
import {
  getSavedBluetoothPrinter,
  saveBluetoothPrinter,
  clearSavedBluetoothPrinter,
  checkBluetoothStatus,
  requestPairBluetoothPrinter,
  getPairedBluetoothPrinters,
  printReceipt,
  createTestReceiptData,
  isBluetoothSupported,
  SavedPrinterInfo,
} from '../utils/thermalPrinter';

interface ThermalPrinterSettingsSectionProps {
  settings: AppSettings;
  onUpdateSettings: (newSettings: AppSettings) => void;
  onShowToast?: (message: string, type: 'success' | 'error' | 'info') => void;
  isOpen: boolean;
  onToggle: () => void;
}

export const ThermalPrinterSettingsSection: React.FC<ThermalPrinterSettingsSectionProps> = ({
  settings,
  onUpdateSettings,
  onShowToast,
  isOpen,
  onToggle,
}) => {
  const [enabled, setEnabled] = useState<boolean>(settings.printerEnabled ?? false);
  const [paperSize, setPaperSize] = useState<ThermalPaperSize>(settings.printerPaperSize || '58mm');
  const [fontSize, setFontSize] = useState<ThermalFontSize>(settings.printerFontSize || 'medium');
  const [savedPrinter, setSavedPrinter] = useState<SavedPrinterInfo | null>(() => getSavedBluetoothPrinter());
  const [isConnecting, setIsConnecting] = useState(false);
  const [isTestPrinting, setIsTestPrinting] = useState(false);
  const [isSavedNotice, setIsSavedNotice] = useState(false);
  const [statusState, setStatusState] = useState<{ connected: boolean; name?: string }>({
    connected: false,
  });

  // Sync with prop updates
  useEffect(() => {
    setEnabled(settings.printerEnabled ?? false);
    setPaperSize(settings.printerPaperSize || '58mm');
    setFontSize(settings.printerFontSize || 'medium');
  }, [settings]);

  // Check connection status periodically
  useEffect(() => {
    const check = async () => {
      const res = await checkBluetoothStatus();
      setStatusState({ connected: res.connected, name: res.deviceName });
    };
    check();
    const interval = setInterval(check, 6000);
    return () => clearInterval(interval);
  }, []);

  const handleToggleEnabled = (newVal: boolean) => {
    setEnabled(newVal);
    const updated: AppSettings = {
      ...settings,
      printerEnabled: newVal,
      printerPaperSize: paperSize,
      printerFontSize: fontSize,
      printerDeviceName: savedPrinter?.name || settings.printerDeviceName,
      printerDeviceId: savedPrinter?.id || settings.printerDeviceId,
    };
    onUpdateSettings(updated);
    if (onShowToast) {
      onShowToast(
        newVal ? 'تم تفعيل الطابعة الحرارية وتنبيهات طباعة الوصل!' : 'تم إيقاف الطابعة الحرارية وتنبيهات الوصل',
        newVal ? 'success' : 'info'
      );
    }
  };

  const handleSavePreferences = (
    newSize = paperSize,
    newFont = fontSize,
    newPrinterInfo = savedPrinter
  ) => {
    setPaperSize(newSize);
    setFontSize(newFont);
    const updated: AppSettings = {
      ...settings,
      printerEnabled: enabled,
      printerPaperSize: newSize,
      printerFontSize: newFont,
      printerDeviceName: newPrinterInfo?.name || '',
      printerDeviceId: newPrinterInfo?.id || '',
    };
    onUpdateSettings(updated);
    setIsSavedNotice(true);
    setTimeout(() => setIsSavedNotice(false), 2500);
    if (onShowToast) {
      onShowToast('تم حفظ إعدادات الطابعة الحرارية بنجاح!', 'success');
    }
  };

  // Pair / Select a printer from device
  const handleSelectPrinter = async () => {
    try {
      setIsConnecting(true);
      const info = await requestPairBluetoothPrinter();
      setSavedPrinter(info);
      setStatusState({ connected: true, name: info.name });
      handleSavePreferences(paperSize, fontSize, info);
      if (onShowToast) {
        onShowToast(`تم ربط الطابعة (${info.name}) بنجاح!`, 'success');
      }
    } catch (err: any) {
      console.warn('Printer pairing error:', err);
      if (onShowToast) {
        onShowToast(err.message || 'تعذر الاتصال بالطابعة، يرجى تشغيل البلوتوث وتحديد الطابعة', 'error');
      }
    } finally {
      setIsConnecting(false);
    }
  };

  const handleForgetPrinter = () => {
    clearSavedBluetoothPrinter();
    setSavedPrinter(null);
    setStatusState({ connected: false });
    const updated: AppSettings = {
      ...settings,
      printerDeviceName: '',
      printerDeviceId: '',
    };
    onUpdateSettings(updated);
    if (onShowToast) {
      onShowToast('تمت إزالة الطابعة المحفوظة', 'info');
    }
  };

  // Run Test Print
  const handleTestPrint = async () => {
    try {
      setIsTestPrinting(true);
      const testData = createTestReceiptData({
        name: settings.companyName,
        phone: settings.companyPhone,
        address: settings.companyAddress,
      });

      const res = await printReceipt(testData, { paperSize, fontSize });
      if (onShowToast) {
        onShowToast(res.message || 'تمت طباعة الوصل التجريبي بنجاح!', 'success');
      }
    } catch (err: any) {
      console.error('Test print failed:', err);
      if (onShowToast) {
        onShowToast(err.message || 'فشلت الطباعة، تأكد من تشغيل الطابعة وتواجدها بالقرب من الجهاز', 'error');
      }
    } finally {
      setIsTestPrinting(false);
    }
  };

  const isBtAvailable = isBluetoothSupported();

  return (
    <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden transition-all text-start">
      {/* Header Button */}
      <button
        type="button"
        onClick={onToggle}
        className="w-full p-4 flex items-center justify-between gap-3 hover:bg-slate-50/70 active:bg-slate-100/60 transition-colors text-start cursor-pointer select-none"
      >
        <div className="flex items-center gap-3 min-w-0">
          <div
            className={`w-10 h-10 rounded-2xl flex items-center justify-center text-lg font-bold shrink-0 shadow-xs transition-all ${
              enabled ? 'bg-amber-50 text-amber-600' : 'bg-slate-100 text-slate-400'
            }`}
          >
            <i className="fa-solid fa-print"></i>
          </div>
          <div className="truncate text-start">
            <div className="font-bold text-sm text-slate-900 flex items-center gap-2">
              <span>إعدادات الطابعة الحرارية (Bluetooth)</span>
              <span
                className={`text-[10px] font-bold px-2 py-0.5 rounded-md border ${
                  enabled
                    ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                    : 'bg-slate-100 text-slate-500 border-slate-200'
                }`}
              >
                {enabled ? 'مفعل (تشغيل)' : 'معطل (إيقاف)'}
              </span>
            </div>
            <div className="text-[11px] text-slate-500 truncate mt-0.5">
              {enabled
                ? savedPrinter?.name
                  ? `الطابعة: ${savedPrinter.name} • مقاس ${paperSize}`
                  : `مفعل • لم يتم تحديد طابعة بعد • مقاس ${paperSize}`
                : 'الطباعة متوقفة • لا تظهر نوافذ تنبيه الوصل عند العمليات'}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <div
            className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all ${
              isOpen ? 'bg-amber-50 text-amber-600 rotate-180' : 'bg-slate-100 text-slate-400'
            }`}
          >
            <i className="fa-solid fa-chevron-down text-xs"></i>
          </div>
        </div>
      </button>

      {/* Accordion Content */}
      {isOpen && (
        <div className="p-5 pt-3 border-t border-slate-100 space-y-4 animate-in fade-in duration-200 text-start">
          {/* Master ON/OFF Switch */}
          <div
            className={`p-3.5 rounded-2xl border transition-all flex items-center justify-between gap-3 ${
              enabled ? 'bg-amber-50/80 border-amber-200' : 'bg-slate-50 border-slate-200'
            }`}
          >
            <div className="space-y-0.5">
              <span className="text-xs font-bold text-slate-900 block flex items-center gap-1.5">
                <i
                  className={`fa-solid ${
                    enabled ? 'fa-toggle-on text-amber-600 text-base' : 'fa-toggle-off text-slate-400 text-base'
                  }`}
                ></i>
                <span>تفعيل نظام الطابعة الحرارية وتنبيهات الوصل</span>
              </span>
              <p className="text-[11px] text-slate-600">
                {enabled
                  ? 'عند التشغيل: سيظهر تنبيه "هل تريد طباعة الوصل؟" فور تسجيل أي دين أو تسديد أو قسط أو مورد.'
                  : 'عند الإيقاف: لا يظهر أي تنبيه للطباعة مطلقاً، وتكتمل العمليات بشكل فوري كما هو معتاد.'}
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer shrink-0">
              <input
                type="checkbox"
                checked={enabled}
                onChange={(e) => handleToggleEnabled(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-600"></div>
            </label>
          </div>

          {/* Explanation Box on Arabic Image Rendering */}
          <div className="p-3 bg-blue-50/70 border border-blue-200/60 rounded-2xl text-xs text-blue-900 space-y-1">
            <div className="font-bold flex items-center gap-1.5 text-blue-950">
              <i className="fa-solid fa-circle-check text-blue-600"></i>
              <span>تقنية الطباعة النقطية كصورة (Monochrome Canvas):</span>
            </div>
            <p className="text-[11px] text-slate-600 leading-relaxed">
              يقوم النظام بتحويل الوصل بالكامل إلى صورة نقطية فائقة الوضوح قبل إرسالها إلى الطابعة عبر البلوتوث، مما يضمن خروج الحروف العربية متصلة وواضحة جداً مع كود الـ QR، دون أي تشويه أو تقطيع للحروف حتى على أرخص الطابعات الحرارية.
            </p>
          </div>

          {/* Printer Connection & Status Card */}
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <i className="fa-brands fa-bluetooth-b text-blue-600 text-sm"></i>
                <span className="text-xs font-bold text-slate-800">حالة الطابعة المتصلة:</span>
              </div>

              {/* Status Badge */}
              <div className="flex items-center gap-1.5">
                {savedPrinter ? (
                  statusState.connected ? (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                      متصلة 🟢
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-50 text-rose-700 border border-rose-200">
                      <span className="w-2 h-2 rounded-full bg-rose-500"></span>
                      جاهزة / غير متصلة 🔴
                    </span>
                  )
                ) : (
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-500 border border-slate-200">
                    لم يتم تعيين طابعة ⚪
                  </span>
                )}
              </div>
            </div>

            {/* Selected Printer Details */}
            {savedPrinter ? (
              <div className="p-3 bg-white rounded-xl border border-slate-200 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="w-8 h-8 rounded-lg bg-slate-100 text-slate-600 flex items-center justify-center shrink-0">
                    <i className="fa-solid fa-receipt text-xs"></i>
                  </div>
                  <div className="truncate">
                    <div className="font-bold text-xs text-slate-900 truncate">
                      {savedPrinter.name}
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono">
                      {savedPrinter.id ? `معرف: ${savedPrinter.id.slice(0, 16)}...` : 'طابعة بلوتوث محفوظة'}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={handleSelectPrinter}
                    disabled={isConnecting}
                    className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[11px] font-bold transition-all cursor-pointer"
                    title="تغيير الطابعة"
                  >
                    تغيير
                  </button>
                  <button
                    type="button"
                    onClick={handleForgetPrinter}
                    className="p-1.5 text-slate-400 hover:text-rose-600 transition-colors cursor-pointer"
                    title="حذف الطابعة"
                  >
                    <i className="fa-solid fa-trash-can text-xs"></i>
                  </button>
                </div>
              </div>
            ) : (
              <div className="p-3 bg-white/70 rounded-xl border border-dashed border-slate-300 text-center space-y-2">
                <p className="text-xs text-slate-500 font-medium">
                  اضغط الزر أدناه لاختيار طابعتك المقترنة بالجهاز مسبقاً
                </p>
                <button
                  type="button"
                  onClick={handleSelectPrinter}
                  disabled={isConnecting}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-all inline-flex items-center gap-2 cursor-pointer shadow-xs active:scale-95"
                >
                  {isConnecting ? (
                    <>
                      <i className="fa-solid fa-spinner fa-spin text-xs"></i>
                      <span>جاري الاتصال بالطابعة...</span>
                    </>
                  ) : (
                    <>
                      <i className="fa-brands fa-bluetooth text-xs"></i>
                      <span>اختيار طابعة من الأجهزة المقترنة</span>
                    </>
                  )}
                </button>
              </div>
            )}
          </div>

          {/* Paper Size Setting */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-slate-800">
              مقاس ورق الطابعة الحرارية:
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleSavePreferences('58mm', fontSize)}
                className={`p-3 rounded-2xl border text-start transition-all cursor-pointer ${
                  paperSize === '58mm'
                    ? 'bg-amber-50/80 border-amber-400 text-amber-950 font-bold ring-1 ring-amber-400'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100/70'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-black">58 ملم (384px)</span>
                  {paperSize === '58mm' && <i className="fa-solid fa-circle-check text-amber-600 text-xs"></i>}
                </div>
                <div className="text-[10px] text-slate-500">
                  المقاس القياسي لطابعات الفواتير المحمولة والبلوتوث الصغيرة
                </div>
              </button>

              <button
                type="button"
                onClick={() => handleSavePreferences('80mm', fontSize)}
                className={`p-3 rounded-2xl border text-start transition-all cursor-pointer ${
                  paperSize === '80mm'
                    ? 'bg-amber-50/80 border-amber-400 text-amber-950 font-bold ring-1 ring-amber-400'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100/70'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-black">80 ملم (576px)</span>
                  {paperSize === '80mm' && <i className="fa-solid fa-circle-check text-amber-600 text-xs"></i>}
                </div>
                <div className="text-[10px] text-slate-500">
                  المقاس العريض لطابعات نقاط البيع (POS) المكتبية وطابعات المطبخ
                </div>
              </button>
            </div>
          </div>

          {/* Receipt Font Size */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-slate-800">
              حجم خط ونصوص الوصل:
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(
                [
                  { id: 'small', label: 'صغير' },
                  { id: 'medium', label: 'متوسط (مثالي)' },
                  { id: 'large', label: 'كبير وعريض' },
                ] as const
              ).map((f) => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => handleSavePreferences(paperSize, f.id)}
                  className={`py-2 px-3 rounded-xl border text-xs font-bold transition-all text-center cursor-pointer ${
                    fontSize === f.id
                      ? 'bg-amber-600 text-white border-amber-600 shadow-xs'
                      : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          {/* Test Print & Actions */}
          <div className="pt-2 flex flex-col sm:flex-row gap-2">
            <button
              type="button"
              onClick={handleTestPrint}
              disabled={isTestPrinting}
              className="flex-1 py-2.5 px-4 bg-slate-900 hover:bg-black text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs active:scale-98"
            >
              {isTestPrinting ? (
                <>
                  <i className="fa-solid fa-spinner fa-spin text-xs"></i>
                  <span>جاري إرسال الوصل للطابعة...</span>
                </>
              ) : (
                <>
                  <i className="fa-solid fa-print text-amber-400 text-xs"></i>
                  <span>تجربة طباعة وصل اختباري 🖨️</span>
                </>
              )}
            </button>

            {isSavedNotice && (
              <div className="flex items-center justify-center gap-1.5 text-xs text-emerald-600 font-bold py-2">
                <i className="fa-solid fa-check-circle"></i>
                <span>تم حفظ الإعدادات بنجاح!</span>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
