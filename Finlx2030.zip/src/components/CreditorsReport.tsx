import React, { useState, useMemo } from 'react';
import { Debtor, DebtorTransaction, User } from '../types';
import { formatNumber, formatDateDigits, formatFullDateTime } from '../utils/formatters';
import { getUserBranchDisplayName, getUserDisplayName } from '../utils/userUtils';
import { printSystemPdfReport } from '../utils/pdfReportGenerator';
import { getLocalDebtorHistory } from '../services/turso';
import { generateCreditorsTextReport, shareTextFile } from '../utils/textReportExporter';
import { useI18n } from '../i18n/index.tsx';

export type CreditorReportPeriod = 'today' | 'week' | 'month' | 'custom' | 'all';
export type CreditorTxFilterType = 'all' | 'add' | 'pay';

interface CreditorsReportProps {
  debtors: Debtor[];
  currentUser: User;
  onShowToast?: (message: string, type: 'success' | 'error' | 'info') => void;
}

export const CreditorsReport: React.FC<CreditorsReportProps> = React.memo(({
  debtors,
  currentUser,
  onShowToast,
}) => {
  const { t, numberFormat, currency } = useI18n();

  const [period, setPeriod] = useState<CreditorReportPeriod>('all');
  const [txTypeFilter, setTxTypeFilter] = useState<CreditorTxFilterType>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [expandedIds, setExpandedIds] = useState<number[]>([]);

  // Only take creditors
  const creditors = useMemo(() => {
    return debtors.filter((d) => d.type === 'creditor');
  }, [debtors]);

  // Toggle expanded accordion
  const toggleExpand = (id: number) => {
    setExpandedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const expandAll = () => {
    setExpandedIds(creditors.map((c) => c.id));
  };

  const collapseAll = () => {
    setExpandedIds([]);
  };

  // Date range bounds calculation
  const { startMs, endMs } = useMemo(() => {
    const now = new Date();
    let s = 0;
    let e = Infinity;

    if (period === 'today') {
      const start = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0);
      s = start.getTime();
      e = Date.now();
    } else if (period === 'week') {
      const start = new Date(now);
      const day = start.getDay();
      const diff = start.getDate() - day + (day === 0 ? -6 : 1);
      start.setDate(diff);
      start.setHours(0, 0, 0, 0);
      s = start.getTime();
      e = Date.now();
    } else if (period === 'month') {
      const start = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0, 0);
      s = start.getTime();
      e = Date.now();
    } else if (period === 'custom') {
      if (startDate) {
        s = new Date(`${startDate}T00:00:00`).getTime();
      }
      if (endDate) {
        e = new Date(`${endDate}T23:59:59.999`).getTime();
      }
    }

    return { startMs: s, endMs: e };
  }, [period, startDate, endDate]);

  // History & summaries
  const { creditorSummaries, totalOwed, totalPaidInPeriod, totalAddedInPeriod, activeCount } = useMemo(() => {
    let owed = 0;
    let paidPeriod = 0;
    let addedPeriod = 0;
    let active = 0;

    const term = searchTerm.toLowerCase().trim();
    const historyMap = currentUser ? getLocalDebtorHistory(currentUser.id) : {};

    const summaries = creditors
      .filter((c) => {
        if (!term) return true;
        return (
          c.name.toLowerCase().includes(term) ||
          (c.phone && c.phone.includes(term)) ||
          (c.notes && c.notes.toLowerCase().includes(term))
        );
      })
      .map((c) => {
        const curAmount = Number(c.amount) || 0;
        if (curAmount > 0) {
          owed += curAmount;
          active++;
        }

        const rawHistory: DebtorTransaction[] = historyMap[c.id] || c.history || [];
        const inPeriodTx = rawHistory.filter((tx) => {
          const txTime = new Date(tx.date).getTime();
          return txTime >= startMs && txTime <= endMs;
        });

        let debtorPeriodAdded = 0;
        let debtorPeriodPaid = 0;

        inPeriodTx.forEach((tx) => {
          const amt = Number(tx.amount) || 0;
          if (tx.type === 'pay') {
            debtorPeriodPaid += amt;
          } else {
            debtorPeriodAdded += amt;
          }
        });

        addedPeriod += debtorPeriodAdded;
        paidPeriod += debtorPeriodPaid;

        const filteredTx = inPeriodTx.filter((tx) => {
          if (txTypeFilter === 'all') return true;
          return tx.type === txTypeFilter;
        });

        return {
          creditor: c,
          currentAmount: curAmount,
          periodAdded: debtorPeriodAdded,
          periodPaid: debtorPeriodPaid,
          netChange: debtorPeriodAdded - debtorPeriodPaid,
          transactions: filteredTx,
        };
      })
      .sort((a, b) => b.currentAmount - a.currentAmount);

    return {
      creditorSummaries: summaries,
      totalOwed: owed,
      totalPaidInPeriod: paidPeriod,
      totalAddedInPeriod: addedPeriod,
      activeCount: active,
    };
  }, [creditors, currentUser, searchTerm, startMs, endMs, txTypeFilter]);

  // Generate WhatsApp Share Statement Text
  const generateReportText = () => {
    const storeName = getUserBranchDisplayName(currentUser, t) || 'دفتر الديون';
    const dateStr = new Date().toLocaleDateString('ar-IQ');

    let text = `📊 *تقرير ديون عليّ (التزامات مالية)*\n`;
    text += `🏪 *الجهة:* ${storeName}\n`;
    text += `📅 *التاريخ:* ${dateStr}\n`;
    text += `⏱️ *الفترة المحددة:* ${
      period === 'today'
        ? 'اليوم'
        : period === 'week'
        ? 'هذا الأسبوع'
        : period === 'month'
        ? 'هذا الشهر'
        : period === 'custom'
        ? `مخصصة (${startDate || '...'} إلى ${endDate || '...'})`
        : 'كافة الفترات'
    }\n`;
    text += `------------------------------------\n`;
    text += `🔴 *إجمالي الديون القائمة عليك:* ${formatNumber(totalOwed, numberFormat)} ${currency}\n`;
    text += `🟢 *إجمالي ما قمت بتسديده في الفترة:* ${formatNumber(totalPaidInPeriod, numberFormat)} ${currency}\n`;
    text += `📦 *إجمالي ديون جديدة أضيفت عليك:* ${formatNumber(totalAddedInPeriod, numberFormat)} ${currency}\n`;
    text += `👥 *عدد الدائنين القائمين:* ${formatNumber(activeCount, numberFormat)}\n`;
    text += `------------------------------------\n`;

    const activeItems = creditorSummaries.filter((s) => s.currentAmount > 0 || s.transactions.length > 0);
    if (activeItems.length > 0) {
      text += `*تفاصيل الدائنين والديون:*\n\n`;
      activeItems.forEach((s, idx) => {
        text += `${idx + 1}) *${s.creditor.name}*\n`;
        if (s.creditor.phone) text += `   📞 ${s.creditor.phone}\n`;
        text += `   • الرصيد القائم: ${formatNumber(s.currentAmount, numberFormat)} ${currency}\n`;
        text += `   • ديون أضيفت: +${formatNumber(s.periodAdded, numberFormat)} ${currency}\n`;
        text += `   • مسددات دفعتها: -${formatNumber(s.periodPaid, numberFormat)} ${currency}\n\n`;
      });
    }

    text += `------------------------------------\n`;
    text += `تم الإنشاء عبر نظام دفتر الديون`;
    return text;
  };

  const handleShareWhatsApp = () => {
    const reportText = generateReportText();
    const url = `https://wa.me/?text=${encodeURIComponent(reportText)}`;
    window.open(url, '_blank');
  };

  const handleShareTextReport = async () => {
    try {
      const historyMap = currentUser ? getLocalDebtorHistory(currentUser.id) : {};
      const branchName = getUserBranchDisplayName(currentUser, t);
      const userName = getUserDisplayName(currentUser, t);
      const text = generateCreditorsTextReport(debtors, historyMap, {
        branchName,
        userName,
        currencySymbol: currency,
      });
      const dateStr = new Date().toISOString().slice(0, 10);
      const res = await shareTextFile(text, `تقرير_الدائنين_${dateStr}.txt`, 'تقرير الدائنين (ديون عليّ)');
      if (onShowToast) {
        if (res.method === 'download_fallback') {
          onShowToast('تم تنزيل الملف النصي (.txt) لعدم توفر المشاركة المباشرة في المتصفح', 'info');
        } else {
          onShowToast('تم فتح نافذة المشاركة بنجاح', 'success');
        }
      }
    } catch (err: any) {
      console.error('Error sharing creditors text report:', err);
      if (onShowToast) {
        onShowToast('حدث خطأ أثناء مشاركة الملف النصي', 'error');
      }
    }
  };

  const handleCopyReport = async () => {
    try {
      const reportText = generateReportText();
      await navigator.clipboard.writeText(reportText);
      if (onShowToast) {
        onShowToast('تم نسخ تقرير ديون عليّ بنجاح', 'success');
      }
    } catch {
      if (onShowToast) {
        onShowToast('تعذر نسخ التقرير تلقائياً', 'error');
      }
    }
  };

  const handleExportPdf = () => {
    const branchName = getUserBranchDisplayName(currentUser, t);
    const userName = getUserDisplayName(currentUser, t);

    let statsSummaryHtml = `<div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 14px;">
      <div style="background: #fff1f2; border: 1px solid #fecdd3; padding: 10px; border-radius: 8px; text-align: center;">
        <span style="font-size: 8pt; color: #881337; font-weight: 700;">إجمالي الديون القائمة عليك</span>
        <div style="font-size: 11.5pt; font-weight: 800; color: #be123c;">${formatNumber(totalOwed, numberFormat)} ${currency}</div>
      </div>
      <div style="background: #f0fdf4; border: 1px solid #bbf7d0; padding: 10px; border-radius: 8px; text-align: center;">
        <span style="font-size: 8pt; color: #14532d; font-weight: 700;">إجمالي مسددات دفعتها</span>
        <div style="font-size: 11.5pt; font-weight: 800; color: #15803d;">${formatNumber(totalPaidInPeriod, numberFormat)} ${currency}</div>
      </div>
      <div style="background: #fffbe3; border: 1px solid #fef08a; padding: 10px; border-radius: 8px; text-align: center;">
        <span style="font-size: 8pt; color: #713f12; font-weight: 700;">ديون جديدة أضيفت عليك</span>
        <div style="font-size: 11.5pt; font-weight: 800; color: #a16207;">${formatNumber(totalAddedInPeriod, numberFormat)} ${currency}</div>
      </div>
    </div>`;

    let htmlSections = '';
    const sortedCreditorSummaries = [...creditorSummaries]
      .filter((s) => s.currentAmount > 0 || s.transactions.length > 0)
      .sort((a, b) => b.currentAmount - a.currentAmount);

    if (sortedCreditorSummaries.length === 0) {
      htmlSections = '<div style="text-align: center; padding: 20px; color: #64748b;">لا يوجد دائنون مطابقون للبحث</div>';
    } else {
      sortedCreditorSummaries.forEach(({ creditor, currentAmount, transactions }) => {
        let txRows = '';
        if (transactions.length === 0) {
          txRows = `<tr><td colspan="5" style="text-align:center; color:#64748b; padding:8px;">لا توجد حركات مسجلة لهذا الدائن خلال هذه الفترة</td></tr>`;
        } else {
          transactions.forEach((tx, idx) => {
            const isPay = tx.type === 'pay';
            const typeLabel = isPay ? 'تسديد دفعة' : 'دين إضافي عليّ';
            const typeClass = isPay ? 'tx-type-pay' : 'tx-type-add';
            const amountPrefix = isPay ? '-' : '+';
            const cleanDate = tx.date ? tx.date.split('T')[0].replace(/-/g, '/') : '-';
            txRows += `<tr>
              <td><strong>${formatNumber(idx + 1, numberFormat)}</strong></td>
              <td><span class="${typeClass}">${typeLabel}</span></td>
              <td><strong>${amountPrefix}${formatNumber(tx.amount, numberFormat)} ${currency}</strong></td>
              <td>${cleanDate}</td>
              <td>${tx.notes || tx.description || '-'}</td>
            </tr>`;
          });
        }

        const cleanCreatedAt = creditor.createdAt ? creditor.createdAt.split('T')[0].replace(/-/g, '/') : '-';
        htmlSections += `<div class="person-card">
          <div class="person-card-header">
            <div>
              <div class="person-name">${creditor.name}</div>
              <div class="person-phone">رقم الهاتف: ${creditor.phone ? formatDateDigits(creditor.phone, numberFormat) : 'غير محدد'} | تاريخ التسجيل: ${cleanCreatedAt}</div>
            </div>
            <div class="person-amount-box">
              <span class="amount-value">${formatNumber(currentAmount, numberFormat)} ${currency}</span>
              <span class="amount-label">الرصيد القائم عليك</span>
            </div>
          </div>
          <div style="padding: 8px 12px; background: #fff;">
            <table class="tx-table">
              <thead>
                <tr>
                  <th style="width: 25px;">#</th>
                  <th style="width: 100px;">نوع الحركة</th>
                  <th style="width: 110px;">المبلغ</th>
                  <th style="width: 95px;">التاريخ</th>
                  <th>الملاحظات والتفاصيل</th>
                </tr>
              </thead>
              <tbody>
                ${txRows}
              </tbody>
            </table>
          </div>
        </div>`;
      });
    }

    printSystemPdfReport(
      {
        title: 'تقرير ديون عليّ (التزامات الدائنين) التفصيلي',
        subtitle: `إجمالي الدائنين المسجلين: ${formatNumber(creditorSummaries.length, numberFormat)} دائن`,
        branchName,
        userName,
        statsSummaryHtml,
        accentColor: 'rose',
      },
      htmlSections
    );
  };

  return (
    <div className="space-y-4 text-start animate-in fade-in duration-150 pt-1">
      {/* 1. Overview Financial Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-3">
        {/* Card 1: Total Owed on me */}
        <div className="bg-gradient-to-br from-rose-600 via-rose-700 to-red-800 rounded-2xl p-3.5 sm:p-4 text-white shadow-md shadow-rose-950/20 flex flex-col justify-between border border-rose-500/40 relative overflow-hidden group">
          <div className="flex items-center justify-between text-xs font-bold mb-1.5 text-rose-100">
            <span>ديون قائمة عليك</span>
            <div className="w-7 h-7 rounded-xl bg-white/15 flex items-center justify-center text-xs shadow-inner">
              <i className="fa-solid fa-hand-holding-dollar"></i>
            </div>
          </div>
          <div className="text-base sm:text-lg font-black font-mono truncate select-all tracking-tight my-0.5">
            {formatNumber(totalOwed, numberFormat)} <span className="text-[10.5px] font-normal text-rose-200">{currency}</span>
          </div>
          <div className="text-[10px] sm:text-[10.5px] text-rose-100 font-medium flex items-center gap-1 mt-1">
            <span className="w-1.5 h-1.5 rounded-full bg-rose-300 animate-pulse"></span>
            <span>{formatNumber(activeCount, numberFormat)} دائنين يطلبونك</span>
          </div>
        </div>

        {/* Card 2: Paid in period */}
        <div className="bg-gradient-to-br from-emerald-600 via-emerald-700 to-teal-800 rounded-2xl p-3.5 sm:p-4 text-white shadow-md shadow-emerald-950/20 flex flex-col justify-between border border-emerald-500/40 relative overflow-hidden group">
          <div className="flex items-center justify-between text-xs font-bold mb-1.5 text-emerald-100">
            <span>مسددات دفعتها</span>
            <div className="w-7 h-7 rounded-xl bg-white/15 flex items-center justify-center text-xs shadow-inner">
              <i className="fa-solid fa-circle-check"></i>
            </div>
          </div>
          <div className="text-base sm:text-lg font-black font-mono truncate select-all tracking-tight my-0.5">
            {formatNumber(totalPaidInPeriod, numberFormat)} <span className="text-[10.5px] font-normal text-emerald-200">{currency}</span>
          </div>
          <div className="text-[10px] sm:text-[10.5px] text-emerald-100 font-medium flex items-center gap-1 mt-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-300"></span>
            <span>دفعات سددتها بالكامل</span>
          </div>
        </div>

        {/* Card 3: Added in period */}
        <div className="bg-gradient-to-br from-amber-500 via-amber-600 to-orange-700 rounded-2xl p-3.5 sm:p-4 text-white shadow-md shadow-amber-950/20 flex flex-col justify-between border border-amber-400/40 relative overflow-hidden group">
          <div className="flex items-center justify-between text-xs font-bold mb-1.5 text-amber-100">
            <span>ديون جديدة عليك</span>
            <div className="w-7 h-7 rounded-xl bg-white/15 flex items-center justify-center text-xs shadow-inner">
              <i className="fa-solid fa-plus-circle"></i>
            </div>
          </div>
          <div className="text-base sm:text-lg font-black font-mono truncate select-all tracking-tight my-0.5">
            {formatNumber(totalAddedInPeriod, numberFormat)} <span className="text-[10.5px] font-normal text-amber-200">{currency}</span>
          </div>
          <div className="text-[10px] sm:text-[10.5px] text-amber-100 font-medium flex items-center gap-1 mt-1">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-300"></span>
            <span>التزامات جديدة أضيفت</span>
          </div>
        </div>

        {/* Card 4: Creditors Count */}
        <div className="bg-gradient-to-br from-slate-800 via-slate-850 to-slate-900 rounded-2xl p-3.5 sm:p-4 text-white shadow-md shadow-slate-950/20 flex flex-col justify-between border border-slate-700/60 relative overflow-hidden group">
          <div className="flex items-center justify-between text-xs font-bold mb-1.5 text-slate-300">
            <span>إجمالي الدائنين</span>
            <div className="w-7 h-7 rounded-xl bg-white/10 flex items-center justify-center text-xs shadow-inner text-rose-400">
              <i className="fa-solid fa-users"></i>
            </div>
          </div>
          <div className="text-base sm:text-lg font-black font-mono truncate select-all tracking-tight my-0.5">
            {formatNumber(creditors.length, numberFormat)} <span className="text-[10.5px] font-normal text-slate-400">حساب</span>
          </div>
          <div className="text-[10px] sm:text-[10.5px] text-slate-400 font-medium flex items-center gap-1 mt-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
            <span>{formatNumber(creditors.length - activeCount, numberFormat)} مصفّر (خالص)</span>
          </div>
        </div>
      </div>

      {/* 2. Control Panel & Filters Box */}
      <div className="bg-white dark:bg-slate-900 p-3.5 sm:p-4 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-3">
        {/* Row A: Period Selector */}
        <div className="flex items-center justify-between gap-2 flex-wrap pb-1 border-b border-slate-100 dark:border-slate-800/80">
          <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700 dark:text-slate-300">
            <i className="fa-solid fa-calendar-days text-rose-600"></i>
            <span>تحديد الفترة:</span>
          </div>
          <div className="flex items-center gap-1 overflow-x-auto no-scrollbar py-0.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-2xl border border-slate-200/60 dark:border-slate-700/60">
            {(['all', 'today', 'week', 'month', 'custom'] as CreditorReportPeriod[]).map((p) => (
              <button
                key={p}
                type="button"
                onClick={() => setPeriod(p)}
                className={`px-3 py-1.5 rounded-xl font-bold transition-all shrink-0 cursor-pointer text-xs ${
                  period === p
                    ? 'bg-rose-600 text-white shadow-xs font-black scale-[1.02]'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-white/50 dark:hover:bg-slate-700/50'
                }`}
              >
                {p === 'all'
                  ? 'الكل'
                  : p === 'today'
                  ? 'اليوم'
                  : p === 'week'
                  ? 'هذا الأسبوع'
                  : p === 'month'
                  ? 'هذا الشهر'
                  : 'مخصصة'}
              </button>
            ))}
          </div>
        </div>

        {/* Row B: Custom Date Pickers (Shown only if custom period selected) */}
        {period === 'custom' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 p-3 rounded-2xl bg-rose-50/50 dark:bg-rose-950/20 border border-rose-200/60 dark:border-rose-900/40 animate-in fade-in duration-200">
            <div>
              <label className="text-[11px] font-bold text-slate-600 dark:text-slate-400 block mb-1">من تاريخ:</label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:border-rose-500 font-mono"
              />
            </div>
            <div>
              <label className="text-[11px] font-bold text-slate-600 dark:text-slate-400 block mb-1">إلى تاريخ:</label>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:border-rose-500 font-mono"
              />
            </div>
          </div>
        )}

        {/* Row C: Live Search Bar & Operation Type Segment */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 pt-0.5">
          {/* Search Box */}
          <div className="relative flex-1">
            <i className="fa-solid fa-magnifying-glass absolute start-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs pointer-events-none"></i>
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="ابحث باسم الدائن أو رقم الهاتف أو الملاحظات..."
              className="w-full ps-8 pe-8 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700 rounded-xl outline-none focus:border-rose-500 focus:bg-white dark:focus:bg-slate-900 transition-all shadow-inner"
            />
            {searchTerm && (
              <button
                type="button"
                onClick={() => setSearchTerm('')}
                className="absolute end-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
                title="مسح البحث"
              >
                <i className="fa-solid fa-xmark text-xs"></i>
              </button>
            )}
          </div>

          {/* Operation Type Switch */}
          <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl border border-slate-200/60 dark:border-slate-700 shrink-0">
            {(['all', 'add', 'pay'] as CreditorTxFilterType[]).map((type) => (
              <button
                key={type}
                type="button"
                onClick={() => setTxTypeFilter(type)}
                className={`flex-1 sm:flex-initial px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                  txTypeFilter === type
                    ? 'bg-white dark:bg-slate-900 text-rose-700 dark:text-rose-400 font-extrabold shadow-xs border border-slate-200/60 dark:border-slate-700'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {type === 'all' ? 'كافة العمليات' : type === 'add' ? 'ديون أضيفت' : 'تسديدات دفعتها'}
              </button>
            ))}
          </div>
        </div>

        {/* Row D: Unified Action & Export Toolbar */}
        <div className="pt-2.5 border-t border-slate-100 dark:border-slate-800/80 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-2.5">
          {/* Left: View Controls (Expand / Collapse) */}
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={expandAll}
              className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer border border-slate-200/60 dark:border-slate-700 active:scale-95"
            >
              <i className="fa-solid fa-up-right-and-down-left-from-center text-[10px] text-slate-500"></i>
              <span>توسيع الكل</span>
            </button>
            <button
              type="button"
              onClick={collapseAll}
              className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer border border-slate-200/60 dark:border-slate-700 active:scale-95"
            >
              <i className="fa-solid fa-down-left-and-up-right-to-center text-[10px] text-slate-500"></i>
              <span>طي الكل</span>
            </button>
          </div>

          {/* Right: Export & Share Actions */}
          <div className="flex items-center gap-1.5 flex-wrap sm:flex-nowrap">
            {/* Copy Report */}
            <button
              type="button"
              onClick={handleCopyReport}
              className="flex-1 sm:flex-initial px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer border border-slate-200/60 dark:border-slate-700 active:scale-95"
              title="نسخ نص التقرير المالي إلى الحافظة"
            >
              <i className="fa-solid fa-copy text-xs text-slate-500"></i>
              <span>نسخ التقرير</span>
            </button>

            {/* Share Text File */}
            <button
              type="button"
              onClick={handleShareTextReport}
              className="flex-1 sm:flex-initial px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-xs active:scale-95"
              title="مشاركة التقرير كملف نصي (.txt)"
            >
              <i className="fa-solid fa-share-nodes text-xs"></i>
              <span>مشاركة ملف (.txt)</span>
            </button>

            {/* Export PDF (Primary Action) */}
            <button
              type="button"
              onClick={handleExportPdf}
              className="w-full sm:w-auto px-4 py-1.5 rounded-xl bg-gradient-to-r from-rose-600 via-rose-600 to-red-700 hover:from-rose-700 hover:to-red-800 text-white font-black text-xs flex items-center justify-center gap-2 shadow-md shadow-rose-950/20 transition-all cursor-pointer active:scale-95 shrink-0"
              title="تصدير وطباعة تقرير ديون عليّ بصيغة PDF"
            >
              <i className="fa-solid fa-file-pdf text-sm"></i>
              <span>تصدير PDF</span>
            </button>
          </div>
        </div>
      </div>

      {/* Creditors Summaries List */}
      <div className="space-y-2.5">
        {creditorSummaries.length === 0 ? (
          <div className="text-center py-10 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs">
            <div className="w-12 h-12 rounded-2xl bg-rose-50 dark:bg-rose-950 text-rose-500 flex items-center justify-center text-xl mx-auto mb-2.5">
              <i className="fa-solid fa-hand-holding-dollar"></i>
            </div>
            <h4 className="text-sm font-bold text-slate-800 dark:text-white mb-1">لا توجد نتائج مطابقة</h4>
            <p className="text-xs text-slate-400">لم يتم العثور على سجلات ديون للدائنين في هذه الفترة المحددة</p>
          </div>
        ) : (
          creditorSummaries.map((s) => {
            const isExpanded = expandedIds.includes(s.creditor.id);
            return (
              <div
                key={s.creditor.id}
                className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden transition-all"
              >
                {/* Header item */}
                <div
                  onClick={() => toggleExpand(s.creditor.id)}
                  className="p-3 sm:p-3.5 flex items-center justify-between gap-3 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/50 select-none"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-8 h-8 rounded-xl bg-rose-50 dark:bg-rose-950 text-rose-600 flex items-center justify-center text-xs shrink-0 font-black">
                      <i className="fa-solid fa-hand-holding-dollar"></i>
                    </div>
                    <div className="min-w-0">
                      <div className="text-xs sm:text-sm font-black text-slate-900 dark:text-white truncate">
                        {s.creditor.name}
                      </div>
                      <div className="text-[10px] text-slate-500 font-mono">
                        {s.creditor.phone || 'بدون رقم'} • {s.transactions.length} حركات
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 shrink-0 text-end">
                    <div>
                      <div className="text-xs sm:text-sm font-black text-rose-600 font-mono" dir="ltr">
                        {formatNumber(s.currentAmount, numberFormat)} {currency}
                      </div>
                      <div className="text-[9.5px] text-slate-400 font-semibold">
                        سددت له: {formatNumber(s.periodPaid, numberFormat)}
                      </div>
                    </div>
                    <i
                      className={`fa-solid fa-chevron-down text-xs text-slate-400 transition-transform ${
                        isExpanded ? 'rotate-180 text-rose-500' : ''
                      }`}
                    ></i>
                  </div>
                </div>

                {/* Expanded Transactions Log */}
                {isExpanded && (
                  <div className="border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/40 p-3 space-y-2">
                    <div className="flex items-center justify-between text-[11px] font-bold text-slate-500 px-1">
                      <span>سجل الحركات خلال الفترة ({s.transactions.length})</span>
                      <div className="flex items-center gap-2 text-[10px]">
                        <span className="text-amber-700 dark:text-amber-400 font-mono">أضيف: +{formatNumber(s.periodAdded, numberFormat)}</span>
                        <span className="text-emerald-700 dark:text-emerald-400 font-mono">دفعت: -{formatNumber(s.periodPaid, numberFormat)}</span>
                      </div>
                    </div>

                    {s.transactions.length === 0 ? (
                      <div className="text-center py-4 text-xs text-slate-400">
                        لا توجد حركات مسجلة لهذا الدائن في الفترة المحددة
                      </div>
                    ) : (
                      <div className="space-y-1.5">
                        {s.transactions.map((tx) => (
                          <div
                            key={tx.id}
                            className="bg-white dark:bg-slate-900 p-2 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs"
                          >
                            <div className="flex items-center gap-2">
                              <span
                                className={`w-5 h-5 rounded-lg flex items-center justify-center text-[10px] ${
                                  tx.type === 'pay'
                                    ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                                    : 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300'
                                }`}
                              >
                                <i className={`fa-solid ${tx.type === 'pay' ? 'fa-arrow-down' : 'fa-plus'}`}></i>
                              </span>
                              <div>
                                <span className="font-bold text-slate-800 dark:text-slate-200 text-[11px]">
                                  {tx.type === 'pay' ? 'تسديد دفعة للدائن' : 'دين إضافي عليك'}
                                </span>
                                {tx.notes && (
                                  <span className="text-[10px] text-slate-500 block truncate max-w-[180px] sm:max-w-xs">
                                    {tx.notes}
                                  </span>
                                )}
                              </div>
                            </div>

                            <div className="text-end">
                              <span
                                className={`font-black font-mono ${
                                  tx.type === 'pay' ? 'text-emerald-600' : 'text-rose-600'
                                }`}
                              >
                                {tx.type === 'pay' ? '-' : '+'}
                                {formatNumber(tx.amount, numberFormat)} {currency}
                              </span>
                              <span className="text-[9.5px] text-slate-500 block font-mono flex items-center gap-1 justify-end">
                                <i className="fa-regular fa-clock text-[8.5px] text-slate-400"></i>
                                <span>{formatFullDateTime(tx.date, numberFormat)}</span>
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
});

CreditorsReport.displayName = 'CreditorsReport';
