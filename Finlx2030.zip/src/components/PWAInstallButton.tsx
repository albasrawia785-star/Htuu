import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { useI18n } from '../i18n/index.tsx';

export const PWAInstallButton: React.FC<{ className?: string; variant?: 'default' | 'login' }> = ({ 
  className = '',
  variant = 'default'
}) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const { t, dir } = useI18n();
  const [showGuideModal, setShowGuideModal] = useState(false);

  // If already installed or running standalone, hide the button
  if (isInstalled) {
    return null;
  }

  const handleButtonClick = async () => {
    if (isInstallable) {
      const ok = await install();
      if (!ok) {
        setShowGuideModal(true);
      }
    } else {
      setShowGuideModal(true);
    }
  };

  const isLoginVariant = variant === 'login';

  return (
    <>
      <button
        id={isLoginVariant ? "loginPwaInstallBtn" : "pwaInstallBtn"}
        type="button"
        onClick={handleButtonClick}
        className={
          isLoginVariant
            ? `inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-black shadow-md border border-emerald-400/40 active:scale-95 transition-all cursor-pointer animate-in fade-in duration-300 ${className}`
            : isIOS
            ? `inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-700/15 hover:bg-emerald-700/25 text-emerald-800 text-xs font-bold border border-emerald-300 transition-all cursor-pointer ${className}`
            : `inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs active:scale-[0.98] transition-all cursor-pointer ${className}`
        }
        title={t('pwa.installDeviceTitle', 'تثبيت التطبيق على الجهاز')}
      >
        <i className={isIOS ? "fa-brands fa-apple text-xs" : "fa-solid fa-cloud-arrow-down text-xs"}></i>
        <span>{t('pwa.installApp', 'تثبيت التطبيق')}</span>
      </button>

      {/* Guide Modal for iOS or manual install on Android/Desktop */}
      {showGuideModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-4 animate-in fade-in duration-150" dir={dir}>
          <div className="w-full max-w-sm rounded-2xl bg-white p-5 shadow-2xl border border-slate-100 text-start space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center text-base">
                  <i className={isIOS ? "fa-brands fa-apple text-lg" : "fa-solid fa-mobile-screen-button"}></i>
                </div>
                <div>
                  <h3 className="text-xs sm:text-sm font-black text-slate-800">
                    {isIOS ? t('pwa.iosModalTitle', 'تثبيت التطبيق على iPhone / iPad') : 'تثبيت التطبيق على الهاتف'}
                  </h3>
                  <p className="text-[11px] text-slate-500 font-medium">ليعمل كتطبيق أصلي سريع ومستقل</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowGuideModal(false)}
                className="w-7 h-7 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center text-xs transition-colors cursor-pointer"
              >
                <i className="fa-solid fa-xmark"></i>
              </button>
            </div>

            {isIOS ? (
              <div className="space-y-2.5 text-xs text-slate-600 leading-relaxed">
                <div className="flex items-start gap-2.5 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                  <span className="w-5 h-5 rounded-full bg-emerald-600 text-white font-bold text-[11px] flex items-center justify-center shrink-0">1</span>
                  <p>{t('pwa.iosStep1', 'اضغط على زر المشاركة (Share) في شريط متصفح سفاري بالأسفل.')}</p>
                </div>
                <div className="flex items-start gap-2.5 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                  <span className="w-5 h-5 rounded-full bg-emerald-600 text-white font-bold text-[11px] flex items-center justify-center shrink-0">2</span>
                  <p>{t('pwa.iosStep2', 'مرر للأسفل واختر إضافة إلى الصفحة الرئيسية (Add to Home Screen).')}</p>
                </div>
                <div className="flex items-start gap-2.5 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                  <span className="w-5 h-5 rounded-full bg-emerald-600 text-white font-bold text-[11px] flex items-center justify-center shrink-0">3</span>
                  <p>{t('pwa.iosStep3', 'اضغط على إضافة (Add) بالأعلى ليفتح التطبيق كنافذة مستقلة وسريعة.')}</p>
                </div>
              </div>
            ) : (
              <div className="space-y-2.5 text-xs text-slate-600 leading-relaxed">
                <div className="flex items-start gap-2.5 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                  <span className="w-5 h-5 rounded-full bg-emerald-600 text-white font-bold text-[11px] flex items-center justify-center shrink-0">1</span>
                  <p>اضغط على قائمة الخيارات <strong>(⋮)</strong> في أعلى أو أسفل المتصفح (Chrome).</p>
                </div>
                <div className="flex items-start gap-2.5 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                  <span className="w-5 h-5 rounded-full bg-emerald-600 text-white font-bold text-[11px] flex items-center justify-center shrink-0">2</span>
                  <p>اختر <strong>"تثبيت التطبيق"</strong> أو <strong>"إضافة إلى الشاشة الرئيسية"</strong>.</p>
                </div>
                <div className="flex items-start gap-2.5 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                  <span className="w-5 h-5 rounded-full bg-emerald-600 text-white font-bold text-[11px] flex items-center justify-center shrink-0">3</span>
                  <p>سيظهر التطبيق كأيقونة مستقلة في قائمة تطبيقات هاتفك ليعمل دون متصفح.</p>
                </div>
              </div>
            )}

            <button
              type="button"
              onClick={() => setShowGuideModal(false)}
              className="w-full py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-colors cursor-pointer"
            >
              {t('pwa.gotIt', 'فهمت، حسناً')}
            </button>
          </div>
        </div>
      )}
    </>
  );
};

