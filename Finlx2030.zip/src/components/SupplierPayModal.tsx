import React, { useState, useEffect, useRef } from 'react';
import { Supplier } from '../types';
import { formatNumber, formatAmountInput, parseFormattedNumber, getCurrentTimeStr, resolveRecordDateTime } from '../utils/formatters';
import { useI18n } from '../i18n/index.tsx';
import { handleInputFocus, useModalKeyboardAdjust } from '../utils/keyboardHelper';
import { RecordTimeSelector } from './RecordTimeSelector';

interface SupplierPayModalProps {
  supplier: Supplier | null;
  isOpen: boolean;
  onClose: () => void;
  onPaySupplier: (supplierId: number, amount: number, notes?: string, payDate?: string, paymentMethod?: 'cash' | 'electronic') => void;
  currencySymbol?: string;
  enableElectronicPayment?: boolean;
}

export const SupplierPayModal: React.FC<SupplierPayModalProps> = ({
  supplier,
  isOpen,
  onClose,
  onPaySupplier,
  currencySymbol = 'د.ع',
  enableElectronicPayment = false,
}) => {
  const { numberFormat } = useI18n();
  const [payAmount, setPayAmount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'electronic'>('cash');
  const [notes, setNotes] = useState('');
  const [payDate, setPayDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [recordTime, setRecordTime] = useState(false);
  const [timeMode, setTimeMode] = useState<'auto' | 'manual'>('auto');
  const [payTime, setPayTime] = useState(() => getCurrentTimeStr());

  const prevIsOpenRef = useRef(false);
  const prevSupplierIdRef = useRef<number | null>(null);

  useModalKeyboardAdjust(isOpen);

  const todayStr = new Date().toISOString().split('T')[0];

  // Reset fields ONLY when the modal transitions from closed to open, or when supplier ID actually changes
  useEffect(() => {
    if (isOpen && supplier) {
      const isJustOpened = !prevIsOpenRef.current;
      const isDifferentSupplier = prevSupplierIdRef.current !== supplier.id;

      if (isJustOpened || isDifferentSupplier) {
        setPayAmount('');
        setPaymentMethod('cash');
        setNotes('');
        setPayDate(new Date().toISOString().split('T')[0]);
        setRecordTime(false);
        setTimeMode('auto');
        setPayTime(getCurrentTimeStr());
      }
    }
    prevIsOpenRef.current = isOpen;
    prevSupplierIdRef.current = supplier ? supplier.id : null;
  }, [supplier?.id, isOpen]);

  if (!isOpen || !supplier) return null;

  const currentAmount = supplier.amount || 0;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFormattedNumber(payAmount);
    if (isNaN(numAmount) || numAmount <= 0) {
      alert('يرجى أدخال مبلغ التسديد بشكل صحيح.');
      return;
    }

    if (numAmount > currentAmount) {
      if (!confirm(`المبلغ المدخل (${formatNumber(numAmount, numberFormat)}) أكبر من الدين القائم عليك للمورد (${formatNumber(currentAmount, numberFormat)}). هل تريد الاستمرار؟`)) {
        return;
      }
    }

    const fullPayDateTime = resolveRecordDateTime(payDate, recordTime, timeMode, payTime);
    onPaySupplier(supplier.id, numAmount, notes.trim() || undefined, fullPayDateTime, paymentMethod);

    // Reset & Close
    setPayAmount('');
    setPaymentMethod('cash');
    setNotes('');
    onClose();
  };

  const supplierDisplayName = typeof supplier.name === 'string' ? supplier.name : String(supplier.name || '');
  const companyNameStr = typeof supplier.companyName === 'string' && supplier.companyName.trim() ? `(${supplier.companyName.trim()})` : '';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200 overflow-y-auto">
      <div
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-md shadow-2xl overflow-hidden flex flex-col my-auto max-h-[92vh] animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-600 via-teal-700 to-cyan-700 p-4 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-white/20 flex items-center justify-center text-lg shrink-0">
              <i className="fa-solid fa-hand-holding-dollar text-emerald-100"></i>
            </div>
            <div>
              <h3 className="font-extrabold text-sm sm:text-base">تسديد المورد / الشركة</h3>
              <p className="text-[11px] text-emerald-100/90 font-medium">تسديد دفعة مالية من الدين المطلوب منك</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors cursor-pointer"
          >
            <i className="fa-solid fa-xmark text-sm"></i>
          </button>
        </div>

        {/* Info Banner */}
        <div className="p-3.5 bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-700/80 text-start flex items-center justify-between">
          <div>
            <span className="text-[10px] text-slate-500 dark:text-slate-400 font-bold block">اسم المورد / الشركة</span>
            <span className="text-xs font-black text-slate-900 dark:text-white">
              {supplierDisplayName} {companyNameStr}
            </span>
          </div>
          <div className="text-left">
            <span className="text-[10px] text-slate-500 dark:text-slate-400 font-bold block">الدين المتبقي له عليك</span>
            <span className="text-sm font-black text-amber-600 dark:text-amber-400 font-mono">
              {formatNumber(currentAmount, numberFormat)} {currencySymbol}
            </span>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-4 space-y-3.5 text-start overflow-y-auto">
          {/* Pay Amount */}
          <div className="space-y-1">
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
              المبلغ المسدد للمورد <span className="text-rose-500">*</span>
            </label>
            <div className="relative flex items-center">
              <input
                type="text"
                inputMode="numeric"
                required
                value={payAmount}
                onFocus={handleInputFocus}
                onChange={(e) => setPayAmount(formatAmountInput(e.target.value))}
                placeholder="أدخل مبلغ التسديد (مثال: 100,000)..."
                className="w-full p-3 bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-300 dark:border-emerald-800/80 rounded-2xl text-base font-black text-emerald-900 dark:text-emerald-200 outline-none focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/30 transition-all"
              />
              <span className="absolute left-3 text-xs font-extrabold text-emerald-700 dark:text-emerald-400">
                {currencySymbol}
              </span>
            </div>
            <button
              type="button"
              onClick={() => setPayAmount(formatAmountInput(String(currentAmount)))}
              className="text-[10px] font-bold text-emerald-600 hover:underline cursor-pointer pt-0.5 inline-block"
            >
              تسديد كامل الدين المتبقي ({formatNumber(currentAmount, numberFormat)} {currencySymbol})
            </button>
          </div>

          {/* Payment Method - Shown only when electronic payment is enabled */}
          {enableElectronicPayment && (
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center justify-between">
                <span>طريقة الدفع والتسديد</span>
                <span className="text-[10.5px] font-bold text-emerald-600 dark:text-emerald-400">
                  {paymentMethod === 'electronic' ? '💳 دفع إلكتروني (ماستر كارد / محفظة)' : '💵 نقداً (كاش)'}
                </span>
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('cash')}
                  className={`py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 border transition-all cursor-pointer ${
                    paymentMethod === 'cash'
                      ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500 text-emerald-700 dark:text-emerald-300 ring-2 ring-emerald-500/20'
                      : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  <span>💵</span>
                  <span>نقداً (كاش)</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('electronic')}
                  className={`py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 border transition-all cursor-pointer ${
                    paymentMethod === 'electronic'
                      ? 'bg-teal-50 dark:bg-teal-950/40 border-teal-500 text-teal-700 dark:text-teal-300 ring-2 ring-teal-500/20'
                      : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  <span>💳</span>
                  <span>دفع إلكتروني</span>
                </button>
              </div>
            </div>
          )}

          {/* Payment Date */}
          <div className="space-y-1">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">تاريخ التسديد</label>
              {payDate !== todayStr ? (
                <button
                  type="button"
                  onClick={() => setPayDate(todayStr)}
                  className="text-[10px] font-bold text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 px-1.5 py-0.5 rounded cursor-pointer transition-colors"
                >
                  اليوم
                </button>
              ) : (
                <span className="text-[10px] text-emerald-700 dark:text-emerald-400 font-bold bg-emerald-50 dark:bg-emerald-950/40 px-1.5 py-0.5 rounded border border-emerald-200 dark:border-emerald-800">
                  اليوم
                </span>
              )}
            </div>
            <input
              type="date"
              value={payDate}
              onFocus={handleInputFocus}
              onChange={(e) => setPayDate(e.target.value)}
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-900 dark:text-white outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 transition-all font-mono"
            />
          </div>

          {/* Record Time Selector */}
          <RecordTimeSelector
            enabled={recordTime}
            onEnabledChange={setRecordTime}
            mode={timeMode}
            onModeChange={setTimeMode}
            time={payTime}
            onTimeChange={setPayTime}
            accentColor="emerald"
            idPrefix="sup_pay"
          />

          {/* Notes */}
          <div className="space-y-1">
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">ملاحظات / طريقة الدفع</label>
            <input
              type="text"
              value={notes}
              onFocus={handleInputFocus}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="مثال: نقداً / تحويل زين كاش / حوالة..."
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium text-slate-900 dark:text-white outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 transition-all"
            />
          </div>

          {/* Actions */}
          <div className="pt-2 flex items-center gap-2">
            <button
              type="submit"
              className="flex-1 py-3 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold rounded-xl text-xs shadow-md transition-all cursor-pointer active:scale-98 flex items-center justify-center gap-2"
            >
              <i className="fa-solid fa-check text-xs"></i>
              <span>حفظ التسديد وإخصام الدين</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="py-3 px-4 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold rounded-xl text-xs transition-all cursor-pointer"
            >
              إلغاء
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
