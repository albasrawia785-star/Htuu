import { Debtor, InstallmentRecord } from '../types';
import { formatFullDateTime } from './formatters';

export function formatNoticeDateTime(dateStr?: string | null): string {
  if (!dateStr) return new Date().toISOString().split('T')[0];
  const formatted = formatFullDateTime(dateStr, 'english');
  return formatted || (dateStr.includes('T') ? dateStr.split('T')[0] : dateStr);
}

/**
 * Formats a phone number for WhatsApp URL.
 * Handles Iraqi phone numbers (07xxxxxxxxx -> 9647xxxxxxxxx)
 * and cleans up any spaces, dashes, or non-numeric characters.
 */
export function formatPhoneNumberForWhatsApp(phone: string): string {
  if (!phone) return '';
  let cleaned = phone.replace(/[^\d+]/g, '');

  // Handle + prefix
  if (cleaned.startsWith('+')) {
    cleaned = cleaned.substring(1);
  }

  // Handle 00964...
  if (cleaned.startsWith('00964')) {
    cleaned = cleaned.substring(2);
  }

  // If starts with 07..., convert to 9647...
  if (cleaned.startsWith('07')) {
    cleaned = '964' + cleaned.substring(1);
  } else if (cleaned.length === 10 && cleaned.startsWith('7')) {
    cleaned = '964' + cleaned;
  }

  return cleaned;
}

/**
 * Generates the full WhatsApp API URL for sending a message
 */
export function getWhatsAppUrl(phone: string, message: string): string {
  const formattedPhone = formatPhoneNumberForWhatsApp(phone);
  // Ensure message is trimmed and within safe browser URL limits (under 3800 chars)
  const safeMessage = (message || '')
    .replace(/[\u0000-\u0008\u000B-\u000C\u000E-\u001F\u007F]/g, '')
    .trim()
    .slice(0, 3800);
  const encodedText = encodeURIComponent(safeMessage);
  return `https://api.whatsapp.com/send?phone=${formattedPhone}&text=${encodedText}`;
}

/**
 * Directly opens WhatsApp without any intermediate UI
 */
export function openWhatsAppDirect(phone: string, message: string): boolean {
  try {
    const formattedPhone = formatPhoneNumberForWhatsApp(phone);
    if (!formattedPhone) return false;
    const url = getWhatsAppUrl(phone, message);

    const a = document.createElement('a');
    a.href = url;
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      if (document.body.contains(a)) {
        document.body.removeChild(a);
      }
    }, 200);
    return true;
  } catch (err) {
    console.warn('Could not open WhatsApp directly:', err);
    try {
      const url = getWhatsAppUrl(phone, message);
      window.open(url, '_blank', 'noopener,noreferrer');
      return true;
    } catch {
      return false;
    }
  }
}

export interface WhatsAppNotificationData {
  customerName: string;
  phone: string;
  title: string;
  message: string;
  url: string;
}

/**
 * Helper to build the payment options block when electronic payment is enabled in Settings
 */
export function getPaymentMethodsBlock(mastercardNumber?: string, enableElectronicPayment?: boolean): string {
  if (enableElectronicPayment === false) return '';
  if (!mastercardNumber || !mastercardNumber.trim()) return '';
  return `\n\n━━━━━━━━━━━━━━━━━━━\nطرق التسديد المتاحة:\n• نقداً (كاش)\n• إلكترونياً (ماستر كارد):\n💳 رقم الماستر كارد: ${mastercardNumber.trim()}\n(يرجى إرسال إشعار التحويل بعد الإيداع لتأكيد السداد)\n━━━━━━━━━━━━━━━━━━━`;
}

export function formatPaymentMethodLabel(paymentMethod?: string): string {
  if (!paymentMethod) return 'نقداً (كاش)';
  return paymentMethod === 'electronic' ? 'دفع إلكتروني (ماستر كارد)' : 'نقداً (كاش)';
}

/**
 * 1. عند إضافة عميل مدين جديد (New Debtor)
 */
export function createNewDebtorWhatsAppNotice(
  debtor: Debtor,
  currencySymbol: string,
  _storeName: string = 'دفتر الديون',
  mastercardNumber?: string
): WhatsAppNotificationData | null {
  if (!debtor.phone || !debtor.phone.trim()) return null;

  const formattedAmount = Number(debtor.amount || 0).toLocaleString('en-US');
  const dateStr = debtor.createdAt
    ? debtor.createdAt.split('T')[0]
    : new Date().toISOString().split('T')[0];

  const dComp = (debtor as { companyName?: string }).companyName;
  const companyLine = dComp && dComp.trim() ? ` (${dComp.trim()})` : '';
  const notesStr = debtor.notes && debtor.notes.trim() ? `\nالملاحظات: ${debtor.notes.trim()}` : '';
  const paymentBlock = getPaymentMethodsBlock(mastercardNumber);

  const message = `السيد/ ${debtor.name}${companyLine} المحترم

نوع العملية: تسجيل دين

تم فتح حساب مالي باسمكم وتسجيل مبلغ مستحق بذمتكم بتاريخ ${dateStr}.

إجمالي المبلغ المستحق بذمتكم: ${formattedAmount} ${currencySymbol}${notesStr}

يرجى تسديد المبلغ المستحق في أقرب وقت ممكن.${paymentBlock}`;

  const url = getWhatsAppUrl(debtor.phone, message);
  return {
    customerName: debtor.name,
    phone: debtor.phone,
    title: 'إشعار تسجيل دين',
    message,
    url,
  };
}

/**
 * 2. عند إضافة دين إضافي لعميل مدين (Add Debt)
 */
export function createAddDebtWhatsAppNotice(
  debtor: Debtor,
  _addedAmount: number,
  newTotalAmount: number,
  currencySymbol: string,
  txDate?: string,
  notes?: string,
  _storeName: string = 'دفتر الديون',
  mastercardNumber?: string
): WhatsAppNotificationData | null {
  if (!debtor.phone || !debtor.phone.trim()) return null;

  const formattedTotal = newTotalAmount.toLocaleString('en-US');
  const dateStr = formatNoticeDateTime(txDate);

  const dComp = (debtor as { companyName?: string }).companyName;
  const companyLine = dComp && dComp.trim() ? ` (${dComp.trim()})` : '';
  const notesStr = notes && notes.trim() ? `\nالملاحظات: ${notes.trim()}` : '';
  const paymentBlock = getPaymentMethodsBlock(mastercardNumber);

  const message = `السيد/ ${debtor.name}${companyLine}

نوع العملية: إضافة دين

تم تحديث حسابكم وإضافة مبلغ جديد بتاريخ ووقت ${dateStr}.

إجمالي المبلغ المستحق بذمتكم: ${formattedTotal} ${currencySymbol}${notesStr}

يرجى تسديد المبلغ المستحق بأقرب وقت ممكن.${paymentBlock}`;

  const url = getWhatsAppUrl(debtor.phone, message);
  return {
    customerName: debtor.name,
    phone: debtor.phone,
    title: 'إشعار إضافة دين',
    message,
    url,
  };
}

/**
 * 3. عند تسديد دفعة من عميل مدين (Pay Debt - سند قبض)
 */
export function createPayDebtWhatsAppNotice(
  debtor: Debtor,
  paidAmount: number,
  remainingAmount: number,
  currencySymbol: string,
  txDate?: string,
  notes?: string,
  _storeName: string = 'دفتر الديون',
  paymentMethod?: string
): WhatsAppNotificationData | null {
  if (!debtor.phone || !debtor.phone.trim()) return null;

  const formattedPaid = (paidAmount || 0).toLocaleString('en-US');
  const formattedRemaining = remainingAmount.toLocaleString('en-US');
  const dateStr = formatNoticeDateTime(txDate);

  const dComp = (debtor as { companyName?: string }).companyName;
  const companyLine = dComp && dComp.trim() ? ` (${dComp.trim()})` : '';
  const notesStr = notes && notes.trim() ? `\nالملاحظات: ${notes.trim()}` : '';
  const methodStr = formatPaymentMethodLabel(paymentMethod);

  const message = `السيد/ ${debtor.name}${companyLine} المحترم
سند قبض مالي 🧾

تم بنجاح تسجيل استلام دفعة من حسابكم:
• المبلغ المسدد: ${formattedPaid} ${currencySymbol}
• طريقة الدفع: ${methodStr}
• التاريخ والوقت: ${dateStr}
• إجمالي المبلغ المتبقي بذمتكم: ${formattedRemaining} ${currencySymbol}${notesStr}

شكراً لتعاملكم وحسن التزامكم.`;

  const url = getWhatsAppUrl(debtor.phone, message);
  return {
    customerName: debtor.name,
    phone: debtor.phone,
    title: 'سند قبض - تسديد دفعة',
    message,
    url,
  };
}

/**
 * 4. عند إضافة عقد قسط جديد (New Installment)
 */
export function createNewInstallmentWhatsAppNotice(
  inst: InstallmentRecord,
  currencySymbol: string,
  storeName: string = 'نظام الأقساط',
  mastercardNumber?: string
): WhatsAppNotificationData | null {
  if (!inst.phone || !inst.phone.trim()) return null;

  const formattedTotal = Number(inst.totalAmount || 0).toLocaleString('en-US');
  const formattedDown = Number(inst.downPayment || 0).toLocaleString('en-US');
  const formattedRemaining = Number(inst.remainingAmount || 0).toLocaleString('en-US');
  const paymentBlock = getPaymentMethodsBlock(mastercardNumber);

  const message = `مرحباً ${inst.name}
تم تسجيل معاملة قسط جديدة لكم لدى (${storeName}):

السلعة: ${inst.item}
إجمالي قيمة الأقساط: ${formattedTotal} ${currencySymbol}
الدفعة المقدمة: ${formattedDown} ${currencySymbol}
المبلغ المتبقي: ${formattedRemaining} ${currencySymbol}
تاريخ القسط القادم: ${inst.nextDueDate}
${inst.notes ? `ملاحظات: ${inst.notes}\n` : ''}${paymentBlock}
شكراً لثقتكم بنا.`;

  const url = getWhatsAppUrl(inst.phone, message);
  return {
    customerName: inst.name,
    phone: inst.phone,
    title: 'تسجيل معاملة قسط جديدة',
    message,
    url,
  };
}

/**
 * 5. عند تسديد قسط (Pay Installment)
 */
export function createPayInstallmentWhatsAppNotice(
  inst: InstallmentRecord,
  paidAmount: number,
  newRemaining: number,
  nextDueDate: string,
  currencySymbol: string,
  payDate?: string,
  notes?: string,
  storeName: string = 'نظام الأقساط',
  paymentMethod?: string
): WhatsAppNotificationData | null {
  if (!inst.phone || !inst.phone.trim()) return null;

  const formattedPaid = paidAmount.toLocaleString('en-US');
  const formattedRemaining = newRemaining.toLocaleString('en-US');
  const dateStr = formatNoticeDateTime(payDate);
  const methodStr = formatPaymentMethodLabel(paymentMethod);

  const isCompleted = newRemaining <= 0;
  const statusLine = isCompleted
    ? 'تم تسديد كامل الأقساط بنجاح واكتمل العقد بالكامل.'
    : `المتبقي الكلي: ${formattedRemaining} ${currencySymbol}\nموعد القسط القادم: ${nextDueDate}`;

  const message = `مرحباً ${inst.name}
إيصال تسديد قسط لدى (${storeName}):

السلعة: ${inst.item}
المبلغ المسدد: ${formattedPaid} ${currencySymbol}
طريقة الدفع: ${methodStr}
تاريخ ووقت الدفع: ${dateStr}
${statusLine}
${notes ? `ملاحظات: ${notes}\n` : ''}
شكراً لالتزامكم بالتسديد.`;

  const url = getWhatsAppUrl(inst.phone, message);
  return {
    customerName: inst.name,
    phone: inst.phone,
    title: 'إيصال تسديد قسط',
    message,
    url,
  };
}

/**
 * 6. عند تسجيل دائن جديد في دفتر الديون (الذين يطلبوني)
 */
export function createNewSupplierWhatsAppNotice(
  supplierName: string,
  supplierPhone: string,
  companyName: string | undefined,
  amount: number,
  currencySymbol: string,
  notes?: string,
  _itemType?: string
): WhatsAppNotificationData | null {
  if (!supplierPhone || !supplierPhone.trim()) return null;

  const formattedAmount = Number(amount || 0).toLocaleString('en-US');
  const dateStr = formatNoticeDateTime(new Date().toISOString());
  const companyLine = companyName && companyName.trim() ? `\nالجهة / الشركة: ${companyName.trim()}` : '';
  const notesStr = notes && notes.trim() ? notes.trim() : '';

  const message = `إشعار حساب دائن
السيد/ ${supplierName}${companyLine}

تم تسجيل مبلغ مستحق لكم بذمتنا، وفق التفاصيل التالية:

• المبلغ المقيد: ${formattedAmount} ${currencySymbol}
• تاريخ ووقت القيد: ${dateStr}
• إجمالي المستحق لكم: ${formattedAmount} ${currencySymbol}${notesStr ? `\n• الملاحظات: ${notesStr}` : ''}

شكرًا لتعاونكم.`;

  const url = getWhatsAppUrl(supplierPhone, message);
  return {
    customerName: supplierName,
    phone: supplierPhone,
    title: 'إشعار حساب دائن',
    message,
    url,
  };
}

/**
 * 6.b. عند إضافة دين جديد للدائن (قيد مالي إضافي)
 */
export function createAddSupplierDebtWhatsAppNotice(
  supplierName: string,
  supplierPhone: string,
  companyName: string | undefined,
  addedAmount: number,
  newRemainingAmount: number,
  currencySymbol: string,
  notes?: string,
  _itemType?: string,
  txDate?: string
): WhatsAppNotificationData | null {
  if (!supplierPhone || !supplierPhone.trim()) return null;

  const formattedAdded = Number(addedAmount || 0).toLocaleString('en-US');
  const formattedTotal = Number(newRemainingAmount || 0).toLocaleString('en-US');
  const dateStr = formatNoticeDateTime(txDate);
  const companyLine = companyName && companyName.trim() ? `\nالجهة / الشركة: ${companyName.trim()}` : '';
  const notesStr = notes && notes.trim() ? notes.trim() : '';

  const message = `السيد/ ${supplierName}${companyLine}
إشعار إضافة مبلغ

تم تسجيل مبلغ مستحق لكم بذمتنا:

• المبلغ المضاف: ${formattedAdded} ${currencySymbol}
• التاريخ والوقت: ${dateStr}
• إجمالي المستحق لكم: ${formattedTotal} ${currencySymbol}${notesStr ? `\n• الملاحظات: ${notesStr}` : ''}

شكرًا لتعاونكم.`;

  const url = getWhatsAppUrl(supplierPhone, message);
  return {
    customerName: supplierName,
    phone: supplierPhone,
    title: 'إشعار إضافة مبلغ',
    message,
    url,
  };
}

/**
 * 7. عند تسديد دفعة مالية للدائن
 */
export function createPaySupplierWhatsAppNotice(
  supplierName: string,
  supplierPhone: string,
  companyName: string | undefined,
  paidAmount: number,
  newRemainingAmount: number,
  currencySymbol: string,
  payDate?: string,
  notes?: string,
  _itemType?: string,
  paymentMethod?: string
): WhatsAppNotificationData | null {
  if (!supplierPhone || !supplierPhone.trim()) return null;

  const formattedPaid = paidAmount.toLocaleString('en-US');
  const formattedRemaining = newRemainingAmount.toLocaleString('en-US');
  const dateStr = formatNoticeDateTime(payDate);
  const companyLine = companyName && companyName.trim() ? `\nالجهة / الشركة: ${companyName.trim()}` : '';
  const notesStr = notes && notes.trim() ? notes.trim() : '';
  const methodStr = formatPaymentMethodLabel(paymentMethod);

  const message = `السيد/ ${supplierName}${companyLine}
إشعار تسديد دفعة 🧾

تم تسجيل تسديد دفعة مالية من حسابكم:

• المبلغ المسدد: ${formattedPaid} ${currencySymbol}
• طريقة الدفع: ${methodStr}
• التاريخ والوقت: ${dateStr}
• المتبقي لكم: ${formattedRemaining} ${currencySymbol}${notesStr ? `\n• الملاحظات: ${notesStr}` : ''}

شكرًا لتعاونكم.`;

  const url = getWhatsAppUrl(supplierPhone, message);
  return {
    customerName: supplierName,
    phone: supplierPhone,
    title: 'إشعار تسديد',
    message,
    url,
  };
}

/**
 * 8. تذكير أو مطابقة رصيد حساب دائن
 */
export function createSupplierReminderWhatsAppNotice(
  supplierName: string,
  supplierPhone: string,
  companyName: string | undefined,
  amount: number,
  currencySymbol: string,
  _itemType?: string
): WhatsAppNotificationData | null {
  if (!supplierPhone || !supplierPhone.trim()) return null;

  const formattedAmount = Number(amount || 0).toLocaleString('en-US');
  const companyLine = companyName && companyName.trim() ? `\nالجهة / الشركة: ${companyName.trim()}` : '';

  const message = `إشعار مطابقة رصيد حساب دائن

السيد/ ${supplierName}${companyLine}
تحية طيبة وبعد،

نود إشعاركم بمطابقة رصيد حسابكم المالي المسجل لدينا:

• إجمالي الرصيد المستحق لكم: ${formattedAmount} ${currencySymbol}

شاكرين لكم حسن التعاون.`;

  const url = getWhatsAppUrl(supplierPhone, message);
  return {
    customerName: supplierName,
    phone: supplierPhone,
    title: 'إشعار مطابقة رصيد دائن',
    message,
    url,
  };
}
