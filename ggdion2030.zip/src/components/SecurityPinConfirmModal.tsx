import React, { useState, useEffect, useRef } from 'react';

interface SecurityPinConfirmModalProps {
  isOpen: boolean;
  title: string;
  message: string;
  targetName?: string;
  actionType?: 'delete' | 'edit' | 'reset';
  requiredPin: string;
  onConfirm: () => void;
  onCancel: () => void;
}

export const SecurityPinConfirmModal: React.FC<SecurityPinConfirmModalProps> = ({
  isOpen,
  title,
  message,
  targetName,
  actionType = 'delete',
  requiredPin,
  onConfirm,
  onCancel,
}) => {
  const [pinInput, setPinInput] = useState('');
  const [showPin, setShowPin] = useState(false);
  const [hasError, setHasError] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setPinInput('');
      setHasError(false);
      setShowPin(false);
      setTimeout(() => {
        inputRef.current?.focus();
      }, 100);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const targetPin = (requiredPin || '1').trim();
  const isMatched = pinInput.trim() === targetPin;

  const handleConfirm = () => {
    if (!isMatched) {
      setHasError(true);
      return;
    }
    onConfirm();
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && isMatched) {
      e.preventDefault();
      handleConfirm();
    } else if (e.key === 'Escape') {
      e.preventDefault();
      onCancel();
    }
  };

  const appendDigit = (digit: string) => {
    setPinInput((prev) => prev + digit);
    setHasError(false);
  };

  const handleBackspace = () => {
    setPinInput((prev) => prev.slice(0, -1));
    setHasError(false);
  };

  const handleClear = () => {
    setPinInput('');
    setHasError(false);
    inputRef.current?.focus();
  };

  return (
    <div
      className="fixed inset-0 z-[99999] flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn overflow-y-auto"
      dir="rtl"
      role="dialog"
      aria-modal="true"
    >
      <div
        className="w-full max-w-[380px] sm:max-w-md my-auto bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200/80 dark:border-slate-800 overflow-hidden flex flex-col max-h-[94vh] animate-scaleUp"
        onKeyDown={handleKeyDown}
      >
        {/* Compact Header */}
        <div className={`px-5 py-4 text-center shrink-0 ${
          actionType === 'delete' 
            ? 'bg-gradient-to-b from-rose-50/90 to-white dark:from-rose-950/40 dark:to-slate-900 border-b border-rose-100 dark:border-rose-900/30'
            : 'bg-gradient-to-b from-amber-50/90 to-white dark:from-amber-950/40 dark:to-slate-900 border-b border-amber-100 dark:border-amber-900/30'
        }`}>
          <div className="flex items-center justify-center gap-2 mb-1.5">
            <div className="w-8 h-8 rounded-xl bg-rose-100 dark:bg-rose-900/60 text-rose-600 dark:text-rose-400 flex items-center justify-center text-sm shadow-xs">
              <i className="fa-solid fa-lock"></i>
            </div>
            <h3 className="text-base sm:text-lg font-black text-slate-900 dark:text-white">
              {title}
            </h3>
          </div>

          <p className="text-xs text-slate-600 dark:text-slate-300 leading-snug line-clamp-2 px-1">
            {message}
          </p>

          {targetName && (
            <div className="mt-2 inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-rose-50 dark:bg-rose-950/70 border border-rose-200/80 dark:border-rose-800/60 text-rose-800 dark:text-rose-300 text-[11px] font-bold">
              <span>المستهدف:</span>
              <span className="font-black text-rose-950 dark:text-rose-200 underline decoration-rose-300">{targetName}</span>
            </div>
          )}
        </div>

        {/* Content Area */}
        <div className="p-4 sm:p-5 space-y-3.5 overflow-y-auto">
          {/* PIN Display / Input */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300 px-1">
              <span>أدخل رمز الأمان للتأكيد:</span>
              <span className="text-[10px] text-slate-400 font-mono">الافتراضي (1)</span>
            </div>

            <div className="relative flex items-center">
              <input
                ref={inputRef}
                type={showPin ? 'text' : 'password'}
                value={pinInput}
                onChange={(e) => {
                  setPinInput(e.target.value);
                  setHasError(false);
                }}
                placeholder="اكتب رمز الأمان..."
                autoComplete="off"
                className={`w-full px-10 py-2.5 sm:py-3 rounded-2xl text-center text-lg sm:text-xl font-black tracking-widest bg-slate-50 dark:bg-slate-800/90 border ${
                  hasError
                    ? 'border-rose-500 ring-2 ring-rose-500/20 text-rose-600 dark:text-rose-400'
                    : isMatched
                    ? 'border-emerald-500 ring-2 ring-emerald-500/20 text-emerald-600 dark:text-emerald-400'
                    : 'border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white focus:border-rose-500 focus:ring-2 focus:ring-rose-500/20'
                } outline-none transition-all shadow-inner`}
              />

              {/* Toggle Show/Hide Icon on Left */}
              <button
                type="button"
                onClick={() => setShowPin(!showPin)}
                className="absolute left-3 p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
                title={showPin ? 'إخفاء' : 'إظهار'}
              >
                <i className={`fa-solid ${showPin ? 'fa-eye-slash' : 'fa-eye'} text-sm`}></i>
              </button>

              {/* Status Indicator Icon on Right */}
              <div className="absolute right-3.5 pointer-events-none">
                {isMatched ? (
                  <i className="fa-solid fa-circle-check text-emerald-500 text-base"></i>
                ) : hasError ? (
                  <i className="fa-solid fa-circle-xmark text-rose-500 text-base"></i>
                ) : (
                  <i className="fa-solid fa-key text-slate-300 dark:text-slate-600 text-sm"></i>
                )}
              </div>
            </div>

            {hasError && (
              <p className="text-[11px] font-bold text-rose-600 dark:text-rose-400 text-center pt-0.5">
                ⚠️ رمز الأمان غير صحيح، يرجى كتابة الرمز الصحيح.
              </p>
            )}
          </div>

          {/* Correctly Aligned Phone Dialer Keypad (Left-to-Right 1 2 3 Layout) */}
          <div className="pt-0.5" dir="ltr">
            <div className="grid grid-cols-3 gap-1.5 sm:gap-2">
              {[
                '1', '2', '3',
                '4', '5', '6',
                '7', '8', '9',
                'C', '0', 'DEL'
              ].map((key) => {
                if (key === 'C') {
                  return (
                    <button
                      key={key}
                      type="button"
                      onClick={handleClear}
                      className="h-10 sm:h-11 rounded-xl font-bold text-xs bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-rose-600 dark:text-rose-400 active:scale-95 transition-all flex items-center justify-center select-none shadow-xs"
                    >
                      مسح
                    </button>
                  );
                }
                if (key === 'DEL') {
                  return (
                    <button
                      key={key}
                      type="button"
                      onClick={handleBackspace}
                      className="h-10 sm:h-11 rounded-xl font-bold text-sm bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 active:scale-95 transition-all flex items-center justify-center select-none shadow-xs"
                      title="حذف خانة"
                    >
                      <i className="fa-solid fa-delete-left"></i>
                    </button>
                  );
                }
                return (
                  <button
                    key={key}
                    type="button"
                    onClick={() => appendDigit(key)}
                    className="h-10 sm:h-11 rounded-xl font-black text-base sm:text-lg bg-slate-100/90 hover:bg-slate-200/90 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 active:scale-95 transition-all flex items-center justify-center select-none shadow-xs"
                  >
                    {key}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Bottom Actions - Always Visible */}
        <div className="p-4 pt-2 bg-slate-50/90 dark:bg-slate-850 border-t border-slate-100 dark:border-slate-800/80 flex items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={onCancel}
            className="flex-1 py-2.5 px-3 rounded-xl font-bold text-xs sm:text-sm bg-white hover:bg-slate-100 dark:bg-slate-800 dark:hover:bg-slate-750 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 active:scale-98 transition-all"
          >
            إلغاء الأمر
          </button>
          <button
            type="button"
            onClick={handleConfirm}
            disabled={!isMatched}
            className={`flex-1 py-2.5 px-3 rounded-xl font-black text-xs sm:text-sm transition-all shadow-md flex items-center justify-center gap-1.5 ${
              isMatched
                ? 'bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-700 hover:to-red-700 text-white shadow-rose-500/25 cursor-pointer active:scale-98'
                : 'bg-slate-200 dark:bg-slate-800 text-slate-400 dark:text-slate-600 cursor-not-allowed shadow-none'
            }`}
          >
            <i className="fa-solid fa-unlock-keyhole"></i>
            <span>تأكيد الإجراء</span>
          </button>
        </div>
      </div>
    </div>
  );
};
