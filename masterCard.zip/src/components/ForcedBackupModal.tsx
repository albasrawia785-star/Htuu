import React, { useState } from 'react';
import { AppSettings, Debtor, InstallmentRecord, Manager, Supplier, User } from '../types';
import { shareBackupPdf, shareBackupTxt, executeExportBackup } from '../utils/backupExport';
import { formatNumber } from '../utils/formatters';

interface ForcedBackupModalProps {
  isOpen: boolean;
  currentUser: User;
  debtors: Debtor[];
  installments?: InstallmentRecord[];
  suppliers?: Supplier[];
  managers?: Manager[];
  settings: AppSettings;
  daysPassed: number;
  lastDateStr: string | null;
  onBackupSuccess: () => void;
  onShowToast: (message: string, type: 'success' | 'error' | 'info') => void;
}

export const ForcedBackupModal: React.FC<ForcedBackupModalProps> = ({
  isOpen,
  currentUser,
  debtors,
  installments = [],
  suppliers = [],
  managers = [],
  settings,
  daysPassed,
  lastDateStr,
  onBackupSuccess,
  onShowToast,
}) => {
  const [isSharingPdf, setIsSharingPdf] = useState(false);
  const [isSharingTxt, setIsSharingTxt] = useState(false);
  const [isSharingJson, setIsSharingJson] = useState(false);

  if (!isOpen) return null;

  const realDebtors = (debtors || []).filter((d) => !d.isDemo);
  const myDebtors = realDebtors.filter((d) => d.type !== 'creditor');
  const myCreditors = realDebtors.filter((d) => d.type === 'creditor');
  const realInstallments = (installments || []).filter((i) => !i.isDemo);
  const realSuppliers = (suppliers || []).filter((s) => !s.isDemo);

  const isBusy = isSharingPdf || isSharingTxt || isSharingJson;

  const handleSharePdf = async () => {
    try {
      setIsSharingPdf(true);
      const res = await shareBackupPdf({
        currentUser,
        debtors,
        installments,
        suppliers,
        managers,
        settings,
      });
      if (res.success) {
        onShowToast('تم إنشاء ومشاركة كشف الحساب الشامل (PDF) بنجاح', 'success');
        onBackupSuccess();
      }
    } catch (err: any) {
      console.error('Share PDF error:', err);
      onShowToast(`حدث خطأ أثناء إعداد ملف PDF: ${err?.message || 'خطأ غير معروف'}`, 'error');
    } finally {
      setIsSharingPdf(false);
    }
  };

  const handleShareTxt = async () => {
    try {
      setIsSharingTxt(true);
      const res = await shareBackupTxt({
        currentUser,
        debtors,
        installments,
        suppliers,
        managers,
        settings,
      });
      if (res.success) {
        onShowToast('تمت مشاركة كشف الحساب النصي بنجاح', 'success');
        onBackupSuccess();
      }
    } catch (err: any) {
      console.error('Share TXT error:', err);
      onShowToast(`حدث خطأ أثناء المشاركة: ${err?.message || 'خطأ غير معروف'}`, 'error');
    } finally {
      setIsSharingTxt(false);
    }
  };

  const handleShareJson = async () => {
    try {
      setIsSharingJson(true);
      const res = await executeExportBackup({
        currentUser,
        debtors,
        installments,
        suppliers,
        managers,
        settings,
      });
      if (res.success) {
        onShowToast('تمت مشاركة ملف النسخة الاحتياطية بنجاح', 'success');
        onBackupSuccess();
      }
    } catch (err: any) {
      console.error('Share JSON error:', err);
      onShowToast(`حدث خطأ أثناء المشاركة: ${err?.message || 'خطأ غير معروف'}`, 'error');
    } finally {
      setIsSharingJson(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-[99999] flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md select-none animate-fadeIn"
      dir="rtl"
      role="dialog"
      aria-modal="true"
    >
      <div className="bg-white dark:bg-slate-900 border border-amber-300 dark:border-amber-600/40 rounded-2xl max-w-lg w-full shadow-2xl overflow-hidden animate-scaleUp">
        {/* Header Banner */}
        <div className="bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 p-5 text-white text-center relative">
          <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center mx-auto mb-2.5 shadow-inner ring-4 ring-white/30 animate-pulse">
            <svg
              className="w-9 h-9 text-white"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth={2}
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z"
              />
            </svg>
          </div>
          <h2 className="text-xl font-bold tracking-wide">تنبيه أمان: مشاركة نسخة احتياطية</h2>
          <p className="text-amber-100 text-xs mt-1">
            إجراء دوري إلزامي كل 3 أيام لحماية سجلات وحسابات المعرض
          </p>
        </div>

        {/* Content Body */}
        <div className="p-5 sm:p-6 space-y-4 text-slate-700 dark:text-slate-200">
          <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/50 rounded-xl p-3.5 text-sm leading-relaxed text-amber-900 dark:text-amber-200">
            <p className="font-semibold text-sm mb-1 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-amber-500 inline-block"></span>
              <span>
                مرت {daysPassed >= 3 ? `${daysPassed} أيام` : '3 أيام'} دون مشاركة نسخة احتياطية
              </span>
            </p>
            <p className="text-xs text-amber-800 dark:text-amber-300">
              لحماية بيانات الفرع (
              <span className="font-bold underline">{currentUser.branch_name || currentUser.username}</span>
              ) من الضياع، يرجى مشاركة كشف الحساب الآن بصيغة <span className="font-bold font-mono">PDF</span> أو <span className="font-bold font-mono">TXT</span> أو <span className="font-bold font-mono">JSON</span> للمتابعة.
            </p>
            {lastDateStr && (
              <div className="mt-1.5 text-[11px] text-amber-700 dark:text-amber-400 font-mono">
                تاريخ آخر نسخة مسجلة: {lastDateStr}
              </div>
            )}
          </div>

          {/* Records Summary Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <div className="bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-lg p-2.5 text-center">
              <span className="text-[11px] text-slate-500 dark:text-slate-400 block mb-0.5">المدينين</span>
              <span className="font-bold text-blue-600 dark:text-blue-400 font-mono text-sm">
                {formatNumber(myDebtors.length)}
              </span>
            </div>
            <div className="bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-lg p-2.5 text-center">
              <span className="text-[11px] text-slate-500 dark:text-slate-400 block mb-0.5">ديون عليّ</span>
              <span className="font-bold text-rose-600 dark:text-rose-400 font-mono text-sm">
                {formatNumber(myCreditors.length)}
              </span>
            </div>
            <div className="bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-lg p-2.5 text-center">
              <span className="text-[11px] text-slate-500 dark:text-slate-400 block mb-0.5">الأقساط</span>
              <span className="font-bold text-purple-600 dark:text-purple-400 font-mono text-sm">
                {formatNumber(realInstallments.length)}
              </span>
            </div>
            <div className="bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-lg p-2.5 text-center">
              <span className="text-[11px] text-slate-500 dark:text-slate-400 block mb-0.5">الموردين</span>
              <span className="font-bold text-amber-600 dark:text-amber-400 font-mono text-sm">
                {formatNumber(realSuppliers.length)}
              </span>
            </div>
          </div>

          {/* Share Action Buttons */}
          <div className="space-y-2.5 pt-1">
            {/* 1. Share PDF Button */}
            <button
              onClick={handleSharePdf}
              disabled={isBusy}
              className="w-full py-3 px-4 bg-gradient-to-r from-red-600 via-rose-600 to-red-700 hover:from-red-700 hover:to-rose-700 active:scale-[0.99] text-white font-bold rounded-xl shadow-md shadow-red-600/20 flex items-center justify-center gap-2.5 transition-all cursor-pointer disabled:opacity-75 disabled:cursor-not-allowed"
            >
              {isSharingPdf ? (
                <>
                  <svg className="animate-spin h-5 w-5 text-white" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
                  </svg>
                  <span>جاري إعداد ومشاركة ملف PDF...</span>
                </>
              ) : (
                <>
                  <svg className="w-5 h-5 text-red-200" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
                  </svg>
                  <span>مشاركة كشف الحساب كملف PDF رسمي</span>
                </>
              )}
            </button>

            {/* 2. Share TXT / WhatsApp Button */}
            <button
              onClick={handleShareTxt}
              disabled={isBusy}
              className="w-full py-3 px-4 bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 hover:from-emerald-700 hover:to-teal-700 active:scale-[0.99] text-white font-bold rounded-xl shadow-md shadow-emerald-600/20 flex items-center justify-center gap-2.5 transition-all cursor-pointer disabled:opacity-75 disabled:cursor-not-allowed"
            >
              {isSharingTxt ? (
                <>
                  <svg className="animate-spin h-5 w-5 text-white" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
                  </svg>
                  <span>جاري تجهيز ومشاركة النص...</span>
                </>
              ) : (
                <>
                  <svg className="w-5 h-5 text-emerald-200" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                  </svg>
                  <span>مشاركة كشف الحساب نصي عبر الواتساب</span>
                </>
              )}
            </button>

            {/* 3. Share JSON File Button */}
            <button
              onClick={handleShareJson}
              disabled={isBusy}
              className="w-full py-2.5 px-4 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-semibold rounded-xl border border-slate-300 dark:border-slate-600 flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-75"
            >
              {isSharingJson ? (
                <span>جاري مشاركة النسخة...</span>
              ) : (
                <>
                  <svg className="w-4 h-4 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
                  </svg>
                  <span className="text-xs">مشاركة ملف النظام الكامل (JSON)</span>
                </>
              )}
            </button>
          </div>

          <div className="text-center text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-center gap-1.5 pt-1">
            <svg className="w-3.5 h-3.5 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
            <span>المشاركة تتيح إرسال التقرير عبر الواتساب أو تيليجرام أو حفظه محلياً</span>
          </div>
        </div>
      </div>
    </div>
  );
};
