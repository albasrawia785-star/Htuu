import React, { useState } from 'react';
import { AppSettings, Debtor, InstallmentRecord, Manager, Supplier, User } from '../types';
import { executeExportBackup } from '../utils/backupExport';
import { formatNumber } from '../utils/formatters';

interface ForcedBackupModalProps {
  isOpen: boolean;
  currentUser: User;
  debtors: Debtor[];
  installments?: InstallmentRecord[];
  suppliers?: Supplier[];
  managers?: Manager[];
  settings: AppSettings;
  daysPassed: number;
  lastDateStr: string | null;
  onBackupSuccess: () => void;
  onShowToast: (message: string, type: 'success' | 'error' | 'info') => void;
}

export const ForcedBackupModal: React.FC<ForcedBackupModalProps> = ({
  isOpen,
  currentUser,
  debtors,
  installments = [],
  suppliers = [],
  managers = [],
  settings,
  daysPassed,
  lastDateStr,
  onBackupSuccess,
  onShowToast,
}) => {
  const [isSharingJson, setIsSharingJson] = useState(false);

  if (!isOpen) return null;

  const realDebtors = (debtors || []).filter((d) => !d.isDemo);
  const myDebtors = realDebtors.filter((d) => d.type !== 'creditor');
  const myCreditors = realDebtors.filter((d) => d.type === 'creditor');
  const realInstallments = (installments || []).filter((i) => !i.isDemo);
  const realSuppliers = (suppliers || []).filter((s) => !s.isDemo);

  const handleShareJson = async () => {
    try {
      setIsSharingJson(true);
      const res = await executeExportBackup({
        currentUser,
        debtors,
        installments,
        suppliers,
        managers,
        settings,
      });
      if (res.success) {
        onShowToast('تم حفظ وتصدير ملف النسخة الاحتياطية (JSON) بنجاح', 'success');
        onBackupSuccess();
      }
    } catch (err: any) {
      console.error('Share JSON error:', err);
      onShowToast(`حدث خطأ أثناء إعداد النسخة: ${err?.message || 'خطأ غير معروف'}`, 'error');
    } finally {
      setIsSharingJson(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-[99999] flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md select-none animate-fadeIn"
      dir="rtl"
      role="dialog"
      aria-modal="true"
    >
      <div className="bg-white dark:bg-slate-900 border border-amber-300 dark:border-amber-600/40 rounded-2xl max-w-lg w-full shadow-2xl overflow-hidden animate-scaleUp">
        {/* Header Banner */}
        <div className="bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 p-5 text-white text-center relative">
          <div className="w-14 h-14 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center mx-auto mb-2.5 shadow-inner ring-4 ring-white/30">
            <svg
              className="w-7 h-7 text-white"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth={2}
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"
              />
            </svg>
          </div>
          <h2 className="text-xl font-bold tracking-wide">حماية إضافية لبياناتك</h2>
          <p className="text-amber-100 text-xs mt-1 font-medium">
            الفرع: {currentUser.branch_name || currentUser.username}
          </p>
        </div>

        {/* Content Body */}
        <div className="p-5 sm:p-6 space-y-4 text-slate-700 dark:text-slate-200">
          <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/50 rounded-xl p-4 text-sm leading-relaxed text-amber-950 dark:text-amber-100">
            <p className="font-bold text-sm mb-2 flex items-center gap-2 text-amber-900 dark:text-amber-200">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500 inline-block shrink-0"></span>
              <span>
                مرت {daysPassed >= 3 ? `${daysPassed} أيام` : '3 أيام'} دون تصدير نسخة احتياطية على جهازك
              </span>
            </p>
            <p className="text-xs sm:text-sm text-amber-900/90 dark:text-amber-200/90 leading-6">
              بياناتك محفوظة سحابيًا، لكن لا تعتمد على نسخة واحدة فقط.
              احفظ نسخة احتياطية من بياناتك على هاتفك بشكل دوري، لتبقى لديك نسخة مستقلة يمكنك استخدامها لاستعادة بياناتك كاملة إذا حدثت مشكلة في الخادم أو مزود الخدمة أو فقدان البيانات بشكل غير متوقع.
            </p>
            {lastDateStr && (
              <div className="mt-2.5 pt-2 border-t border-amber-200/70 dark:border-amber-800/50 text-[11px] text-amber-800 dark:text-amber-400 font-mono">
                تاريخ آخر نسخة محفوظة محلياً: {lastDateStr}
              </div>
            )}
          </div>

          {/* Records Summary Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <div className="bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-lg p-2.5 text-center">
              <span className="text-[11px] text-slate-500 dark:text-slate-400 block mb-0.5">المدينين</span>
              <span className="font-bold text-blue-600 dark:text-blue-400 font-mono text-sm">
                {formatNumber(myDebtors.length)}
              </span>
            </div>
            <div className="bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-lg p-2.5 text-center">
              <span className="text-[11px] text-slate-500 dark:text-slate-400 block mb-0.5">ديون عليّ</span>
              <span className="font-bold text-rose-600 dark:text-rose-400 font-mono text-sm">
                {formatNumber(myCreditors.length)}
              </span>
            </div>
            <div className="bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-lg p-2.5 text-center">
              <span className="text-[11px] text-slate-500 dark:text-slate-400 block mb-0.5">الأقساط</span>
              <span className="font-bold text-purple-600 dark:text-purple-400 font-mono text-sm">
                {formatNumber(realInstallments.length)}
              </span>
            </div>
            <div className="bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-lg p-2.5 text-center">
              <span className="text-[11px] text-slate-500 dark:text-slate-400 block mb-0.5">الموردين</span>
              <span className="font-bold text-amber-600 dark:text-amber-400 font-mono text-sm">
                {formatNumber(realSuppliers.length)}
              </span>
            </div>
          </div>

          {/* Primary Action Button */}
          <div className="pt-2">
            <button
              onClick={handleShareJson}
              disabled={isSharingJson}
              className="w-full py-3.5 px-4 bg-gradient-to-r from-amber-600 via-orange-600 to-amber-700 hover:from-amber-700 hover:to-orange-700 active:scale-[0.99] text-white font-bold rounded-xl shadow-lg shadow-orange-600/25 flex items-center justify-center gap-2.5 transition-all cursor-pointer disabled:opacity-75 disabled:cursor-not-allowed text-sm"
            >
              {isSharingJson ? (
                <>
                  <svg className="animate-spin h-5 w-5 text-white" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
                  </svg>
                  <span>جاري حفظ وتصدير النسخة الاحتياطية...</span>
                </>
              ) : (
                <>
                  <svg className="w-5 h-5 text-amber-200" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
                  </svg>
                  <span>حفظ وتصدير نسخة احتياطية على هاتفك (JSON)</span>
                </>
              )}
            </button>
          </div>

          <div className="text-center text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-center gap-1.5 pt-1">
            <svg className="w-3.5 h-3.5 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
            <span>يتم حفظ ملف مشفر ومستقل يمكنك الاحتفاظ به على جهازك أو إرساله للواتساب</span>
          </div>
        </div>
      </div>
    </div>
  );
};
