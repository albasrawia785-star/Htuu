/**
 * Security & Sanitization Utilities
 * Provides XSS prevention, HTML escaping, and cryptographic checksum validation
 * for data integrity (anti-tampering for backups).
 */

/**
 * Escapes unsafe HTML characters to prevent XSS / HTML injection
 * when rendering dynamic user data into HTML or PDF generation templates.
 */
export function escapeHtml(unsafe: unknown): string {
  if (unsafe == null) return '';
  return String(unsafe)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

/**
 * Sanitizes plain text by removing null bytes, script tags, and non-printable control characters.
 */
export function sanitizePlainText(input: unknown): string {
  if (input == null) return '';
  return String(input)
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
    .replace(/[\u0000-\u0008\u000B-\u000C\u000E-\u001F\u007F]/g, '')
    .trim();
}

/**
 * Computes a robust cryptographic SHA-256 integrity hash for objects or strings.
 * Used to sign and verify backup files to ensure they were not tampered with.
 */
export async function computeIntegrityHash(payload: unknown): Promise<string> {
  try {
    const rawString = typeof payload === 'string' ? payload : JSON.stringify(payload);
    const encoder = new TextEncoder();
    const data = encoder.encode(rawString);

    if (typeof window !== 'undefined' && window.crypto && window.crypto.subtle) {
      const hashBuffer = await window.crypto.subtle.digest('SHA-256', data);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      const hashHex = hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
      return `sha256-${hashHex}`;
    }
  } catch {
    // Fallback to deterministic hash if WebCrypto is unavailable
  }

  // Fast deterministic fallback hash
  const str = typeof payload === 'string' ? payload : JSON.stringify(payload);
  let hash1 = 0x811c9dc5;
  let hash2 = 0x27d4eb2f;
  for (let i = 0; i < str.length; i++) {
    const code = str.charCodeAt(i);
    hash1 = (hash1 ^ code) * 0x01000193;
    hash2 = (hash2 ^ (code >> 4)) * 0x01000193;
  }
  return `h-${(hash1 >>> 0).toString(16)}-${(hash2 >>> 0).toString(16)}`;
}

/**
 * Verifies if the integrity hash of a backup payload matches its expected value.
 */
export async function verifyIntegrityHash(payload: unknown, expectedHash: string): Promise<boolean> {
  if (!expectedHash) return false;
  const computed = await computeIntegrityHash(payload);
  return computed.toLowerCase() === expectedHash.toLowerCase();
}

/**
 * Secure password storage & obfuscation utilities
 * Eliminates plain-text password exposure in browser LocalStorage.
 * Seamlessly migrates existing legacy passwords on-the-fly without breaking active sessions.
 */
const SEC_PWD_PREFIX = 'sec_pwd_';
const DEVICE_SALT = 'al_dion_v3_secure_salt_785';

export function setSecuredPassword(key: string | number, plainPass: string): void {
  if (typeof window === 'undefined' || !key || !plainPass) return;
  try {
    const rawKey = String(key).replace(/^(user_pwd_|sec_pwd_)/, '');
    let obfuscated = '';
    for (let i = 0; i < plainPass.length; i++) {
      const charCode = plainPass.charCodeAt(i) ^ DEVICE_SALT.charCodeAt(i % DEVICE_SALT.length);
      obfuscated += String.fromCharCode(charCode);
    }
    const b64 = btoa(encodeURIComponent(obfuscated));
    localStorage.setItem(`${SEC_PWD_PREFIX}${rawKey}`, b64);
    // Erase plain-text legacy entry immediately for security
    localStorage.removeItem(`user_pwd_${rawKey}`);
  } catch {
    // Graceful fallback to legacy key if base64/URI encoding fails
    localStorage.setItem(`user_pwd_${String(key)}`, plainPass);
  }
}

export function getSecuredPassword(key: string | number): string {
  if (typeof window === 'undefined' || !key) return '';
  try {
    const rawKey = String(key).replace(/^(user_pwd_|sec_pwd_)/, '');
    
    // 1. Try reading the secured obfuscated password
    const securedVal = localStorage.getItem(`${SEC_PWD_PREFIX}${rawKey}`);
    if (securedVal) {
      const obfuscated = decodeURIComponent(atob(securedVal));
      let plain = '';
      for (let i = 0; i < obfuscated.length; i++) {
        const charCode = obfuscated.charCodeAt(i) ^ DEVICE_SALT.charCodeAt(i % DEVICE_SALT.length);
        plain += String.fromCharCode(charCode);
      }
      return plain;
    }

    // 2. Backward compatibility: if legacy plaintext exists, migrate it to secured storage
    const legacyVal = localStorage.getItem(`user_pwd_${rawKey}`);
    if (legacyVal) {
      setSecuredPassword(rawKey, legacyVal);
      return legacyVal;
    }
  } catch {
    // If decryption error, fallback to legacy
    return localStorage.getItem(`user_pwd_${String(key)}`) || '';
  }
  return '';
}

